import{$n as vu,$t as eU,A as Fg,An as oT,Cn as nC,Dn as nm,Dt as XC,En as ne,Fn as pV,Gn as tU,H as Kg,Ln as rU,O as Es,On as nt$1,Ot as Xe,Pn as pC,R as Iu,U as Kw,Un as tC,Ut as _u,V as Jw,Vt as _i,Wt as aC,Xn as vf,_ as Bg,_t as So,ar as yf,b as Ct$1,bn as mC,bt as UI,ct as Pe,dn as hu,en as eb,er as xg,et as Nl,f as Af,fn as hy,ft as QE,g as BI,h as BC,ht as Rs,it as Ob,j as Fs,jn as or,k as Eu,kt as Xg,lt as Pg,mt as Rg,nn as fV,nt as No,on as gm,pn as iU,pt as QT,qn as v,rn as g,rr as yC,s as u,u as A,v as Bm,vt as St$1,w as Du,wn as na,x as DC}from"./main-3QBSMUZZ.js";import{C as ee,E as ji,F as sr,I as ts,L as vn,N as ri,O as mr,P as rs,R as wt$1,_ as Qa,a as Br,b as Vt,c as Hr,f as Kr,m as Ne,o as Dt$1,p as Me,s as Ft$1,t as $n,u as Ja,w as hr,x as Wr,y as Ur}from"./chunk-DQx8XbKA.js";import{n as Lr,r as Xr,s as qr,t as Fr}from"./chunk-CMnOXcFs.js";import{a as He,w as z}from"./chunk-DZy8PcWk.js";import{i as lt,r as ct$1}from"./chunk-7SdlaC6J.js";var et=(()=>{class t{labelPosition=`after`;static ɵfac=function(r){return new(r||t)};static ɵcmp=(function(){return So({type:t,selectors:[[``,`mat-internal-form-field`,``]],hostAttrs:[1,`mdc-form-field`,`mat-internal-form-field`],hostVars:2,hostBindings:function(d,f){d&2&&Rs(`mdc-form-field--align-end`,f.labelPosition===`before`)},inputs:{labelPosition:`labelPosition`},ngContentSelectors:[`*`],decls:1,vars:0,template:function(d,f){d&1&&(vu(),Du(0))},styles:[`.mat-internal-form-field {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}
.mat-internal-form-field > label, .mat-internal-form-field > .mat-internal-form-field-label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
  order: 0;
}
[dir=rtl] .mat-internal-form-field > label, [dir=rtl] .mat-internal-form-field > .mat-internal-form-field-label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
}

.mdc-form-field--align-end > label, .mdc-form-field--align-end > .mat-internal-form-field-label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
  order: -1;
}
[dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end label, [dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end .mat-internal-form-field-label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
}
`],encapsulation:2})})()}return t})();var st=new v(`mat-slide-toggle-default-options`,{providedIn:`root`,factory:()=>({disableToggleValue:!1,hideIcon:!1,disabledInteractive:!1})});var X=class{source;checked;constructor(a,e){this.source=a,this.checked=e}};var Z=(()=>{class t{_elementRef=g(nt$1);_focusMonitor=g(He);_changeDetectorRef=g(gm);defaults=g(st);_injector=g(ne);_signalFormField=null;_onChange=e=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=!1;_createChangeEvent(e){return new X(this,e)}_labelId;get buttonId(){return`${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus()}_noopAnimations=Xr();_focused=!1;name=null;id;labelPosition=`after`;ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=!1;color;disabled=!1;fullWidth=!1;disableRipple=!1;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked=e,this._changeDetectorRef.markForCheck()}hideIcon;disabledInteractive;change=new Pe;toggleChange=new Pe;get inputId(){return`${this.id||this._uniqueId}-input`}constructor(){g(QT).load(ct$1);let e=g(new Fs(`tabindex`),{optional:!0}),r=this.defaults;this.tabIndex=e==null?0:parseInt(e)||0,this.color=r.color||`accent`,this.id=this._uniqueId=g(z).getId(`mat-mdc-slide-toggle-`),this.hideIcon=r.hideIcon??!1,this.disabledInteractive=r.disabledInteractive??!1,this._labelId=this._uniqueId+`-label`}ngOnInit(){this._signalFormField=this._injector.get($n,void 0,{optional:!0,self:!0})}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,!0).subscribe(e=>{e===`keyboard`||e===`program`?(this._focused=!0,this._changeDetectorRef.markForCheck()):e||Promise.resolve().then(()=>{this._focused=!1,this._onTouched(),this._changeDetectorRef.markForCheck()})})}ngOnChanges(e){e.required&&this._validatorOnChange()}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef)}writeValue(e){this.checked=!!e}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}validate(e){return this.required&&e.value!==!0&&!this._signalFormField?{required:!0}:null}registerOnValidatorChange(e){this._validatorOnChange=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck()}toggle(){this.checked=!this.checked,this._onChange(this.checked)}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked))}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new X(this,this.checked))))}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static ɵfac=function(r){return new(r||t)};static ɵcmp=(function(){let e=[`switch`],r=[`*`];function d(f,v){f&1&&(Es(0,`span`,11),Af(),Es(1,`svg`,13),Rg(2,`path`,14),hu(),Es(3,`svg`,15),Rg(4,`path`,16),hu()())}return So({type:t,selectors:[[`mat-slide-toggle`]],viewQuery:function(v,l){if(v&1&&Bg(e,5),v&2){let C;mC(C=yC())&&(l._switchElement=C.first)}},hostAttrs:[1,`mat-mdc-slide-toggle`],hostVars:15,hostBindings:function(v,l){v&2&&(Fg(`id`,l.id),No(`tabindex`,null)(`aria-label`,null)(`name`,null)(`aria-labelledby`,null),Eu(l.color?`mat-`+l.color:``),Rs(`mat-mdc-slide-toggle-focused`,l._focused)(`mat-mdc-slide-toggle-checked`,l.checked)(`mat-slide-toggle-full-width`,l.fullWidth)(`_mat-animation-noopable`,l._noopAnimations))},inputs:{name:`name`,id:`id`,labelPosition:`labelPosition`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],ariaDescribedby:[0,`aria-describedby`,`ariaDescribedby`],required:[2,`required`,`required`,_u],color:`color`,disabled:[2,`disabled`,`disabled`,_u],fullWidth:[2,`fullWidth`,`fullWidth`,_u],disableRipple:[2,`disableRipple`,`disableRipple`,_u],tabIndex:[2,`tabIndex`,`tabIndex`,f=>f==null?0:Ob(f)],checked:[2,`checked`,`checked`,_u],hideIcon:[2,`hideIcon`,`hideIcon`,_u],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,_u]},outputs:{change:`change`,toggleChange:`toggleChange`},exportAs:[`matSlideToggle`],features:[nm([{provide:Ne,useExisting:_i(()=>t),multi:!0},{provide:ee,useExisting:t,multi:!0}]),Nl],ngContentSelectors:r,decls:14,vars:27,consts:[[`switch`,``],[`mat-internal-form-field`,``,3,`labelPosition`],[`role`,`switch`,`type`,`button`,1,`mdc-switch`,3,`click`,`tabIndex`,`disabled`],[1,`mat-mdc-slide-toggle-touch-target`],[1,`mdc-switch__track`],[1,`mdc-switch__handle-track`],[1,`mdc-switch__handle`],[1,`mdc-switch__shadow`],[1,`mdc-elevation-overlay`],[1,`mdc-switch__ripple`],[`mat-ripple`,``,1,`mat-mdc-slide-toggle-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`,`matRippleCentered`],[1,`mdc-switch__icons`],[1,`mdc-label`,3,`click`,`for`],[`viewBox`,`0 0 24 24`,`aria-hidden`,`true`,1,`mdc-switch__icon`,`mdc-switch__icon--on`],[`d`,`M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z`],[`viewBox`,`0 0 24 24`,`aria-hidden`,`true`,1,`mdc-switch__icon`,`mdc-switch__icon--off`],[`d`,`M20 13H4v-2h16v2z`]],template:function(v,l){if(v&1&&(vu(),Es(0,`div`,1)(1,`button`,2,0),Pg(`click`,function(){return l._handleClick()}),Rg(3,`div`,3)(4,`span`,4),Es(5,`span`,5)(6,`span`,6)(7,`span`,7),Rg(8,`span`,8),hu(),Es(9,`span`,9),Rg(10,`span`,10),hu(),Kw(11,d,5,0,`span`,11),hu()()(),Es(12,`label`,12),Pg(`click`,function(at){return at.stopPropagation()}),Du(13),hu()()),v&2){let C=DC(2);xg(`labelPosition`,l.labelPosition),QE(),Rs(`mdc-switch--selected`,l.checked)(`mdc-switch--unselected`,!l.checked)(`mdc-switch--checked`,l.checked)(`mdc-switch--disabled`,l.disabled)(`mat-mdc-slide-toggle-disabled-interactive`,l.disabledInteractive),xg(`tabIndex`,l.disabled&&!l.disabledInteractive?-1:l.tabIndex)(`disabled`,l.disabled&&!l.disabledInteractive),No(`id`,l.buttonId)(`name`,l.name)(`aria-label`,l.ariaLabel)(`aria-labelledby`,l._getAriaLabelledBy())(`aria-describedby`,l.ariaDescribedby)(`aria-required`,l.required||null)(`aria-checked`,l.checked)(`aria-disabled`,l.disabled&&l.disabledInteractive?`true`:null),QE(9),xg(`matRippleTrigger`,C)(`matRippleDisabled`,l.disableRipple||l.disabled)(`matRippleCentered`,!0),QE(),Jw(l.hideIcon?-1:11),QE(),xg(`for`,l.buttonId),No(`id`,l._labelId)}},dependencies:[lt,et],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--%NS%mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--%NS%mat-slide-toggle-track-height, 32px);
  border-radius: var(--%NS%mat-slide-toggle-track-shape, var(--%NS%mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--%NS%mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--%NS%mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-track-outline-color, var(--%NS%mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--%NS%mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--%NS%mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-disabled-unselected-track-outline-color, var(--%NS%mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--%NS%mat-slide-toggle-unselected-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--%NS%mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--%NS%mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--%NS%mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--%NS%mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-hover-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-focus-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-track-color, var(--%NS%mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-disabled-unselected-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--%NS%mat-slide-toggle-selected-track-color, var(--%NS%mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--%NS%mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--%NS%mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--%NS%mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--%NS%mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-track-color, var(--%NS%mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-track-color, var(--%NS%mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-track-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-disabled-selected-track-color, var(--%NS%mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--%NS%mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--%NS%mat-slide-toggle-handle-width);
  height: var(--%NS%mat-slide-toggle-handle-height);
  border-radius: var(--%NS%mat-slide-toggle-handle-shape, var(--%NS%mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--%NS%mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--%NS%mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--%NS%mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-selected-handle-size, 24px);
  height: var(--%NS%mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--%NS%mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--%NS%mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--%NS%mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--%NS%mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--%NS%mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--%NS%selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--%NS%mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--%NS%unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--%NS%mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--%NS%mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--%NS%mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--%NS%selected:enabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-handle-color, var(--%NS%mat-sys-on-primary));
}
.mdc-switch--%NS%selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-handle-color, var(--%NS%mat-sys-primary-container));
}
.mdc-switch--%NS%selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-handle-color, var(--%NS%mat-sys-primary-container));
}
.mdc-switch--%NS%selected:enabled:active .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-handle-color, var(--%NS%mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-disabled-selected-handle-color, var(--%NS%mat-sys-surface));
}
.mdc-switch--%NS%unselected:enabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-handle-color, var(--%NS%mat-sys-outline));
}
.mdc-switch--%NS%unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-hover-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--%NS%unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-focus-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--%NS%unselected:enabled:active .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-disabled-unselected-handle-color, var(--%NS%mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--%NS%mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--%NS%mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--%NS%mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--%NS%mat-slide-toggle-state-layer-size, 40px);
  height: var(--%NS%mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--%NS%unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-hover-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mdc-switch--%NS%unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-focus-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mdc-switch--%NS%unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--%NS%selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mdc-switch--%NS%selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mdc-switch--%NS%selected:enabled:active .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--%NS%mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--%NS%mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--%NS%mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--%NS%mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--%NS%mat-slide-toggle-unselected-icon-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--%NS%mat-slide-toggle-disabled-unselected-icon-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--%NS%mat-slide-toggle-selected-icon-size, 16px);
  height: var(--%NS%mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--%NS%mat-slide-toggle-selected-icon-color, var(--%NS%mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--%NS%mat-slide-toggle-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-icon {
  min-height: fit-content;
  flex-shrink: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--%NS%mat-slide-toggle-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-slide-toggle-label-text-font, var(--%NS%mat-sys-body-medium-font));
  line-height: var(--%NS%mat-slide-toggle-label-text-line-height, var(--%NS%mat-sys-body-medium-line-height));
  font-size: var(--%NS%mat-slide-toggle-label-text-size, var(--%NS%mat-sys-body-medium-size));
  letter-spacing: var(--%NS%mat-slide-toggle-label-text-tracking, var(--%NS%mat-sys-body-medium-tracking));
  font-weight: var(--%NS%mat-slide-toggle-label-text-weight, var(--%NS%mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--%NS%mat-slide-toggle-disabled-label-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-slide-toggle-full-width {
  width: 100%;
}
.mat-slide-toggle-full-width .mat-internal-form-field {
  width: 100%;
  justify-content: space-between;
}
.mat-slide-toggle-full-width .mat-internal-form-field label {
  margin: 0;
  flex-grow: 1;
  text-align: end;
}
.mat-slide-toggle-full-width .mdc-form-field--align-end label {
  text-align: start;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--%NS%mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--%NS%mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2})})()}return t})();var tt=(()=>{class t{static ɵfac=function(r){return new(r||t)};static ɵmod=Ct$1({type:t});static ɵinj=Xe({imports:[Z,hy]})}return t})();var B=class t{http=g(na);api=iU.apiUrl;list(a=1,e=10){let r=new St$1().set(`page`,String(a)).set(`per_page`,String(e));return this.http.get(`${this.api}/users`,{params:r})}create(a){return this.http.post(`${this.api}/users`,a)}static ɵfac=function(e){return new(e||t)};static ɵprov=A({token:t,factory:t.ɵfac,providedIn:`root`})};function dt(t,a){if(t&1){let e=aC();Es(0,`nav`,0)(1,`button`,1),Pg(`click`,function(){yf(e);let d=pC();return vf(d.go(d.page()-1))}),Es(2,`mat-icon`),BC(3,`chevron_left`),hu(),BC(4),hu(),Es(5,`span`,2),BC(6),hu(),Es(7,`button`,1),Pg(`click`,function(){yf(e);let d=pC();return vf(d.go(d.page()+1))}),BC(8),Es(9,`mat-icon`),BC(10,`chevron_right`),hu()()()}if(t&2){let e=pC();QE(),xg(`disabled`,e.page()<=1),QE(3),Iu(` `,e.messages.pager.previous,` `),QE(2),Kg(e.messages.pager.info(e.page(),e.lastPage())),QE(),xg(`disabled`,e.page()>=e.lastPage()),QE(),Iu(` `,e.messages.pager.next,` `)}}var G=class t{messages=rU;page=pV.required();lastPage=pV.required();pageChange=fV();go(a){a>=1&&a<=this.lastPage()&&a!==this.page()&&this.pageChange.emit(a)}static ɵfac=function(e){return new(e||t)};static ɵcmp=So({type:t,selectors:[[`app-pager`]],inputs:{page:[1,`page`],lastPage:[1,`lastPage`]},outputs:{pageChange:`pageChange`},decls:1,vars:1,consts:[[`aria-label`,`Paginación`,1,`pager`],[`type`,`button`,1,`btn`,`btn--outline`,`btn--sm`,3,`click`,`disabled`],[1,`pager__info`]],template:function(e,r){e&1&&Kw(0,dt,11,5,`nav`,0),e&2&&Jw(r.lastPage()>1?0:-1)},dependencies:[tU,eU],styles:[`.pager[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:16px;margin-top:20px;flex-wrap:wrap}.pager__info[_ngcontent-%COMP%]{font-size:.84rem;color:var(--%NS%optic-muted)}@media(max-width:480px){.pager[_ngcontent-%COMP%]{gap:8px}.pager[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}}`]})};var ct=(t,a)=>a.id;function mt(t,a){t&1&&Rg(0,`mat-progress-bar`,9)}function gt(t,a){t&1&&BC(0,` El nombre es obligatorio. `)}function ht(t,a){t&1&&BC(0,` El nombre no puede superar los 100 caracteres. `)}function pt(t,a){t&1&&BC(0,` Escribe al menos 3 letras. `)}function ut(t,a){if(t&1&&(Es(0,`mat-error`),Kw(1,gt,1,0)(2,ht,1,0)(3,pt,1,0),hu()),t&2){let e=pC();QE(),Jw(e.form.controls.name.errors?.required?1:e.form.controls.name.errors?.maxlength?2:3)}}function ft(t,a){t&1&&BC(0,` Usa solo letras, números, guiones o guiones bajos. `)}function bt(t,a){t&1&&BC(0,` El nombre de usuario es obligatorio. `)}function _t(t,a){t&1&&BC(0,` Debe tener al menos 3 caracteres. `)}function vt(t,a){if(t&1&&(Es(0,`mat-error`),Kw(1,ft,1,0)(2,bt,1,0)(3,_t,1,0),hu()),t&2){let e=pC();QE(),Jw(e.form.controls.username.errors?.pattern?1:e.form.controls.username.errors?.required?2:3)}}function wt(t,a){t&1&&BC(0,` La contraseña es demasiado larga. `)}function yt(t,a){t&1&&BC(0,` La contraseña debe tener al menos 8 caracteres. `)}function kt(t,a){if(t&1&&(Es(0,`mat-error`),Kw(1,wt,1,0)(2,yt,1,0),hu()),t&2){let e=pC();QE(),Jw(e.form.controls.password.errors?.maxlength?1:2)}}function xt(t,a){t&1&&BC(0,` Las contraseñas no coinciden. `)}function St(t,a){t&1&&BC(0,` La contraseña es demasiado larga. `)}function Ct(t,a){t&1&&BC(0,` Repite la contraseña. `)}function Nt(t,a){if(t&1&&(Es(0,`mat-error`),Kw(1,xt,1,0)(2,St,1,0)(3,Ct,1,0),hu()),t&2){let e=pC();QE(),Jw(e.form.controls.password_confirmation.errors?.mismatch?1:e.form.controls.password_confirmation.errors?.maxlength?2:3)}}function Mt(t,a){if(t&1&&(Es(0,`div`,22)(1,`span`,4),BC(2,`error`),hu(),Es(3,`span`),BC(4),hu()()),t&2){let e=pC();QE(4),Kg(e.error())}}function It(t,a){t&1&&(Rg(0,`span`,28),BC(1,` Creando… `))}function Et(t,a){t&1&&(Es(0,`span`,4),BC(1,`person_add`),hu(),BC(2,` Crear usuario `))}function zt(t,a){t&1&&Rg(0,`mat-progress-bar`,9)}function Pt(t,a){t&1&&(Es(0,`div`,27)(1,`span`,4),BC(2,`group`),hu(),Es(3,`h3`),BC(4,`No hay usuarios`),hu(),Es(5,`p`),BC(6,`Crea el primero con el formulario de la izquierda.`),hu()())}function Tt(t,a){if(t&1&&(Es(0,`span`,36),BC(1),XC(2,`date`),hu()),t&2){let e=pC().$implicit;QE(),Kg(eb(2,1,e.created_at,`dd/MM/yyyy`))}}function Ft(t,a){if(t&1&&(Es(0,`li`,30)(1,`span`,32),BC(2),hu(),Es(3,`div`,33)(4,`strong`),BC(5),hu(),Es(6,`span`,8),BC(7),hu()(),Es(8,`div`,34)(9,`span`,35),BC(10),hu(),Kw(11,Tt,3,4,`span`,36),hu()()),t&2){let e=a.$implicit;QE(2),Kg(e.name.charAt(0)),QE(3),Kg(e.name),QE(2),Iu(`@`,e.username),QE(2),Rs(`user-status--inactive`,!e.is_active),QE(),Iu(` `,e.is_active?`Activo`:`Inactivo`,` `),QE(),Jw(e.created_at?11:-1)}}function Dt(t,a){if(t&1){let e=aC();Es(0,`ul`,29),tC(1,Ft,12,7,`li`,30,ct),hu(),Es(3,`app-pager`,31),Pg(`pageChange`,function(d){yf(e);let f=pC();return vf(f.goToPage(d))}),hu()}if(t&2){let e=pC();QE(),nC(e.users()),QE(2),xg(`page`,e.page())(`lastPage`,e.lastPage())}}var nt=class t{fb=g(Wr);usersService=g(B);toast=g(u);formDirective;users=or([]);loading=or(!0);saving=or(!1);error=or(null);page=or(1);lastPage=or(1);total=or(0);pageSize=10;form=this.fb.nonNullable.group({name:[``,[Me.required,Me.minLength(3),Me.maxLength(100),ts]],username:[``,[Me.required,Me.minLength(3),Me.maxLength(50),Me.pattern(/^[a-zA-Z0-9_-]+$/),ts]],password:[``,[Me.required,Me.minLength(8),Me.maxLength(255)]],password_confirmation:[``,[Me.required,Me.maxLength(255)]],is_active:[!0]},{validators:rs});ngOnInit(){this.loadUsers()}loadUsers(){this.loading.set(!0),this.usersService.list(this.page(),this.pageSize).subscribe({next:a=>{this.users.set(a.data),this.total.set(a.total),this.lastPage.set(a.last_page),this.loading.set(!1)},error:a=>{this.loading.set(!1),this.toast.error(qr(a,rU.users.loadFallback))}})}submit(){if(this.form.invalid){this.form.markAllAsTouched();return}if(this.form.controls.password.value!==this.form.controls.password_confirmation.value){this.form.controls.password_confirmation.setErrors({mismatch:!0}),this.form.controls.password_confirmation.markAsTouched();return}this.saving.set(!0),this.error.set(null);let a=this.form.getRawValue();this.usersService.create({name:a.name.trim(),username:a.username.trim().toLowerCase(),password:a.password,password_confirmation:a.password_confirmation,is_active:a.is_active}).subscribe({next:e=>{this.saving.set(!1),this.toast.success(e.message||rU.users.createSuccess),this.clearForm(),this.page.set(1),this.loadUsers()},error:e=>{this.saving.set(!1),this.error.set(qr(e,rU.users.createFallback))}})}clearForm(){let a={name:``,username:``,password:``,password_confirmation:``,is_active:!0};this.formDirective?this.formDirective.resetForm(a):this.form.reset(a),this.form.markAsPristine(),this.form.markAsUntouched(),this.form.updateValueAndValidity(),this.error.set(null)}goToPage(a){a<1||a>this.lastPage()||a===this.page()||(this.page.set(a),this.loadUsers(),window.scrollTo({top:0,behavior:`smooth`}))}static ɵfac=function(e){return new(e||t)};static ɵcmp=So({type:t,selectors:[[`app-users`]],viewQuery:function(e,r){if(e&1&&Bg(wt$1,5),e&2){let d;mC(d=yC())&&(r.formDirective=d.first)}},decls:87,vars:14,consts:[[1,`page`],[1,`page-header`],[1,`page-header__text`],[1,`banner`,`banner--info`,2,`margin-bottom`,`16px`],[1,`material-icons`],[1,`users-layout`],[1,`card`],[1,`section-head`],[1,`muted`,`small`],[`mode`,`indeterminate`],[1,`stack`,3,`ngSubmit`,`formGroup`],[1,`form-required-note`],[1,`form-grid`],[`appearance`,`outline`,1,`full`],[`matInput`,``,`formControlName`,`name`,`autocomplete`,`name`,`maxlength`,`100`,`placeholder`,`Ej. Ana Torres`],[`matPrefix`,``],[`appearance`,`outline`],[`matInput`,``,`formControlName`,`username`,`autocomplete`,`username`,`autocapitalize`,`none`,`spellcheck`,`false`,`maxlength`,`50`,`placeholder`,`Ej. maria`],[1,`active-toggle`],[`formControlName`,`is_active`,`color`,`primary`],[`matInput`,``,`type`,`password`,`formControlName`,`password`,`autocomplete`,`new-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password_confirmation`,`autocomplete`,`new-password`,`maxlength`,`255`],[1,`banner`,`banner--danger`],[1,`form-actions`],[`type`,`submit`,1,`btn`,`btn--primary`,`btn--lg`,3,`disabled`],[`type`,`button`,1,`btn`,`btn--outline`,`btn--lg`,3,`click`,`disabled`],[`type`,`button`,1,`btn`,`btn--ghost`,`btn--sm`,3,`click`],[1,`empty-state`],[1,`spinner`],[1,`user-list`],[1,`user-item`],[3,`pageChange`,`page`,`lastPage`],[1,`user-item__avatar`],[1,`user-item__body`],[1,`user-item__side`],[1,`user-status`],[1,`muted`,`tiny`]],template:function(e,r){e&1&&(Es(0,`div`,0)(1,`header`,1)(2,`div`,2)(3,`h1`),BC(4,`Usuarios`),hu(),Es(5,`p`),BC(6,`Crea una cuenta para que otra persona pueda ingresar al sistema.`),hu()()(),Es(7,`div`,3)(8,`span`,4),BC(9,`info`),hu(),Es(10,`span`),BC(11,` Los usuarios nuevos tienen los mismos permisos que tú. Comparte la contraseña de forma segura y pídele que la cambie después de su primer ingreso. `),hu()(),Es(12,`div`,5)(13,`section`,6)(14,`div`,7)(15,`div`)(16,`h2`),BC(17,`Crear usuario`),hu(),Es(18,`p`,8),BC(19,`Completa los datos de la persona que usará el sistema.`),hu()()(),Kw(20,mt,1,0,`mat-progress-bar`,9),Es(21,`form`,10),Pg(`ngSubmit`,function(){return r.submit()}),Es(22,`p`,11),BC(23,`Los campos con * son obligatorios.`),hu(),Es(24,`div`,12)(25,`mat-form-field`,13)(26,`mat-label`),BC(27,`Nombre completo`),hu(),Es(28,`input`,14),BI(),hu(),Es(29,`mat-icon`,15),BC(30,`badge`),hu(),Es(31,`mat-hint`),BC(32,`Nombre y apellidos de la persona.`),hu(),Kw(33,ut,4,1,`mat-error`),hu(),Es(34,`mat-form-field`,16)(35,`mat-label`),BC(36,`Nombre de usuario`),hu(),Es(37,`input`,17),BI(),hu(),Es(38,`mat-icon`,15),BC(39,`person`),hu(),Es(40,`mat-hint`),BC(41,`Sin espacios. Se usará para iniciar sesión.`),hu(),Kw(42,vt,4,1,`mat-error`),hu(),Es(43,`div`,18)(44,`mat-slide-toggle`,19),BI(),BC(45,` Usuario activo `),hu(),Es(46,`p`,8),BC(47,` Si está activo, podrá iniciar sesión inmediatamente. Puedes desactivarlo al crearlo si aún no lo usará. `),hu()(),Es(48,`mat-form-field`,16)(49,`mat-label`),BC(50,`Contraseña`),hu(),Es(51,`input`,20),BI(),hu(),Es(52,`mat-icon`,15),BC(53,`lock`),hu(),Es(54,`mat-hint`),BC(55,`Mínimo 8 caracteres. Compártela de forma segura.`),hu(),Kw(56,kt,3,1,`mat-error`),hu(),Es(57,`mat-form-field`,16)(58,`mat-label`),BC(59,`Repetir contraseña`),hu(),Es(60,`input`,21),BI(),hu(),Es(61,`mat-icon`,15),BC(62,`lock_reset`),hu(),Es(63,`mat-hint`),BC(64,`Debe coincidir exactamente con la contraseña.`),hu(),Kw(65,Nt,4,1,`mat-error`),hu()(),Kw(66,Mt,5,1,`div`,22),Es(67,`div`,23)(68,`button`,24),Kw(69,It,2,0)(70,Et,3,0),hu(),Es(71,`button`,25),Pg(`click`,function(){return r.clearForm()}),BC(72,` Limpiar `),hu()()()(),Es(73,`section`,6)(74,`div`,7)(75,`div`)(76,`h2`),BC(77,`Usuarios del sistema`),hu(),Es(78,`p`,8),BC(79),hu()(),Es(80,`button`,26),Pg(`click`,function(){return r.loadUsers()}),Es(81,`mat-icon`),BC(82,`refresh`),hu(),BC(83,` Actualizar `),hu()(),Kw(84,zt,1,0,`mat-progress-bar`,9),Kw(85,Pt,7,0,`div`,27)(86,Dt,4,2),hu()()()),e&2&&(QE(20),Jw(r.saving()?20:-1),QE(),xg(`formGroup`,r.form),QE(7),UI(),QE(5),Jw(r.form.controls.name.touched&&r.form.controls.name.invalid?33:-1),QE(4),UI(),QE(5),Jw(r.form.controls.username.touched&&r.form.controls.username.invalid?42:-1),QE(2),UI(),QE(7),UI(),QE(5),Jw(r.form.controls.password.touched&&r.form.controls.password.invalid?56:-1),QE(4),UI(),QE(5),Jw(r.form.controls.password_confirmation.touched&&r.form.controls.password_confirmation.invalid?65:-1),QE(),Jw(r.error()?66:-1),QE(2),xg(`disabled`,r.saving()),QE(),Jw(r.saving()?69:70),QE(2),xg(`disabled`,r.saving()),QE(8),Xg(` `,r.total(),` `,r.total()===1?`usuario registrado`:`usuarios registrados`,`. `),QE(5),Jw(r.loading()?84:-1),QE(),Jw(!r.loading()&&r.users().length===0?85:86))},dependencies:[Bm,Kr,Ur,vn,Br,Hr,ji,wt$1,sr,Vt,ri,Dt$1,Ft$1,mr,hr,Ja,Qa,tU,eU,Fr,Lr,tt,Z,G,oT],styles:[`.users-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:16px;align-items:start}.section-head[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}.section-head[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-size:1.05rem}.active-toggle[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;padding:8px 12px;border:1px solid var(--%NS%optic-border);border-radius:12px;background:#fbfdfd;height:fit-content;margin-top:4px}.active-toggle[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0}.user-list[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0;display:flex;flex-direction:column}.user-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:11px;padding:12px 4px;border-bottom:1px solid #eef4f4}.user-item[_ngcontent-%COMP%]:last-child{border-bottom:none}.user-item__avatar[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:12px;background:#e2f6f6;color:#007171;display:grid;place-items:center;font-weight:800;font-size:1rem;flex-shrink:0;text-transform:uppercase}.user-item__body[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0;flex:1}.user-item__body[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.user-item__side[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0}.user-status[_ngcontent-%COMP%]{display:inline-flex;border-radius:999px;padding:3px 10px;font-size:.72rem;font-weight:700;background:var(--%NS%optic-success-soft);color:#217a45}.user-status--inactive[_ngcontent-%COMP%]{background:#eef1f1;color:#62706f}.spinner[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:_ngcontent-%COMP%_spin .7s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}@media(max-width:980px){.users-layout[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr)}}@media(max-width:720px){.form-actions[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}.user-item[_ngcontent-%COMP%]{align-items:flex-start}}`]})};export{nt as UsersComponent};