import{An as py,At as YT,Bn as tC,C as Es,Ct as Vg,Dn as ov,Dt as Xg,E as Fs,Et as Xe,Fn as rT,G as Le,Gn as v,H as KC,I as Iu,In as rU,It as Zy,J as M2,Jn as vf,Jt as fC,K as Lg,Kn as vC,Kt as eU,Ln as rv,Mt as ZC,N as HI,Ot as Xw,Pn as qy,Pt as Zi,R as JC,Rn as sC,Rt as _o,Sn as nt,T as Fg,Tn as or,U as Kg,Un as te,V as Jw,Vn as tU,Wt as eC,Xn as vu,Xt as g,Z as Mo,Zn as xg,Zt as gC,an as hu,at as Ot,bn as ne,bt as VC,ct as Qw,dn as kt,dt as Rg,et as Nl,ft as Rs,g as Ct,gn as ma,hn as mC,i as ua,in as hr,jn as qC,k as G$1,kt as YE,n as G,nn as he,nr as yf,p as Bg,pt as Sg,r as di,rn as hm,st as Q,t as B,u as Af,ut as Rb,vn as n_,w as Eu,wt as Vm,xn as nm,xt as VI,y as Du,yt as V,zt as _u}from"./main-CFZDGVOD.js";import{a as jr,n as Fr,r as Gr,t as Ar}from"./chunk-Cxg2CmRk.js";import{b as q,h as X,l as Re,v as nt$1,y as p}from"./chunk-CJmGvftz.js";import{D as xe,S as rt,_ as ke$1,b as ma$1,d as an,i as Pn$1,l as Zn$1,n as En$1,u as _e,w as ue,x as rn}from"./chunk-CHOU0nKw.js";import{t as m}from"./chunk-DTKzuofc.js";import{n as U}from"./chunk-s8amlX7K.js";import{n as Ft}from"./chunk-BwrSnfOa.js";import{i as l,n as f}from"./chunk-DHsVWloz.js";import"./chunk-DAa08OhI.js";import{n as u,t as A}from"./chunk-C596hOfa.js";import{C as hr$1,D as mr,E as li,F as ts,I as vn,L as wt,M as ri,P as sr,T as ji,_ as Ti,a as Dt,b as Wr,c as It,d as Kr,f as Me,g as Qa,h as Pi,i as Br,j as qr,k as or$1,l as Ja,m as Nt,n as $r,o as Ft$1,r as At,s as Hr,t as $n$1,u as Ke,v as Ur,w as is,x as Y,y as Vt}from"./chunk-CoCFn46E.js";import{n as S,r as s,t as E}from"./chunk-u2fsw79w.js";import{t as g$1}from"./chunk-Dv-4ht92.js";var Ee=new v(`MAT_OPTION_PARENT_COMPONENT`);var Ie=new v(`MatOptgroup`);var ke=class{source;isUserInput;constructor(o,e=!1){this.source=o,this.isUserInput=e}};var H=(()=>{class n{_element=g(nt);_changeDetectorRef=g(hm);_parent=g(Ee,{optional:!0});group=g(Ie,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue=``;get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=g(q).getId(`mat-option-`);get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=or(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new Le;_text;_stateChanges=new te;constructor(){let e=g(YT);e.load(an),e.load(M2),this._signalDisableRipple=!!this._parent&&Zi(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||``).trim()}select(e=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}deselect(e=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}focus(e,t){let a=this._getHostElement();typeof a.focus==`function`&&a.focus(t)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!Re(e)&&(this._selectViaInteraction(),e.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?`-1`:`0`}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let e=this.viewValue;e!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=e)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(e=!1){this.onSelectionChange.emit(new ke(this,e))}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`text`],t=[[[`mat-icon`]],`*`],a=[`mat-icon`,`*`];function p(f,C){if(f&1&&Rg(0,`mat-pseudo-checkbox`,1),f&2){let m=fC();xg(`disabled`,m.disabled)(`state`,m.selected?`checked`:`unchecked`)}}function y(f,C){if(f&1&&Rg(0,`mat-pseudo-checkbox`,3),f&2){let m=fC();xg(`disabled`,m.disabled)}}function k(f,C){if(f&1&&(Es(0,`span`,4),VC(1),hu()),f&2){let m=fC();YE(),Iu(`(`,m.group.label,`)`)}}return _o({type:n,selectors:[[`mat-option`]],viewQuery:function(C,m){if(C&1&&Bg(e,7),C&2){let g;gC(g=mC())&&(m._text=g.first)}},hostAttrs:[`role`,`option`,1,`mat-mdc-option`,`mdc-list-item`],hostVars:11,hostBindings:function(C,m){C&1&&Lg(`click`,function(){return m._selectViaInteraction()})(`keydown`,function(v){return m._handleKeydown(v)}),C&2&&(Fg(`id`,m.id),Mo(`aria-selected`,m.selected)(`aria-disabled`,m.disabled.toString()),Rs(`mdc-list-item--selected`,m.selected)(`mat-mdc-option-multiple`,m.multiple)(`mat-mdc-option-active`,m.active)(`mdc-list-item--disabled`,m.disabled))},inputs:{value:`value`,id:`id`,disabled:[2,`disabled`,`disabled`,_u]},outputs:{onSelectionChange:`onSelectionChange`},exportAs:[`matOption`],ngContentSelectors:a,decls:8,vars:5,consts:[[`text`,``],[`aria-hidden`,`true`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`,`state`],[1,`mdc-list-item__primary-text`],[`state`,`checked`,`aria-hidden`,`true`,`appearance`,`minimal`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`],[1,`cdk-visually-hidden`],[`aria-hidden`,`true`,`mat-ripple`,``,1,`mat-mdc-option-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`]],template:function(C,m){C&1&&(vu(t),Qw(0,p,1,2,`mat-pseudo-checkbox`,1),Du(1),Es(2,`span`,2,0),Du(4,1),hu(),Qw(5,y,1,1,`mat-pseudo-checkbox`,3),Qw(6,k,2,1,`span`,4),Rg(7,`div`,5)),C&2&&(Xw(m.multiple?0:-1),YE(5),Xw(!m.multiple&&m.selected&&!m.hideSingleSelectionIndicator?5:-1),YE(),Xw(m.group&&m.group._inert?6:-1),YE(),xg(`matRippleTrigger`,m._getHostElement())(`matRippleDisabled`,m.disabled||m.disableRipple))},dependencies:[S,ma$1],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--%NS%mat-option-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-option-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-option-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-option-label-text-size, var(--%NS%mat-sys-body-large-size));
  letter-spacing: var(--%NS%mat-option-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-option-label-text-weight, var(--%NS%mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--%NS%mat-option-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--%NS%mat-option-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--%NS%mat-option-selected-state-layer-color, var(--%NS%mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --%NS%mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --%NS%mat-list-list-item-selected-container-color: var(--%NS%mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2})})()}return n})();function cn(n,o,e){if(e.length){let t=o.toArray(),a=e.toArray(),p=0;for(let y=0;y<n+1;y++)t[y].group&&t[y].group===a[p]&&p++;return p}return 0}function dn(n,o,e,t){return n<e?n:n+o>e+t?Math.max(0,n-t+o):e}var Te=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[rn,E,H,py]})}return n})();var Cn=new v(`mat-select-scroll-strategy`,{providedIn:`root`,factory:()=>{let n=g(ne);return()=>xe(n)}});var Sn=new v(`MAT_SELECT_CONFIG`);var On=new v(`MatSelectTrigger`);var Ne=class{source;value;constructor(o,e){this.source=o,this.value=e}};var un=(()=>{class n{_viewportRuler=g(rt);_changeDetectorRef=g(hm);_elementRef=g(nt);_dir=g(n_,{optional:!0});_idGenerator=g(q);_renderer=g(hr);_parentFormField=g(It,{optional:!0});ngControl=g(Y,{self:!0,optional:!0});_liveAnnouncer=g(nt$1);_defaultOptions=g(Sn,{optional:!0});_animationsDisabled=Ar();_popoverLocation;_initialized=new te;_cleanupDetach;options;optionGroups;customTrigger;_positions=[{originX:`start`,originY:`bottom`,overlayX:`start`,overlayY:`top`},{originX:`end`,originY:`bottom`,overlayX:`end`,overlayY:`top`},{originX:`start`,originY:`top`,overlayX:`start`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`},{originX:`end`,originY:`top`,overlayX:`end`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`}];_scrollOptionIntoView(e){let t=this.options.toArray()[e];if(t){let a=this.panel.nativeElement,p=cn(e,this.options,this.optionGroups),y=t._getHostElement();e===0&&p===1?a.scrollTop=0:a.scrollTop=dn(y.offsetTop,y.offsetHeight,a.scrollTop,a.offsetHeight)}}_positioningSettled(){this._scrollOptionIntoView(this._keyManager.activeItemIndex||0)}_getChangeEvent(e){return new Ne(this,e)}_scrollStrategyFactory=g(Cn);_panelOpen=!1;_compareWith=(e,t)=>e===t;_uid=this._idGenerator.getId(`mat-select-`);_triggerAriaLabelledBy=null;_previousControl;_destroy=new te;_errorStateTracker;stateChanges=new te;disableAutomaticLabeling=!0;userAriaDescribedBy;_selectionModel;_keyManager;_preferredOverlayOrigin;_overlayWidth;_onChange=()=>{};_onTouched=()=>{};_valueId=this._idGenerator.getId(`mat-select-value-`);_scrollStrategy;_overlayPanelClass=this._defaultOptions?.overlayPanelClass||``;get focused(){return this._focused||this._panelOpen}_focused=!1;controlType=`mat-select`;trigger;panel;_overlayDir;panelClass;disabled=!1;get disableRipple(){return this._disableRipple()}set disableRipple(e){this._disableRipple.set(e)}_disableRipple=or(!1);tabIndex=0;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._syncParentProperties()}_hideSingleSelectionIndicator=this._defaultOptions?.hideSingleSelectionIndicator??!1;get placeholder(){return this._placeholder}set placeholder(e){this._placeholder=e,this.stateChanges.next()}_placeholder;get required(){return this._required??this.ngControl?.control?.hasValidator(Me.required)??!1}set required(e){this._required=e,this.stateChanges.next()}_required;get multiple(){return this._multiple}set multiple(e){this._selectionModel,this._multiple=e}_multiple=!1;disableOptionCentering=this._defaultOptions?.disableOptionCentering??!1;get compareWith(){return this._compareWith}set compareWith(e){this._compareWith=e,this._selectionModel&&this._initializeSelection()}get value(){return this._value}set value(e){this._assignValue(e)&&this._onChange(e)}_value;ariaLabel=``;ariaLabelledby;get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}typeaheadDebounceInterval;sortComparator;get id(){return this._id}set id(e){this._id=e||this._uid,this.stateChanges.next()}_id;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}panelWidth=this._defaultOptions&&typeof this._defaultOptions.panelWidth<`u`?this._defaultOptions.panelWidth:`auto`;canSelectNullableOptions=this._defaultOptions?.canSelectNullableOptions??!1;optionSelectionChanges=qy(()=>{let e=this.options;return e?e.changes.pipe(rv(e),ma(()=>Zy(...e.map(t=>t.onSelectionChange)))):this._initialized.pipe(ma(()=>this.optionSelectionChanges))});openedChange=new Le;_openedStream=this.openedChange.pipe(Ot(e=>e),Q(()=>{}));_closedStream=this.openedChange.pipe(Ot(e=>!e),Q(()=>{}));selectionChange=new Le;valueChange=new Le;constructor(){let e=g(li),t=g(Nt,{optional:!0}),a=g(wt,{optional:!0}),p=g(new Fs(`tabindex`),{optional:!0}),y=g(ke$1,{optional:!0}),k=g($n$1,{optional:!0,self:!0});this.ngControl&&(this.ngControl.valueAccessor=this),this._defaultOptions?.typeaheadDebounceInterval!=null&&(this.typeaheadDebounceInterval=this._defaultOptions.typeaheadDebounceInterval),this._errorStateTracker=new Ke(e,k||this.ngControl,a,t,this.stateChanges),this._scrollStrategy=this._scrollStrategyFactory(),this.tabIndex=p==null?0:parseInt(p)||0,this._popoverLocation=y?.usePopover===!1?null:`inline`,this.id=this.id}ngOnInit(){this._selectionModel=new s(this.multiple),this.stateChanges.next(),this._viewportRuler.change().pipe(ov(this._destroy)).subscribe(()=>{this.panelOpen&&(this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._changeDetectorRef.detectChanges())})}ngAfterContentInit(){this._initialized.next(),this._initialized.complete(),this._initKeyManager(),this._selectionModel.changed.pipe(ov(this._destroy)).subscribe(e=>{e.added.forEach(t=>t.select()),e.removed.forEach(t=>t.deselect())}),this.options.changes.pipe(rv(null),ov(this._destroy)).subscribe(()=>{this._resetOptions(),this._initializeSelection()})}ngDoCheck(){let e=this._getTriggerAriaLabelledby(),t=this.ngControl;if(e!==this._triggerAriaLabelledBy){let a=this._elementRef.nativeElement;this._triggerAriaLabelledBy=e,e?a.setAttribute(`aria-labelledby`,e):a.removeAttribute(`aria-labelledby`)}t&&(this._previousControl!==t.control&&(this._previousControl!==void 0&&t.disabled!==null&&t.disabled!==this.disabled&&(this.disabled=t.disabled),this._previousControl=t.control),this.updateErrorState())}ngOnChanges(e){(e.disabled||e.userAriaDescribedBy)&&this.stateChanges.next(),e.typeaheadDebounceInterval&&this._keyManager&&this._keyManager.withTypeAhead(this.typeaheadDebounceInterval),e.panelClass&&this.panelClass instanceof Set&&(this.panelClass=Array.from(this.panelClass))}ngOnDestroy(){this._cleanupDetach?.(),this._keyManager?.destroy(),this._destroy.next(),this._destroy.complete(),this.stateChanges.complete()}toggle(){this.panelOpen?this.close():this.open()}open(){this._canOpen()&&(this._parentFormField&&(this._preferredOverlayOrigin=this._parentFormField.getConnectedOverlayOrigin()),this._cleanupDetach?.(),this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._panelOpen=!0,this._overlayDir.positionChange.pipe(kt(1)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this._positioningSettled()}),this._overlayDir.attachOverlay(),this._keyManager.withHorizontalOrientation(null),this._highlightCorrectOption(),this._changeDetectorRef.markForCheck(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!0)))}close(){this._panelOpen&&(this._panelOpen=!1,this._exitAndDetach(),this._keyManager.withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`),this._changeDetectorRef.markForCheck(),this._onTouched(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!1)))}_exitAndDetach(){if(this._animationsDisabled||!this.panel){this._detachOverlay();return}this._cleanupDetach?.(),this._cleanupDetach=()=>{t(),clearTimeout(a),this._cleanupDetach=void 0};let e=this.panel.nativeElement,t=this._renderer.listen(e,`animationend`,p=>{p.animationName===`_mat-select-exit`&&(this._cleanupDetach?.(),this._detachOverlay())}),a=setTimeout(()=>{this._cleanupDetach?.(),this._detachOverlay()},200);e.classList.add(`mat-select-panel-exit`)}_detachOverlay(){this._overlayDir.detachOverlay(),this._changeDetectorRef.markForCheck()}writeValue(e){this._assignValue(e)}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck(),this.stateChanges.next()}get panelOpen(){return this._panelOpen}get selected(){return this.multiple?this._selectionModel?.selected||[]:this._selectionModel?.selected[0]}get triggerValue(){if(this.empty)return``;if(this._multiple){let e=this._selectionModel.selected.map(t=>t.viewValue);return this._isRtl()&&e.reverse(),e.join(`, `)}return this._selectionModel.selected[0].viewValue}updateErrorState(){this._errorStateTracker.updateErrorState()}_isRtl(){return this._dir?this._dir.value===`rtl`:!1}_handleKeydown(e){this.disabled||(this.panelOpen?this._handleOpenKeydown(e):this._handleClosedKeydown(e))}_handleClosedKeydown(e){let t=e.keyCode,a=t===40||t===38||t===37||t===39,p=t===13||t===32,y=this._keyManager;if(!y.isTyping()&&p&&!Re(e)||(this.multiple||e.altKey)&&a)e.preventDefault(),this.open();else if(!this.multiple){let k=this.selected;y.onKeydown(e);let f=this.selected;f&&k!==f&&this._liveAnnouncer.announce(f.viewValue,1e4)}}_handleOpenKeydown(e){let t=this._keyManager,a=e.keyCode,p=a===40||a===38,y=t.isTyping();if(p&&e.altKey)e.preventDefault(),this.close();else if(!y&&(a===13||a===32)&&t.activeItem&&!Re(e))e.preventDefault(),t.activeItem._selectViaInteraction();else if(!y&&this._multiple&&a===65&&e.ctrlKey){e.preventDefault();let k=this.options.some(f=>!f.disabled&&!f.selected);this.options.forEach(f=>{f.disabled||(k?f.select():f.deselect())})}else{let k=t.activeItemIndex;t.onKeydown(e),this._multiple&&p&&e.shiftKey&&t.activeItem&&t.activeItemIndex!==k&&t.activeItem._selectViaInteraction()}}_handleOverlayKeydown(e){e.keyCode===27&&!Re(e)&&(e.preventDefault(),this.close())}_onFocus(){this.disabled||(this._focused=!0,this.stateChanges.next())}_onBlur(){this._focused=!1,this._keyManager?.cancelTypeahead(),!this.disabled&&!this.panelOpen&&(this._onTouched(),this._changeDetectorRef.markForCheck(),this.stateChanges.next())}get empty(){return!this._selectionModel||this._selectionModel.isEmpty()}_initializeSelection(){Promise.resolve().then(()=>{this.ngControl&&(this._value=this.ngControl.value),this._setSelectionByValue(this._value),this.stateChanges.next()})}_setSelectionByValue(e){if(this.options.forEach(t=>t.setInactiveStyles()),this._selectionModel.clear(),this.multiple&&e)e.forEach(t=>this._selectOptionByValue(t)),this._sortValues();else{let t=this._selectOptionByValue(e);t?this._keyManager.updateActiveItem(t):this.panelOpen||this._keyManager.updateActiveItem(-1)}this._changeDetectorRef.markForCheck()}_selectOptionByValue(e){let t=this.options.find(a=>{if(this._selectionModel.isSelected(a))return!1;try{return(a.value!=null||this.canSelectNullableOptions)&&this._compareWith(a.value,e)}catch{return!1}});return t&&this._selectionModel.select(t),t}_assignValue(e){return e!==this._value||this._multiple&&Array.isArray(e)?(this.options&&this._setSelectionByValue(e),this._value=e,!0):!1}_skipPredicate=e=>this.panelOpen?!1:e.disabled;_getOverlayWidth(e){return this.panelWidth===`auto`?(e instanceof _e?e.elementRef:e||this._elementRef).nativeElement.getBoundingClientRect().width:this.panelWidth===null?``:this.panelWidth}_syncParentProperties(){if(this.options)for(let e of this.options)e._changeDetectorRef.markForCheck()}_initKeyManager(){this._keyManager=new X(this.options).withTypeAhead(this.typeaheadDebounceInterval).withVerticalOrientation().withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`).withHomeAndEnd().withPageUpDown().withAllowedModifierKeys([`shiftKey`]).skipPredicate(this._skipPredicate),this._keyManager.tabOut.subscribe(()=>{this.panelOpen&&(!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction(),this.focus(),this.close())}),this._keyManager.change.subscribe(()=>{this._panelOpen&&this.panel?this._scrollOptionIntoView(this._keyManager.activeItemIndex||0):!this._panelOpen&&!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction()})}_resetOptions(){let e=Zy(this.options.changes,this._destroy);this.optionSelectionChanges.pipe(ov(e)).subscribe(t=>{this._onSelect(t.source,t.isUserInput),t.isUserInput&&!this.multiple&&this._panelOpen&&(this.close(),this.focus())}),Zy(...this.options.map(t=>t._stateChanges)).pipe(ov(e)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this.stateChanges.next()})}_onSelect(e,t){let a=this._selectionModel.isSelected(e);!this.canSelectNullableOptions&&e.value==null&&!this._multiple?(e.deselect(),this._selectionModel.clear(),this.value!=null&&this._propagateChanges(e.value)):(a!==e.selected&&(e.selected?this._selectionModel.select(e):this._selectionModel.deselect(e)),t&&this._keyManager.setActiveItem(e),this.multiple&&(this._sortValues(),t&&this.focus())),a!==this._selectionModel.isSelected(e)&&this._propagateChanges(),this.stateChanges.next()}_sortValues(){if(this.multiple){let e=this.options.toArray();this._selectionModel.sort((t,a)=>this.sortComparator?this.sortComparator(t,a,e):e.indexOf(t)-e.indexOf(a)),this.stateChanges.next()}}_propagateChanges(e){let t;this.multiple?t=this.selected.map(a=>a.value):t=this.selected?this.selected.value:e,this._value=t,this.valueChange.emit(t),this._onChange(t),this.selectionChange.emit(this._getChangeEvent(t)),this._changeDetectorRef.markForCheck()}_highlightCorrectOption(){if(this._keyManager)if(this.empty){let e=-1;for(let t=0;t<this.options.length;t++)if(!this.options.get(t).disabled){e=t;break}this._keyManager.setActiveItem(e)}else this._keyManager.setActiveItem(this._selectionModel.selected[0])}_canOpen(){return!this._panelOpen&&!this.disabled&&this.options?.length>0&&!!this._overlayDir}focus(e){this._elementRef.nativeElement.focus(e)}_getPanelAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||null,t=e?e+` `:``;return this.ariaLabelledby?t+this.ariaLabelledby:e}_getAriaActiveDescendant(){return this.panelOpen&&this._keyManager&&this._keyManager.activeItem?this._keyManager.activeItem.id:null}_getTriggerAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||``;return this.ariaLabelledby&&(e+=` `+this.ariaLabelledby),e||(e=this._valueId),e}get describedByIds(){return this._elementRef.nativeElement.getAttribute(`aria-describedby`)?.split(` `)||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute(`aria-describedby`,e.join(` `)):t.removeAttribute(`aria-describedby`)}onContainerClick(e){let t=p(e);t&&(t.tagName===`MAT-OPTION`||t.classList.contains(`cdk-overlay-backdrop`)||t.closest(`.mat-mdc-select-panel`))||(this.focus(),this.open())}get shouldLabelFloat(){return this.panelOpen||!this.empty||this.focused&&!!this.placeholder}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`trigger`],t=[`panel`],a=[[[`mat-select-trigger`]],`*`],p=[`mat-select-trigger`,`*`];function y(g,v){if(g&1&&(Es(0,`span`,4),VC(1),hu()),g&2){let c=fC();YE(),Kg(c.placeholder)}}function k(g,v){g&1&&Du(0)}function f(g,v){if(g&1&&(Es(0,`span`,11),VC(1),hu()),g&2){let c=fC(2);YE(),Kg(c.triggerValue)}}function C(g,v){if(g&1&&(Es(0,`span`,5),Qw(1,k,1,0)(2,f,2,1,`span`,11),hu()),g&2){let c=fC();YE(),Xw(c.customTrigger?1:2)}}function m(g,v){if(g&1){let c=sC();Es(0,`div`,12,1),Lg(`keydown`,function(S){yf(c);let _n=fC();return vf(_n._handleKeydown(S))}),Du(2,1),hu()}if(g&2){let c=fC();Eu(c.panelClass),Rs(`mat-select-panel-animations-enabled`,!c._animationsDisabled)(`mat-primary`,c._parentFormField?.color===`primary`)(`mat-accent`,c._parentFormField?.color===`accent`)(`mat-warn`,c._parentFormField?.color===`warn`)(`mat-undefined`,!c._parentFormField?.color),Mo(`id`,c.id+`-panel`)(`aria-multiselectable`,c.multiple)(`aria-label`,c.ariaLabel||null)(`aria-labelledby`,c._getPanelAriaLabelledby())}}return _o({type:n,selectors:[[`mat-select`]],contentQueries:function(v,c,b){if(v&1&&Vg(b,On,5)(b,H,5)(b,Ie,5),v&2){let S;gC(S=mC())&&(c.customTrigger=S.first),gC(S=mC())&&(c.options=S),gC(S=mC())&&(c.optionGroups=S)}},viewQuery:function(v,c){if(v&1&&Bg(e,5)(t,5)(Zn$1,5),v&2){let b;gC(b=mC())&&(c.trigger=b.first),gC(b=mC())&&(c.panel=b.first),gC(b=mC())&&(c._overlayDir=b.first)}},hostAttrs:[`role`,`combobox`,`aria-haspopup`,`listbox`,1,`mat-mdc-select`],hostVars:21,hostBindings:function(v,c){v&1&&Lg(`keydown`,function(S){return c._handleKeydown(S)})(`focus`,function(){return c._onFocus()})(`blur`,function(){return c._onBlur()}),v&2&&(Mo(`id`,c.id)(`tabindex`,c.disabled?-1:c.tabIndex)(`aria-controls`,c.panelOpen?c.id+`-panel`:null)(`aria-expanded`,c.panelOpen)(`aria-label`,c.ariaLabel||null)(`aria-required`,c.required.toString())(`aria-disabled`,c.disabled.toString())(`aria-invalid`,c.errorState)(`aria-activedescendant`,c._getAriaActiveDescendant()),Rs(`mat-mdc-select-disabled`,c.disabled)(`mat-mdc-select-invalid`,c.errorState)(`mat-mdc-select-required`,c.required)(`mat-mdc-select-empty`,c.empty)(`mat-mdc-select-multiple`,c.multiple)(`mat-select-open`,c.panelOpen))},inputs:{userAriaDescribedBy:[0,`aria-describedby`,`userAriaDescribedBy`],panelClass:`panelClass`,disabled:[2,`disabled`,`disabled`,_u],disableRipple:[2,`disableRipple`,`disableRipple`,_u],tabIndex:[2,`tabIndex`,`tabIndex`,g=>g==null?0:Rb(g)],hideSingleSelectionIndicator:[2,`hideSingleSelectionIndicator`,`hideSingleSelectionIndicator`,_u],placeholder:`placeholder`,required:[2,`required`,`required`,_u],multiple:[2,`multiple`,`multiple`,_u],disableOptionCentering:[2,`disableOptionCentering`,`disableOptionCentering`,_u],compareWith:`compareWith`,value:`value`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],errorStateMatcher:`errorStateMatcher`,typeaheadDebounceInterval:[2,`typeaheadDebounceInterval`,`typeaheadDebounceInterval`,Rb],sortComparator:`sortComparator`,id:`id`,panelWidth:`panelWidth`,canSelectNullableOptions:[2,`canSelectNullableOptions`,`canSelectNullableOptions`,_u]},outputs:{openedChange:`openedChange`,_openedStream:`opened`,_closedStream:`closed`,selectionChange:`selectionChange`,valueChange:`valueChange`},exportAs:[`matSelect`],features:[nm([{provide:At,useExisting:n},{provide:Ee,useExisting:n}]),Nl],ngContentSelectors:p,decls:11,vars:10,consts:[[`fallbackOverlayOrigin`,`cdkOverlayOrigin`,`trigger`,``],[`panel`,``],[`cdk-overlay-origin`,``,1,`mat-mdc-select-trigger`,3,`click`],[1,`mat-mdc-select-value`],[1,`mat-mdc-select-placeholder`,`mat-mdc-select-min-line`],[1,`mat-mdc-select-value-text`],[1,`mat-mdc-select-arrow-wrapper`],[1,`mat-mdc-select-arrow`],[`viewBox`,`0 0 24 24`,`width`,`24px`,`height`,`24px`,`focusable`,`false`,`aria-hidden`,`true`],[`d`,`M7 10l5 5 5-5z`],[`cdk-connected-overlay`,``,`cdkConnectedOverlayHasBackdrop`,``,`cdkConnectedOverlayBackdropClass`,`cdk-overlay-transparent-backdrop`,3,`detach`,`backdropClick`,`overlayKeydown`,`cdkConnectedOverlayDisableClose`,`cdkConnectedOverlayPanelClass`,`cdkConnectedOverlayScrollStrategy`,`cdkConnectedOverlayOrigin`,`cdkConnectedOverlayPositions`,`cdkConnectedOverlayWidth`,`cdkConnectedOverlayFlexibleDimensions`,`cdkConnectedOverlayUsePopover`],[1,`mat-mdc-select-min-line`],[`role`,`listbox`,`tabindex`,`-1`,1,`mat-mdc-select-panel`,`mdc-menu-surface`,`mdc-menu-surface--open`,3,`keydown`]],template:function(v,c){if(v&1&&(vu(a),Es(0,`div`,2,0),Lg(`click`,function(){return c.open()}),Es(3,`div`,3),Qw(4,y,2,1,`span`,4)(5,C,3,1,`span`,5),hu(),Es(6,`div`,6)(7,`div`,7),Af(),Es(8,`svg`,8),Rg(9,`path`,9),hu()()()(),Sg(10,m,3,16,`ng-template`,10),Lg(`detach`,function(){return c.close()})(`backdropClick`,function(){return c.close()})(`overlayKeydown`,function(S){return c._handleOverlayKeydown(S)})),v&2){let b=vC(1);YE(3),Mo(`id`,c._valueId),YE(),Xw(c.empty?4:5),YE(6),xg(`cdkConnectedOverlayDisableClose`,!0)(`cdkConnectedOverlayPanelClass`,c._overlayPanelClass)(`cdkConnectedOverlayScrollStrategy`,c._scrollStrategy)(`cdkConnectedOverlayOrigin`,c._preferredOverlayOrigin||b)(`cdkConnectedOverlayPositions`,c._positions)(`cdkConnectedOverlayWidth`,c._overlayWidth)(`cdkConnectedOverlayFlexibleDimensions`,!0)(`cdkConnectedOverlayUsePopover`,c._popoverLocation)}},dependencies:[_e,Zn$1],styles:[`@keyframes _mat-select-enter {
  from {
    opacity: 0;
    transform: scaleY(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-select-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-select {
  display: inline-block;
  width: 100%;
  outline: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  color: var(--%NS%mat-select-enabled-trigger-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-select-trigger-text-font, var(--%NS%mat-sys-body-large-font));
  line-height: var(--%NS%mat-select-trigger-text-line-height, var(--%NS%mat-sys-body-large-line-height));
  font-size: var(--%NS%mat-select-trigger-text-size, var(--%NS%mat-sys-body-large-size));
  font-weight: var(--%NS%mat-select-trigger-text-weight, var(--%NS%mat-sys-body-large-weight));
  letter-spacing: var(--%NS%mat-select-trigger-text-tracking, var(--%NS%mat-sys-body-large-tracking));
}

div.mat-mdc-select-panel {
  box-shadow: var(--%NS%mat-select-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}

.mat-mdc-select-disabled {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-select-disabled .mat-mdc-select-placeholder {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-select-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}
.mat-mdc-select-disabled .mat-mdc-select-trigger {
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
}

.mat-mdc-select-value {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mat-mdc-select-value-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mat-mdc-select-arrow-wrapper {
  height: 24px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
}
.mat-form-field-appearance-fill .mdc-text-field--no-label .mat-mdc-select-arrow-wrapper {
  transform: none;
}

.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-invalid .mat-mdc-select-arrow,
.mat-form-field-invalid:not(.mat-form-field-disabled) .mat-mdc-form-field-infix::after {
  color: var(--%NS%mat-select-invalid-arrow-color, var(--%NS%mat-sys-error));
}

.mat-mdc-select-arrow {
  width: 10px;
  height: 5px;
  position: relative;
  color: var(--%NS%mat-select-enabled-arrow-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field.mat-focused .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-focused-arrow-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-disabled .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-disabled-arrow-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-select-open .mat-mdc-select-arrow {
  transform: rotate(180deg);
}
.mat-form-field-animations-enabled .mat-mdc-select-arrow {
  transition: transform 80ms linear;
}
.mat-mdc-select-arrow svg {
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (forced-colors: active) {
  .mat-mdc-select-arrow svg {
    fill: CanvasText;
  }
  .mat-mdc-select-disabled .mat-mdc-select-arrow svg {
    fill: GrayText;
  }
}

div.mat-mdc-select-panel {
  width: 100%;
  max-height: 275px;
  outline: 0;
  overflow: auto;
  padding: 8px 0;
  box-sizing: border-box;
  transform-origin: top center;
  border-radius: 0 0 4px 4px;
  position: relative;
  background-color: var(--%NS%mat-select-panel-background-color, var(--%NS%mat-sys-surface-container));
}
.mat-mdc-select-panel-above div.mat-mdc-select-panel {
  border-radius: 4px 4px 0 0;
  transform-origin: bottom center;
}
@media (forced-colors: active) {
  div.mat-mdc-select-panel {
    outline: solid 1px;
  }
}

.mat-select-panel-animations-enabled {
  animation: _mat-select-enter 120ms cubic-bezier(0, 0, 0.2, 1) forwards;
}
.mat-select-panel-animations-enabled.mat-select-panel-exit {
  animation: _mat-select-exit 100ms linear forwards;
}

.mat-mdc-select-placeholder {
  transition: color 400ms 133.3333333333ms cubic-bezier(0.25, 0.8, 0.25, 1);
  color: var(--%NS%mat-select-placeholder-text-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field:not(.mat-form-field-animations-enabled) .mat-mdc-select-placeholder, ._mat-animation-noopable .mat-mdc-select-placeholder {
  transition: none;
}
.mat-form-field-hide-placeholder .mat-mdc-select-placeholder {
  color: transparent;
  -webkit-text-fill-color: transparent;
  transition: none;
  display: block;
}

.mat-mdc-form-field-type-mat-select:not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper {
  cursor: pointer;
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mat-mdc-floating-label {
  max-width: calc(100% - 18px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mdc-floating-label--float-above {
  max-width: calc(100% / 0.75 - 24px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-notched-outline__notch {
  max-width: calc(100% - 60px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-text-field--label-floating .mdc-notched-outline__notch {
  max-width: calc(100% - 24px);
}

.mat-mdc-select-min-line:empty::before {
  content: " ";
  white-space: pre;
  width: 1px;
  display: inline-block;
  visibility: hidden;
}

.mat-form-field-appearance-fill .mat-mdc-select-arrow-wrapper {
  transform: var(--%NS%mat-select-arrow-transform, translateY(-8px));
}
`],encapsulation:2})})()}return n})();var hn=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[En$1,Te,py,ue,Vt,Te]})}return n})();var De=n=>[`/clientes`,n];var kn=()=>[`/clientes`];var wn=n=>[`/clientes`,n,`recetas`,`nueva`];var fn=(n,o)=>o.id;function En(n,o){n&1&&Rg(0,`mat-progress-bar`,1)}function In(n,o){n&1&&(VC(0,` Para `),Es(1,`strong`),VC(2),hu(),VC(3,`. Usa una receta existente como referencia. `)),n&2&&(YE(2),Kg(o.full_name))}function Tn(n,o){n&1&&VC(0,` Registra un pedido para un cliente. `)}function Nn(n,o){if(n&1&&(Es(0,`div`,6)(1,`span`,3),VC(2,`error`),hu(),Es(3,`span`),VC(4),hu()()),n&2){let e=fC();YE(4),Kg(e.error())}}function Dn(n,o){if(n&1&&(Es(0,`div`,11)(1,`span`,3),VC(2,`photo_camera_back`),hu(),Es(3,`h3`),VC(4,`Este cliente no tiene recetas`),hu(),Es(5,`p`),VC(6,`Para crear un pedido primero debes registrar la fotografía de la receta.`),hu(),Es(7,`a`,33)(8,`span`,3),VC(9,`photo_camera`),hu(),VC(10,` Registrar receta `),hu()()),n&2){let e=fC();YE(7),xg(`routerLink`,ZC(1,wn,e.id))}}function Fn(n,o){if(n&1&&VC(0),n&2){let e=fC().$implicit;Iu(` · `,e.observations,` `)}}function Pn(n,o){if(n&1&&(Es(0,`mat-option`,18),VC(1),KC(2,`date`),Qw(3,Fn,1,1),VC(4),hu()),n&2){let e=o.$implicit;xg(`value`,e.id),YE(),Iu(` `,JC(2,5,e.registered_at,`dd/MM/yyyy`),` `),YE(2),Xw(e.observations?3:-1),YE(),Xg(` (`,e.images.length,` foto`,e.images.length===1?``:`s`,`) `)}}function An(n,o){n&1&&(Es(0,`mat-error`),VC(1,`Selecciona la receta que se usará.`),hu())}function Rn(n,o){if(n&1){let e=sC();Es(0,`button`,37),Lg(`click`,function(){let a=yf(e).$implicit,p=fC(4);return vf(p.openImage(a))}),Rg(1,`app-auth-image`,38),hu()}if(n&2){let e=o.$implicit;YE(),xg(`image`,e)}}function Vn(n,o){if(n&1&&(Es(0,`div`,35),eC(1,Rn,2,1,`button`,36,fn),hu()),n&2){let e=fC();YE(),tC(e.images)}}function Ln(n,o){if(n&1&&(Es(0,`div`,19)(1,`div`,34)(2,`span`,3),VC(3,`description`),hu(),Es(4,`div`)(5,`strong`),VC(6),KC(7,`date`),hu(),Es(8,`p`,9),VC(9),hu()()(),Qw(10,Vn,3,0,`div`,35),hu()),n&2){let e=o;YE(6),Iu(`Receta del `,JC(7,3,e.registered_at,`dd/MM/yyyy`)),YE(3),Kg(e.observations||`Sin observaciones.`),YE(),Xw(e.images.length?10:-1)}}function Bn(n,o){if(n&1&&Rg(0,`option`,18),n&2){let e=o.$implicit;xg(`value`,e)}}function zn(n,o){n&1&&VC(0,` El tipo de lentes no puede superar los 100 caracteres. `)}function Gn(n,o){n&1&&VC(0,` Indica el tipo de lentes. `)}function Wn(n,o){if(n&1&&(Es(0,`mat-error`),Qw(1,zn,1,0)(2,Gn,1,0),hu()),n&2){let e=fC(2);YE(),Xw(e.form.controls.lens_type.errors?.maxlength?1:2)}}function Kn(n,o){n&1&&VC(0,` La fecha no puede ser futura. `)}function qn(n,o){n&1&&VC(0,` Selecciona la fecha del pedido. `)}function jn(n,o){if(n&1&&(Es(0,`mat-error`),Qw(1,Kn,1,0)(2,qn,1,0),hu()),n&2){let e=fC(2);YE(),Xw(e.form.controls.ordered_at.errors?.futureDate?1:2)}}function Hn(n,o){n&1&&VC(0,` El precio no puede superar Bs 999.999. `)}function Un(n,o){n&1&&VC(0,` El precio no puede ser negativo. `)}function Qn(n,o){if(n&1&&(Es(0,`mat-error`),Qw(1,Hn,1,0)(2,Un,1,0),hu()),n&2){let e=fC(2);YE(),Xw(e.form.controls.price.errors?.max?1:2)}}function Yn(n,o){n&1&&VC(0,` El adelanto no puede superar el precio total. `)}function $n(n,o){n&1&&VC(0,` El adelanto no puede superar Bs 999.999. `)}function Xn(n,o){n&1&&VC(0,` El adelanto no puede ser negativo. `)}function Jn(n,o){if(n&1&&(Es(0,`mat-error`),Qw(1,Yn,1,0)(2,$n,1,0)(3,Xn,1,0),hu()),n&2){let e=fC(2);YE(),Xw(e.form.controls.advance.errors?.exceedsPrice?1:e.form.controls.advance.errors?.max?2:3)}}function Zn(n,o){n&1&&(Es(0,`span`,41),VC(1,`El adelanto supera el precio. Corrige los montos.`),hu())}function ei(n,o){if(n&1&&(Es(0,`div`,39)(1,`span`,3),VC(2),hu(),Es(3,`div`)(4,`span`,40),VC(5,`Saldo pendiente`),hu(),Es(6,`strong`),VC(7),hu()(),Qw(8,Zn,2,0,`span`,41),hu()),n&2){let e=fC(2);Rs(`balance-box--alert`,e.advanceExceedsPrice()),YE(2),Kg(e.advanceExceedsPrice()?`warning`:`account_balance_wallet`),YE(5),Kg(e.money(e.balance())),YE(),Xw(e.advanceExceedsPrice()?8:-1)}}function ti(n,o){n&1&&(Rg(0,`span`,42),VC(1,` Registrando… `))}function ni(n,o){n&1&&(Es(0,`span`,3),VC(1,`add_shopping_cart`),hu(),VC(2,` Registrar pedido `))}function ii(n,o){if(n&1){let e=sC();Es(0,`div`,7)(1,`span`,8),VC(2),hu(),Es(3,`div`)(4,`strong`),VC(5),hu(),Es(6,`span`,9),VC(7),hu()(),Es(8,`a`,10),VC(9,`Ver ficha`),hu()(),Qw(10,Dn,11,3,`div`,11),Es(11,`div`,12)(12,`form`,13),Lg(`ngSubmit`,function(){yf(e);let a=fC();return vf(a.submit())}),Es(13,`p`,14),VC(14,`Los campos con * son obligatorios.`),hu(),Es(15,`div`,15)(16,`mat-form-field`,16)(17,`mat-label`),VC(18,`Receta utilizada`),hu(),Es(19,`mat-select`,17),VI(),eC(20,Pn,5,8,`mat-option`,18,fn),hu(),Es(22,`mat-hint`),VC(23,`Receta que respalda las medidas de este pedido.`),hu(),Qw(24,An,2,0,`mat-error`),hu(),Qw(25,Ln,11,6,`div`,19),Es(26,`mat-form-field`,20)(27,`mat-label`),VC(28,`Tipo de lentes`),hu(),Es(29,`input`,21),VI(),hu(),Es(30,`mat-icon`,22),VC(31,`visibility`),hu(),Es(32,`mat-hint`),VC(33,`Elige una opción o escribe el tipo exacto.`),hu(),Es(34,`datalist`,23),eC(35,Bn,1,1,`option`,18,Jw),hu(),Qw(37,Wn,3,1,`mat-error`),hu(),Es(38,`mat-form-field`,20)(39,`mat-label`),VC(40,`Fecha del pedido`),hu(),Es(41,`input`,24),VI(),hu(),Es(42,`mat-hint`),VC(43,`No puede ser una fecha futura.`),hu(),Qw(44,jn,3,1,`mat-error`),hu(),Es(45,`mat-form-field`,20)(46,`mat-label`),VC(47,`Precio total (opcional)`),hu(),Es(48,`span`,22),VC(49,`Bs\xA0`),hu(),Es(50,`input`,25),VI(),hu(),Es(51,`mat-hint`),VC(52,`Opcional. Si lo registras, se calcula el saldo.`),hu(),Qw(53,Qn,3,1,`mat-error`),hu(),Es(54,`mat-form-field`,20)(55,`mat-label`),VC(56,`Adelanto (opcional)`),hu(),Es(57,`span`,22),VC(58,`Bs\xA0`),hu(),Es(59,`input`,26),VI(),hu(),Es(60,`mat-hint`),VC(61,`Opcional. No puede superar el precio total.`),hu(),Qw(62,Jn,4,1,`mat-error`),hu(),Qw(63,ei,9,5,`div`,27),Es(64,`mat-form-field`,16)(65,`mat-label`),VC(66,`Observaciones del pedido (opcional)`),hu(),Es(67,`textarea`,28),VI(),hu(),Es(68,`mat-hint`),VC(69,`Opcional: detalles del tratamiento, montura o fecha prometida.`),hu(),Es(70,`mat-hint`,29),VC(71),hu()()(),Es(72,`div`,30)(73,`button`,31),Qw(74,ti,2,0)(75,ni,3,0),hu(),Es(76,`a`,32),VC(77,`Cancelar`),hu()()()()}if(n&2){let e,t=o,a=fC();YE(2),Kg(t.full_name.charAt(0)),YE(3),Kg(t.full_name),YE(2),Kg(t.phone),YE(),xg(`routerLink`,ZC(18,De,t.id)),YE(2),Xw(a.prescriptions.length===0?10:-1),YE(2),xg(`formGroup`,a.form),YE(7),HI(),YE(),tC(a.prescriptions),YE(4),Xw(a.form.controls.prescription_id.touched&&a.form.controls.prescription_id.invalid?24:-1),YE(),Xw((e=a.selectedPrescription())?25:-1,e),YE(4),HI(),YE(6),tC(a.lensTypes),YE(2),Xw(a.form.controls.lens_type.touched&&a.form.controls.lens_type.invalid?37:-1),YE(4),xg(`max`,a.today),HI(),YE(3),Xw(a.form.controls.ordered_at.touched&&a.form.controls.ordered_at.invalid?44:-1),YE(6),HI(),YE(3),Xw(a.form.controls.price.touched&&a.form.controls.price.invalid?53:-1),YE(6),HI(),YE(3),Xw(a.form.controls.advance.touched&&a.form.controls.advance.invalid?62:-1),YE(),Xw(a.balance()!==null?63:-1),YE(4),HI(),YE(4),Iu(``,a.form.controls.observations.value?.length||0,` / 2000`),YE(2),xg(`disabled`,a.saving()||a.prescriptions.length===0),YE(),Xw(a.saving()?74:75),YE(2),xg(`routerLink`,ZC(20,De,t.id))}}var gn=class n{fb=g(Wr);clients=g(g$1);orders=g(m);toast=g(Pn$1);route=g(B);router=g(G);dialog=g(Ft);destroyRef=g(he);client=or(null);loading=or(!0);saving=or(!1);error=or(null);today=f();lensTypes=[`Monofocal`,`Bifocal`,`Progresivo`,`Ocupacional`,`Fotocromático`,`Antirreflejo`,`Lentes de sol`,`Otro`];form=this.fb.group({prescription_id:[null,[Me.required]],lens_type:[``,[Me.required,Me.maxLength(100),ts]],observations:[``,[Me.maxLength(2e3)]],price:[null,[Me.min(0),Me.max(999999)]],advance:[null,[Me.min(0),Me.max(999999)]],ordered_at:[f(),[Me.required,is]]});constructor(){this.form.controls.price.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError()),this.form.controls.advance.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError())}ngOnInit(){let o=Number(this.route.snapshot.queryParamMap.get(`clientId`)),e=Number(this.route.snapshot.queryParamMap.get(`prescriptionId`));if(!o){this.toast.info(rU.orders.selectClientFirst),this.router.navigate([`/clientes`]);return}this.clients.get(o).subscribe({next:t=>{this.client.set(t.data),this.loading.set(!1);let a=t.data.prescriptions??[],p=a.find(y=>y.id===e);p?this.form.controls.prescription_id.setValue(p.id):a.length===1&&this.form.controls.prescription_id.setValue(a[0].id)},error:t=>{this.loading.set(!1),this.error.set(Gr(t,rU.clients.loadFallback))}})}get prescriptions(){return this.client()?.prescriptions??[]}selectedPrescription(){let o=this.form.controls.prescription_id.value;return this.prescriptions.find(e=>e.id===o)??null}balance(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o==null?null:Math.round((Number(o)-Number(e??0))*100)/100}syncAdvanceError(){let o=this.form.controls.advance,e=o.errors??{};if(this.advanceExceedsPrice()){o.setErrors(G$1(V({},e),{exceedsPrice:!0}));return}if(e.exceedsPrice){let t=V({},e);delete t.exceedsPrice,o.setErrors(Object.keys(t).length>0?t:null)}}advanceExceedsPrice(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o!==null&&e!==null&&Number(e)>Number(o)}money(o){return l(o)}openImage(o,e){this.dialog.open(A,{data:{image:o,title:e},width:`min(1000px, 94vw)`,maxWidth:`94vw`,panelClass:`app-dialog`,autoFocus:!1})}submit(){let o=this.client();if(!o)return;if(this.prescriptions.length===0){this.error.set(rU.orders.noPrescription);return}if(this.form.invalid){this.form.markAllAsTouched();return}if(this.advanceExceedsPrice()){this.error.set(rU.orders.advanceExceedsPrice);return}let e=this.form.getRawValue();this.saving.set(!0),this.error.set(null),this.orders.create({client_id:o.id,prescription_id:Number(e.prescription_id),lens_type:(e.lens_type??``).trim(),observations:e.observations?.trim()||null,price:e.price===null?null:Number(e.price),advance:e.advance===null?null:Number(e.advance),ordered_at:e.ordered_at??f()}).subscribe({next:t=>{this.saving.set(!1),this.toast.success(rU.orders.createSuccess(t.data.id)),this.router.navigate([`/pedidos`,t.data.id])},error:t=>{this.saving.set(!1),this.error.set(Gr(t,rU.orders.createFallback))}})}static ɵfac=function(e){return new(e||n)};static ɵcmp=_o({type:n,selectors:[[`app-order-form`]],decls:15,vars:8,consts:[[1,`page`,`page--narrow`],[`mode`,`indeterminate`,1,`loading-bar`],[1,`back-link`,3,`routerLink`],[1,`material-icons`],[1,`page-header`],[1,`page-header__text`],[1,`banner`,`banner--danger`,2,`margin-bottom`,`14px`],[1,`card`,`client-summary`],[1,`client-summary__avatar`],[1,`muted`,`small`],[1,`btn`,`btn--ghost`,`btn--sm`,3,`routerLink`],[1,`empty-state`,2,`margin-bottom`,`14px`],[1,`card`],[1,`stack`,3,`ngSubmit`,`formGroup`],[1,`form-required-note`],[1,`form-grid`],[`appearance`,`outline`,1,`full`],[`formControlName`,`prescription_id`,`placeholder`,`Selecciona una receta`],[3,`value`],[1,`prescription-summary`,`full`],[`appearance`,`outline`],[`matInput`,``,`formControlName`,`lens_type`,`list`,`lensTypes`,`maxlength`,`100`,`placeholder`,`Ej. Progresivo`],[`matPrefix`,``],[`id`,`lensTypes`],[`matInput`,``,`type`,`date`,`formControlName`,`ordered_at`,3,`max`],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`price`,`inputmode`,`decimal`],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`advance`,`inputmode`,`decimal`],[1,`balance-box`,`full`,3,`balance-box--alert`],[`matInput`,``,`rows`,`3`,`maxlength`,`2000`,`formControlName`,`observations`,`placeholder`,`Ej. Tratamiento antirreflejo, montura elegida, fecha prometida…`],[`align`,`end`],[1,`form-actions`],[`type`,`submit`,1,`btn`,`btn--primary`,`btn--lg`,3,`disabled`],[1,`btn`,`btn--outline`,`btn--lg`,3,`routerLink`],[1,`btn`,`btn--primary`,2,`margin-top`,`14px`,3,`routerLink`],[1,`prescription-summary__info`],[1,`prescription-summary__photos`],[`type`,`button`,1,`photo-thumb`],[`type`,`button`,1,`photo-thumb`,3,`click`],[3,`image`],[1,`balance-box`,`full`],[1,`small`,`muted`],[1,`small`],[1,`spinner`]],template:function(e,t){if(e&1&&(Es(0,`div`,0),Qw(1,En,1,0,`mat-progress-bar`,1),Es(2,`a`,2)(3,`span`,3),VC(4,`arrow_back`),hu(),VC(5,` Volver a la ficha del cliente `),hu(),Es(6,`header`,4)(7,`div`,5)(8,`h1`),VC(9,`Nuevo pedido`),hu(),Es(10,`p`),Qw(11,In,4,1)(12,Tn,1,0),hu()()(),Qw(13,Nn,5,1,`div`,6),Qw(14,ii,78,22),hu()),e&2){let a,p;YE(),Xw(t.loading()?1:-1),YE(),xg(`routerLink`,t.client()?ZC(5,De,t.client()?.id):qC(7,kn)),YE(9),Xw((a=t.client())?11:12,a),YE(2),Xw(t.error()?13:-1),YE(),Xw((p=t.client())?14:-1,p)}},dependencies:[Vm,Kr,Ur,qr,$r,vn,or$1,Br,Hr,ji,Pi,Ti,wt,sr,ua,di,Vt,ri,Dt,Ft$1,mr,hr$1,Ja,Qa,hn,un,H,tU,eU,jr,Fr,u,rT],styles:[`.page--narrow[_ngcontent-%COMP%]{max-width:900px}.back-link[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:5px;color:var(--%NS%optic-primary-dark);font-weight:600;font-size:.82rem;margin-bottom:10px;text-decoration:none}.back-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.back-link[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}.client-summary[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:14px 18px;margin-bottom:14px}.client-summary__avatar[_ngcontent-%COMP%]{width:42px;height:42px;border-radius:12px;background:#def5f5;color:#007171;display:grid;place-items:center;font-weight:800;text-transform:uppercase;flex-shrink:0}.client-summary[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1;min-width:0}.client-summary[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.95rem}.prescription-summary[_ngcontent-%COMP%]{background:#f7fbfb;border:1px solid #e4efef;border-radius:12px;padding:12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}.prescription-summary__info[_ngcontent-%COMP%]{display:flex;gap:9px;align-items:flex-start;flex:1;min-width:200px}.prescription-summary__info[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary);font-size:21px;margin-top:1px}.prescription-summary__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.86rem}.prescription-summary__info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-top:2px}.prescription-summary__photos[_ngcontent-%COMP%]{display:flex;gap:7px;flex-wrap:wrap}.prescription-summary__photos[_ngcontent-%COMP%]   .photo-thumb[_ngcontent-%COMP%]{width:62px;height:52px;aspect-ratio:auto}.balance-box[_ngcontent-%COMP%]{display:flex;align-items:center;gap:11px;background:#f1fafa;border:1px solid #dcefee;border-radius:12px;padding:11px 14px}.balance-box[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary-dark);font-size:24px}.balance-box[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column}.balance-box[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:1.15rem;color:#164040}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:auto;text-align:right}.balance-box--alert[_ngcontent-%COMP%]{background:var(--%NS%optic-danger-soft);border-color:#f3cccc}.balance-box--alert[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%], .balance-box--alert[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--%NS%optic-danger)}.spinner[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:_ngcontent-%COMP%_spin .7s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}@media(max-width:720px){.form-actions[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}}@media(max-width:599px){.balance-box[_ngcontent-%COMP%]{flex-wrap:wrap}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:0;flex-basis:100%;text-align:left}}`]})};export{gn as OrderFormComponent};