import{$n as zC,$t as gf,At as ZC,Bn as tm,C as Fe,Cn as nv,E as GT,En as or,Et as Xe,F as Kg,Fn as qy,Ft as _2,G as Nb,Gt as eT,H as Mf,Hn as v,I as Kw,It as _g,J as Ot,Jn as xg,Jt as fl,Kn as wt,Ln as rv,M as JT,N as Jw,Nn as pm,Nt as Zi,O as Gy,Ot as Xw,Pt as Zw,Qn as yl,R as Lg,S as Es,Sn as nt,W as Mu,Wn as vl,X as PC,Xt as g,Yt as fy,Z as PI,_n as ml,_t as VI,bt as W,ct as Rt,d as Ag,en as hC,et as Q,ft as So,gt as V,h as Cl,ht as To,i as ua,in as hr,it as Qw,j as J2,jn as pe,jt as ZE,kn as pC,ln as kg,mn as ma,n as G,nn as hf,on as jg,pn as mC,r as di,rt as Qg,sn as jm,st as Rs,t as B,tt as QC,un as lC,v as Dl,vt as Vg,w as Fs,wn as oC,wt as X2,xn as ne,xt as WC,zn as te}from"./main-7GRNA55A.js";import{t as m}from"./chunk-D4XK0BTW.js";import{n as Fr,o as Wr,r as Lr,t as Er}from"./chunk-D0_iMdnJ.js";import{n as S,r as s,t as E}from"./chunk-BsYZI_Aa.js";import{n as U}from"./chunk-DzPnPQJa.js";import"./chunk-Dp0WzdZ5.js";import{b as q,h as X,l as Re,v as nt$1,y as p}from"./chunk-DeIkbxSl.js";import{D as ye,S as rt,T as we,b as nn,d as _e,o as Nn$1,p as da,s as On,u as Un$1,x as on,y as me}from"./chunk-CaBvzpX-.js";import{n as Ft}from"./chunk-IwrZ0X4n.js";import{n as _,t as T}from"./chunk-BQrB8KHK.js";import{C as hr$1,D as mr,E as li,F as ts,I as vn,L as wt$1,M as ri,P as sr,T as ji,_ as Ti,a as Dt,b as Wr$1,c as It,d as Kr,f as Me$1,g as Qa,h as Pi,i as Br,j as qr,k as or$1,l as Ja,m as Nt,n as $r,o as Ft$1,r as At,s as Hr,t as $n$1,u as Ke,v as Ur,w as is,x as Y,y as Vt}from"./chunk-CKBCQ-z1.js";import{n as o,t as c}from"./chunk-DE7w8o4j.js";import{t as g$1}from"./chunk-Bwu3vnqr.js";var ke=new v(`MAT_OPTION_PARENT_COMPONENT`);var Ee=new v(`MatOptgroup`);var Me=class{source;isUserInput;constructor(o,e=!1){this.source=o,this.isUserInput=e}};var j=(()=>{class n{_element=g(nt);_changeDetectorRef=g(pm);_parent=g(ke,{optional:!0});group=g(Ee,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue=``;get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=g(q).getId(`mat-option-`);get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=or(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new Fe;_text;_stateChanges=new te;constructor(){let e=g(GT);e.load(nn),e.load(_2),this._signalDisableRipple=!!this._parent&&Zi(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||``).trim()}select(e=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}deselect(e=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}focus(e,t){let a=this._getHostElement();typeof a.focus==`function`&&a.focus(t)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!Re(e)&&(this._selectViaInteraction(),e.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?`-1`:`0`}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let e=this.viewValue;e!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=e)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(e=!1){this.onSelectionChange.emit(new Me(this,e))}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`text`],t=[[[`mat-icon`]],`*`],a=[`mat-icon`,`*`];function p(f,C){if(f&1&&xg(0,`mat-pseudo-checkbox`,1),f&2){let m=lC();Ag(`disabled`,m.disabled)(`state`,m.selected?`checked`:`unchecked`)}}function y(f,C){if(f&1&&xg(0,`mat-pseudo-checkbox`,3),f&2){let m=lC();Ag(`disabled`,m.disabled)}}function w(f,C){if(f&1&&(Es(0,`span`,4),PC(1),fl()),f&2){let m=lC();ZE(),Dl(`(`,m.group.label,`)`)}}return To({type:n,selectors:[[`mat-option`]],viewQuery:function(C,m){if(C&1&&Vg(e,7),C&2){let g;pC(g=hC())&&(m._text=g.first)}},hostAttrs:[`role`,`option`,1,`mat-mdc-option`,`mdc-list-item`],hostVars:11,hostBindings:function(C,m){C&1&&Lg(`click`,function(){return m._selectViaInteraction()})(`keydown`,function(v){return m._handleKeydown(v)}),C&2&&(kg(`id`,m.id),So(`aria-selected`,m.selected)(`aria-disabled`,m.disabled.toString()),Rs(`mdc-list-item--selected`,m.selected)(`mat-mdc-option-multiple`,m.multiple)(`mat-mdc-option-active`,m.active)(`mdc-list-item--disabled`,m.disabled))},inputs:{value:`value`,id:`id`,disabled:[2,`disabled`,`disabled`,Cl]},outputs:{onSelectionChange:`onSelectionChange`},exportAs:[`matOption`],ngContentSelectors:a,decls:8,vars:5,consts:[[`text`,``],[`aria-hidden`,`true`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`,`state`],[1,`mdc-list-item__primary-text`],[`state`,`checked`,`aria-hidden`,`true`,`appearance`,`minimal`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`],[1,`cdk-visually-hidden`],[`aria-hidden`,`true`,`mat-ripple`,``,1,`mat-mdc-option-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`]],template:function(C,m){C&1&&(ml(t),Zw(0,p,1,2,`mat-pseudo-checkbox`,1),yl(1),Es(2,`span`,2,0),yl(4,1),fl(),Zw(5,y,1,1,`mat-pseudo-checkbox`,3),Zw(6,w,2,1,`span`,4),xg(7,`div`,5)),C&2&&(Qw(m.multiple?0:-1),ZE(5),Qw(!m.multiple&&m.selected&&!m.hideSingleSelectionIndicator?5:-1),ZE(),Qw(m.group&&m.group._inert?6:-1),ZE(),Ag(`matRippleTrigger`,m._getHostElement())(`matRippleDisabled`,m.disabled||m.disableRipple))},dependencies:[S,da],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--%NS%mat-option-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-option-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-option-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-option-label-text-size, var(--%NS%mat-sys-body-large-size));
  letter-spacing: var(--%NS%mat-option-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-option-label-text-weight, var(--%NS%mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--%NS%mat-option-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--%NS%mat-option-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--%NS%mat-option-selected-state-layer-color, var(--%NS%mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --%NS%mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --%NS%mat-list-list-item-selected-container-color: var(--%NS%mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2})})()}return n})();function sn(n,o,e){if(e.length){let t=o.toArray(),a=e.toArray(),p=0;for(let y=0;y<n+1;y++)t[y].group&&t[y].group===a[p]&&p++;return p}return 0}function cn(n,o,e,t){return n<e?n:n+o>e+t?Math.max(0,n-t+o):e}var Ie=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=wt({type:n});static ɵinj=Xe({imports:[on,E,j,fy]})}return n})();var xn=new v(`mat-select-scroll-strategy`,{providedIn:`root`,factory:()=>{let n=g(ne);return()=>_e(n)}});var Cn=new v(`MAT_SELECT_CONFIG`);var Sn=new v(`MatSelectTrigger`);var Ne=class{source;value;constructor(o,e){this.source=o,this.value=e}};var pn=(()=>{class n{_viewportRuler=g(rt);_changeDetectorRef=g(pm);_elementRef=g(nt);_dir=g(JT,{optional:!0});_idGenerator=g(q);_renderer=g(hr);_parentFormField=g(It,{optional:!0});ngControl=g(Y,{self:!0,optional:!0});_liveAnnouncer=g(nt$1);_defaultOptions=g(Cn,{optional:!0});_animationsDisabled=Er();_popoverLocation;_initialized=new te;_cleanupDetach;options;optionGroups;customTrigger;_positions=[{originX:`start`,originY:`bottom`,overlayX:`start`,overlayY:`top`},{originX:`end`,originY:`bottom`,overlayX:`end`,overlayY:`top`},{originX:`start`,originY:`top`,overlayX:`start`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`},{originX:`end`,originY:`top`,overlayX:`end`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`}];_scrollOptionIntoView(e){let t=this.options.toArray()[e];if(t){let a=this.panel.nativeElement,p=sn(e,this.options,this.optionGroups),y=t._getHostElement();e===0&&p===1?a.scrollTop=0:a.scrollTop=cn(y.offsetTop,y.offsetHeight,a.scrollTop,a.offsetHeight)}}_positioningSettled(){this._scrollOptionIntoView(this._keyManager.activeItemIndex||0)}_getChangeEvent(e){return new Ne(this,e)}_scrollStrategyFactory=g(xn);_panelOpen=!1;_compareWith=(e,t)=>e===t;_uid=this._idGenerator.getId(`mat-select-`);_triggerAriaLabelledBy=null;_previousControl;_destroy=new te;_errorStateTracker;stateChanges=new te;disableAutomaticLabeling=!0;userAriaDescribedBy;_selectionModel;_keyManager;_preferredOverlayOrigin;_overlayWidth;_onChange=()=>{};_onTouched=()=>{};_valueId=this._idGenerator.getId(`mat-select-value-`);_scrollStrategy;_overlayPanelClass=this._defaultOptions?.overlayPanelClass||``;get focused(){return this._focused||this._panelOpen}_focused=!1;controlType=`mat-select`;trigger;panel;_overlayDir;panelClass;disabled=!1;get disableRipple(){return this._disableRipple()}set disableRipple(e){this._disableRipple.set(e)}_disableRipple=or(!1);tabIndex=0;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._syncParentProperties()}_hideSingleSelectionIndicator=this._defaultOptions?.hideSingleSelectionIndicator??!1;get placeholder(){return this._placeholder}set placeholder(e){this._placeholder=e,this.stateChanges.next()}_placeholder;get required(){return this._required??this.ngControl?.control?.hasValidator(Me$1.required)??!1}set required(e){this._required=e,this.stateChanges.next()}_required;get multiple(){return this._multiple}set multiple(e){this._selectionModel,this._multiple=e}_multiple=!1;disableOptionCentering=this._defaultOptions?.disableOptionCentering??!1;get compareWith(){return this._compareWith}set compareWith(e){this._compareWith=e,this._selectionModel&&this._initializeSelection()}get value(){return this._value}set value(e){this._assignValue(e)&&this._onChange(e)}_value;ariaLabel=``;ariaLabelledby;get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}typeaheadDebounceInterval;sortComparator;get id(){return this._id}set id(e){this._id=e||this._uid,this.stateChanges.next()}_id;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}panelWidth=this._defaultOptions&&typeof this._defaultOptions.panelWidth<`u`?this._defaultOptions.panelWidth:`auto`;canSelectNullableOptions=this._defaultOptions?.canSelectNullableOptions??!1;optionSelectionChanges=Gy(()=>{let e=this.options;return e?e.changes.pipe(nv(e),ma(()=>qy(...e.map(t=>t.onSelectionChange)))):this._initialized.pipe(ma(()=>this.optionSelectionChanges))});openedChange=new Fe;_openedStream=this.openedChange.pipe(Rt(e=>e),Q(()=>{}));_closedStream=this.openedChange.pipe(Rt(e=>!e),Q(()=>{}));selectionChange=new Fe;valueChange=new Fe;constructor(){let e=g(li),t=g(Nt,{optional:!0}),a=g(wt$1,{optional:!0}),p=g(new Fs(`tabindex`),{optional:!0}),y=g(we,{optional:!0}),w=g($n$1,{optional:!0,self:!0});this.ngControl&&(this.ngControl.valueAccessor=this),this._defaultOptions?.typeaheadDebounceInterval!=null&&(this.typeaheadDebounceInterval=this._defaultOptions.typeaheadDebounceInterval),this._errorStateTracker=new Ke(e,w||this.ngControl,a,t,this.stateChanges),this._scrollStrategy=this._scrollStrategyFactory(),this.tabIndex=p==null?0:parseInt(p)||0,this._popoverLocation=y?.usePopover===!1?null:`inline`,this.id=this.id}ngOnInit(){this._selectionModel=new s(this.multiple),this.stateChanges.next(),this._viewportRuler.change().pipe(rv(this._destroy)).subscribe(()=>{this.panelOpen&&(this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._changeDetectorRef.detectChanges())})}ngAfterContentInit(){this._initialized.next(),this._initialized.complete(),this._initKeyManager(),this._selectionModel.changed.pipe(rv(this._destroy)).subscribe(e=>{e.added.forEach(t=>t.select()),e.removed.forEach(t=>t.deselect())}),this.options.changes.pipe(nv(null),rv(this._destroy)).subscribe(()=>{this._resetOptions(),this._initializeSelection()})}ngDoCheck(){let e=this._getTriggerAriaLabelledby(),t=this.ngControl;if(e!==this._triggerAriaLabelledBy){let a=this._elementRef.nativeElement;this._triggerAriaLabelledBy=e,e?a.setAttribute(`aria-labelledby`,e):a.removeAttribute(`aria-labelledby`)}t&&(this._previousControl!==t.control&&(this._previousControl!==void 0&&t.disabled!==null&&t.disabled!==this.disabled&&(this.disabled=t.disabled),this._previousControl=t.control),this.updateErrorState())}ngOnChanges(e){(e.disabled||e.userAriaDescribedBy)&&this.stateChanges.next(),e.typeaheadDebounceInterval&&this._keyManager&&this._keyManager.withTypeAhead(this.typeaheadDebounceInterval),e.panelClass&&this.panelClass instanceof Set&&(this.panelClass=Array.from(this.panelClass))}ngOnDestroy(){this._cleanupDetach?.(),this._keyManager?.destroy(),this._destroy.next(),this._destroy.complete(),this.stateChanges.complete()}toggle(){this.panelOpen?this.close():this.open()}open(){this._canOpen()&&(this._parentFormField&&(this._preferredOverlayOrigin=this._parentFormField.getConnectedOverlayOrigin()),this._cleanupDetach?.(),this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._panelOpen=!0,this._overlayDir.positionChange.pipe(Ot(1)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this._positioningSettled()}),this._overlayDir.attachOverlay(),this._keyManager.withHorizontalOrientation(null),this._highlightCorrectOption(),this._changeDetectorRef.markForCheck(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!0)))}close(){this._panelOpen&&(this._panelOpen=!1,this._exitAndDetach(),this._keyManager.withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`),this._changeDetectorRef.markForCheck(),this._onTouched(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!1)))}_exitAndDetach(){if(this._animationsDisabled||!this.panel){this._detachOverlay();return}this._cleanupDetach?.(),this._cleanupDetach=()=>{t(),clearTimeout(a),this._cleanupDetach=void 0};let e=this.panel.nativeElement,t=this._renderer.listen(e,`animationend`,p=>{p.animationName===`_mat-select-exit`&&(this._cleanupDetach?.(),this._detachOverlay())}),a=setTimeout(()=>{this._cleanupDetach?.(),this._detachOverlay()},200);e.classList.add(`mat-select-panel-exit`)}_detachOverlay(){this._overlayDir.detachOverlay(),this._changeDetectorRef.markForCheck()}writeValue(e){this._assignValue(e)}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck(),this.stateChanges.next()}get panelOpen(){return this._panelOpen}get selected(){return this.multiple?this._selectionModel?.selected||[]:this._selectionModel?.selected[0]}get triggerValue(){if(this.empty)return``;if(this._multiple){let e=this._selectionModel.selected.map(t=>t.viewValue);return this._isRtl()&&e.reverse(),e.join(`, `)}return this._selectionModel.selected[0].viewValue}updateErrorState(){this._errorStateTracker.updateErrorState()}_isRtl(){return this._dir?this._dir.value===`rtl`:!1}_handleKeydown(e){this.disabled||(this.panelOpen?this._handleOpenKeydown(e):this._handleClosedKeydown(e))}_handleClosedKeydown(e){let t=e.keyCode,a=t===40||t===38||t===37||t===39,p=t===13||t===32,y=this._keyManager;if(!y.isTyping()&&p&&!Re(e)||(this.multiple||e.altKey)&&a)e.preventDefault(),this.open();else if(!this.multiple){let w=this.selected;y.onKeydown(e);let f=this.selected;f&&w!==f&&this._liveAnnouncer.announce(f.viewValue,1e4)}}_handleOpenKeydown(e){let t=this._keyManager,a=e.keyCode,p=a===40||a===38,y=t.isTyping();if(p&&e.altKey)e.preventDefault(),this.close();else if(!y&&(a===13||a===32)&&t.activeItem&&!Re(e))e.preventDefault(),t.activeItem._selectViaInteraction();else if(!y&&this._multiple&&a===65&&e.ctrlKey){e.preventDefault();let w=this.options.some(f=>!f.disabled&&!f.selected);this.options.forEach(f=>{f.disabled||(w?f.select():f.deselect())})}else{let w=t.activeItemIndex;t.onKeydown(e),this._multiple&&p&&e.shiftKey&&t.activeItem&&t.activeItemIndex!==w&&t.activeItem._selectViaInteraction()}}_handleOverlayKeydown(e){e.keyCode===27&&!Re(e)&&(e.preventDefault(),this.close())}_onFocus(){this.disabled||(this._focused=!0,this.stateChanges.next())}_onBlur(){this._focused=!1,this._keyManager?.cancelTypeahead(),!this.disabled&&!this.panelOpen&&(this._onTouched(),this._changeDetectorRef.markForCheck(),this.stateChanges.next())}get empty(){return!this._selectionModel||this._selectionModel.isEmpty()}_initializeSelection(){Promise.resolve().then(()=>{this.ngControl&&(this._value=this.ngControl.value),this._setSelectionByValue(this._value),this.stateChanges.next()})}_setSelectionByValue(e){if(this.options.forEach(t=>t.setInactiveStyles()),this._selectionModel.clear(),this.multiple&&e)e.forEach(t=>this._selectOptionByValue(t)),this._sortValues();else{let t=this._selectOptionByValue(e);t?this._keyManager.updateActiveItem(t):this.panelOpen||this._keyManager.updateActiveItem(-1)}this._changeDetectorRef.markForCheck()}_selectOptionByValue(e){let t=this.options.find(a=>{if(this._selectionModel.isSelected(a))return!1;try{return(a.value!=null||this.canSelectNullableOptions)&&this._compareWith(a.value,e)}catch{return!1}});return t&&this._selectionModel.select(t),t}_assignValue(e){return e!==this._value||this._multiple&&Array.isArray(e)?(this.options&&this._setSelectionByValue(e),this._value=e,!0):!1}_skipPredicate=e=>this.panelOpen?!1:e.disabled;_getOverlayWidth(e){return this.panelWidth===`auto`?(e instanceof ye?e.elementRef:e||this._elementRef).nativeElement.getBoundingClientRect().width:this.panelWidth===null?``:this.panelWidth}_syncParentProperties(){if(this.options)for(let e of this.options)e._changeDetectorRef.markForCheck()}_initKeyManager(){this._keyManager=new X(this.options).withTypeAhead(this.typeaheadDebounceInterval).withVerticalOrientation().withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`).withHomeAndEnd().withPageUpDown().withAllowedModifierKeys([`shiftKey`]).skipPredicate(this._skipPredicate),this._keyManager.tabOut.subscribe(()=>{this.panelOpen&&(!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction(),this.focus(),this.close())}),this._keyManager.change.subscribe(()=>{this._panelOpen&&this.panel?this._scrollOptionIntoView(this._keyManager.activeItemIndex||0):!this._panelOpen&&!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction()})}_resetOptions(){let e=qy(this.options.changes,this._destroy);this.optionSelectionChanges.pipe(rv(e)).subscribe(t=>{this._onSelect(t.source,t.isUserInput),t.isUserInput&&!this.multiple&&this._panelOpen&&(this.close(),this.focus())}),qy(...this.options.map(t=>t._stateChanges)).pipe(rv(e)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this.stateChanges.next()})}_onSelect(e,t){let a=this._selectionModel.isSelected(e);!this.canSelectNullableOptions&&e.value==null&&!this._multiple?(e.deselect(),this._selectionModel.clear(),this.value!=null&&this._propagateChanges(e.value)):(a!==e.selected&&(e.selected?this._selectionModel.select(e):this._selectionModel.deselect(e)),t&&this._keyManager.setActiveItem(e),this.multiple&&(this._sortValues(),t&&this.focus())),a!==this._selectionModel.isSelected(e)&&this._propagateChanges(),this.stateChanges.next()}_sortValues(){if(this.multiple){let e=this.options.toArray();this._selectionModel.sort((t,a)=>this.sortComparator?this.sortComparator(t,a,e):e.indexOf(t)-e.indexOf(a)),this.stateChanges.next()}}_propagateChanges(e){let t;this.multiple?t=this.selected.map(a=>a.value):t=this.selected?this.selected.value:e,this._value=t,this.valueChange.emit(t),this._onChange(t),this.selectionChange.emit(this._getChangeEvent(t)),this._changeDetectorRef.markForCheck()}_highlightCorrectOption(){if(this._keyManager)if(this.empty){let e=-1;for(let t=0;t<this.options.length;t++)if(!this.options.get(t).disabled){e=t;break}this._keyManager.setActiveItem(e)}else this._keyManager.setActiveItem(this._selectionModel.selected[0])}_canOpen(){return!this._panelOpen&&!this.disabled&&this.options?.length>0&&!!this._overlayDir}focus(e){this._elementRef.nativeElement.focus(e)}_getPanelAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||null,t=e?e+` `:``;return this.ariaLabelledby?t+this.ariaLabelledby:e}_getAriaActiveDescendant(){return this.panelOpen&&this._keyManager&&this._keyManager.activeItem?this._keyManager.activeItem.id:null}_getTriggerAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||``;return this.ariaLabelledby&&(e+=` `+this.ariaLabelledby),e||(e=this._valueId),e}get describedByIds(){return this._elementRef.nativeElement.getAttribute(`aria-describedby`)?.split(` `)||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute(`aria-describedby`,e.join(` `)):t.removeAttribute(`aria-describedby`)}onContainerClick(e){let t=p(e);t&&(t.tagName===`MAT-OPTION`||t.classList.contains(`cdk-overlay-backdrop`)||t.closest(`.mat-mdc-select-panel`))||(this.focus(),this.open())}get shouldLabelFloat(){return this.panelOpen||!this.empty||this.focused&&!!this.placeholder}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`trigger`],t=[`panel`],a=[[[`mat-select-trigger`]],`*`],p=[`mat-select-trigger`,`*`];function y(g,v){if(g&1&&(Es(0,`span`,4),PC(1),fl()),g&2){let c=lC();ZE(),Qg(c.placeholder)}}function w(g,v){g&1&&yl(0)}function f(g,v){if(g&1&&(Es(0,`span`,11),PC(1),fl()),g&2){let c=lC(2);ZE(),Qg(c.triggerValue)}}function C(g,v){if(g&1&&(Es(0,`span`,5),Zw(1,w,1,0)(2,f,2,1,`span`,11),fl()),g&2){let c=lC();ZE(),Qw(c.customTrigger?1:2)}}function m(g,v){if(g&1){let c=oC();Es(0,`div`,12,1),Lg(`keydown`,function(S){hf(c);let fn=lC();return gf(fn._handleKeydown(S))}),yl(2,1),fl()}if(g&2){let c=lC();vl(c.panelClass),Rs(`mat-select-panel-animations-enabled`,!c._animationsDisabled)(`mat-primary`,c._parentFormField?.color===`primary`)(`mat-accent`,c._parentFormField?.color===`accent`)(`mat-warn`,c._parentFormField?.color===`warn`)(`mat-undefined`,!c._parentFormField?.color),So(`id`,c.id+`-panel`)(`aria-multiselectable`,c.multiple)(`aria-label`,c.ariaLabel||null)(`aria-labelledby`,c._getPanelAriaLabelledby())}}return To({type:n,selectors:[[`mat-select`]],contentQueries:function(v,c,b){if(v&1&&jg(b,Sn,5)(b,j,5)(b,Ee,5),v&2){let S;pC(S=hC())&&(c.customTrigger=S.first),pC(S=hC())&&(c.options=S),pC(S=hC())&&(c.optionGroups=S)}},viewQuery:function(v,c){if(v&1&&Vg(e,5)(t,5)(Un$1,5),v&2){let b;pC(b=hC())&&(c.trigger=b.first),pC(b=hC())&&(c.panel=b.first),pC(b=hC())&&(c._overlayDir=b.first)}},hostAttrs:[`role`,`combobox`,`aria-haspopup`,`listbox`,1,`mat-mdc-select`],hostVars:21,hostBindings:function(v,c){v&1&&Lg(`keydown`,function(S){return c._handleKeydown(S)})(`focus`,function(){return c._onFocus()})(`blur`,function(){return c._onBlur()}),v&2&&(So(`id`,c.id)(`tabindex`,c.disabled?-1:c.tabIndex)(`aria-controls`,c.panelOpen?c.id+`-panel`:null)(`aria-expanded`,c.panelOpen)(`aria-label`,c.ariaLabel||null)(`aria-required`,c.required.toString())(`aria-disabled`,c.disabled.toString())(`aria-invalid`,c.errorState)(`aria-activedescendant`,c._getAriaActiveDescendant()),Rs(`mat-mdc-select-disabled`,c.disabled)(`mat-mdc-select-invalid`,c.errorState)(`mat-mdc-select-required`,c.required)(`mat-mdc-select-empty`,c.empty)(`mat-mdc-select-multiple`,c.multiple)(`mat-select-open`,c.panelOpen))},inputs:{userAriaDescribedBy:[0,`aria-describedby`,`userAriaDescribedBy`],panelClass:`panelClass`,disabled:[2,`disabled`,`disabled`,Cl],disableRipple:[2,`disableRipple`,`disableRipple`,Cl],tabIndex:[2,`tabIndex`,`tabIndex`,g=>g==null?0:Nb(g)],hideSingleSelectionIndicator:[2,`hideSingleSelectionIndicator`,`hideSingleSelectionIndicator`,Cl],placeholder:`placeholder`,required:[2,`required`,`required`,Cl],multiple:[2,`multiple`,`multiple`,Cl],disableOptionCentering:[2,`disableOptionCentering`,`disableOptionCentering`,Cl],compareWith:`compareWith`,value:`value`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],errorStateMatcher:`errorStateMatcher`,typeaheadDebounceInterval:[2,`typeaheadDebounceInterval`,`typeaheadDebounceInterval`,Nb],sortComparator:`sortComparator`,id:`id`,panelWidth:`panelWidth`,canSelectNullableOptions:[2,`canSelectNullableOptions`,`canSelectNullableOptions`,Cl]},outputs:{openedChange:`openedChange`,_openedStream:`opened`,_closedStream:`closed`,selectionChange:`selectionChange`,valueChange:`valueChange`},exportAs:[`matSelect`],features:[tm([{provide:At,useExisting:n},{provide:ke,useExisting:n}]),Mu],ngContentSelectors:p,decls:11,vars:10,consts:[[`fallbackOverlayOrigin`,`cdkOverlayOrigin`,`trigger`,``],[`panel`,``],[`cdk-overlay-origin`,``,1,`mat-mdc-select-trigger`,3,`click`],[1,`mat-mdc-select-value`],[1,`mat-mdc-select-placeholder`,`mat-mdc-select-min-line`],[1,`mat-mdc-select-value-text`],[1,`mat-mdc-select-arrow-wrapper`],[1,`mat-mdc-select-arrow`],[`viewBox`,`0 0 24 24`,`width`,`24px`,`height`,`24px`,`focusable`,`false`,`aria-hidden`,`true`],[`d`,`M7 10l5 5 5-5z`],[`cdk-connected-overlay`,``,`cdkConnectedOverlayHasBackdrop`,``,`cdkConnectedOverlayBackdropClass`,`cdk-overlay-transparent-backdrop`,3,`detach`,`backdropClick`,`overlayKeydown`,`cdkConnectedOverlayDisableClose`,`cdkConnectedOverlayPanelClass`,`cdkConnectedOverlayScrollStrategy`,`cdkConnectedOverlayOrigin`,`cdkConnectedOverlayPositions`,`cdkConnectedOverlayWidth`,`cdkConnectedOverlayFlexibleDimensions`,`cdkConnectedOverlayUsePopover`],[1,`mat-mdc-select-min-line`],[`role`,`listbox`,`tabindex`,`-1`,1,`mat-mdc-select-panel`,`mdc-menu-surface`,`mdc-menu-surface--open`,3,`keydown`]],template:function(v,c){if(v&1&&(ml(a),Es(0,`div`,2,0),Lg(`click`,function(){return c.open()}),Es(3,`div`,3),Zw(4,y,2,1,`span`,4)(5,C,3,1,`span`,5),fl(),Es(6,`div`,6)(7,`div`,7),Mf(),Es(8,`svg`,8),xg(9,`path`,9),fl()()()(),_g(10,m,3,16,`ng-template`,10),Lg(`detach`,function(){return c.close()})(`backdropClick`,function(){return c.close()})(`overlayKeydown`,function(S){return c._handleOverlayKeydown(S)})),v&2){let b=mC(1);ZE(3),So(`id`,c._valueId),ZE(),Qw(c.empty?4:5),ZE(6),Ag(`cdkConnectedOverlayDisableClose`,!0)(`cdkConnectedOverlayPanelClass`,c._overlayPanelClass)(`cdkConnectedOverlayScrollStrategy`,c._scrollStrategy)(`cdkConnectedOverlayOrigin`,c._preferredOverlayOrigin||b)(`cdkConnectedOverlayPositions`,c._positions)(`cdkConnectedOverlayWidth`,c._overlayWidth)(`cdkConnectedOverlayFlexibleDimensions`,!0)(`cdkConnectedOverlayUsePopover`,c._popoverLocation)}},dependencies:[ye,Un$1],styles:[`@keyframes _mat-select-enter {
  from {
    opacity: 0;
    transform: scaleY(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-select-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-select {
  display: inline-block;
  width: 100%;
  outline: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  color: var(--%NS%mat-select-enabled-trigger-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-select-trigger-text-font, var(--%NS%mat-sys-body-large-font));
  line-height: var(--%NS%mat-select-trigger-text-line-height, var(--%NS%mat-sys-body-large-line-height));
  font-size: var(--%NS%mat-select-trigger-text-size, var(--%NS%mat-sys-body-large-size));
  font-weight: var(--%NS%mat-select-trigger-text-weight, var(--%NS%mat-sys-body-large-weight));
  letter-spacing: var(--%NS%mat-select-trigger-text-tracking, var(--%NS%mat-sys-body-large-tracking));
}

div.mat-mdc-select-panel {
  box-shadow: var(--%NS%mat-select-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}

.mat-mdc-select-disabled {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-select-disabled .mat-mdc-select-placeholder {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-select-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}
.mat-mdc-select-disabled .mat-mdc-select-trigger {
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
}

.mat-mdc-select-value {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mat-mdc-select-value-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mat-mdc-select-arrow-wrapper {
  height: 24px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
}
.mat-form-field-appearance-fill .mdc-text-field--no-label .mat-mdc-select-arrow-wrapper {
  transform: none;
}

.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-invalid .mat-mdc-select-arrow,
.mat-form-field-invalid:not(.mat-form-field-disabled) .mat-mdc-form-field-infix::after {
  color: var(--%NS%mat-select-invalid-arrow-color, var(--%NS%mat-sys-error));
}

.mat-mdc-select-arrow {
  width: 10px;
  height: 5px;
  position: relative;
  color: var(--%NS%mat-select-enabled-arrow-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field.mat-focused .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-focused-arrow-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-disabled .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-disabled-arrow-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-select-open .mat-mdc-select-arrow {
  transform: rotate(180deg);
}
.mat-form-field-animations-enabled .mat-mdc-select-arrow {
  transition: transform 80ms linear;
}
.mat-mdc-select-arrow svg {
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (forced-colors: active) {
  .mat-mdc-select-arrow svg {
    fill: CanvasText;
  }
  .mat-mdc-select-disabled .mat-mdc-select-arrow svg {
    fill: GrayText;
  }
}

div.mat-mdc-select-panel {
  width: 100%;
  max-height: 275px;
  outline: 0;
  overflow: auto;
  padding: 8px 0;
  box-sizing: border-box;
  transform-origin: top center;
  border-radius: 0 0 4px 4px;
  position: relative;
  background-color: var(--%NS%mat-select-panel-background-color, var(--%NS%mat-sys-surface-container));
}
.mat-mdc-select-panel-above div.mat-mdc-select-panel {
  border-radius: 4px 4px 0 0;
  transform-origin: bottom center;
}
@media (forced-colors: active) {
  div.mat-mdc-select-panel {
    outline: solid 1px;
  }
}

.mat-select-panel-animations-enabled {
  animation: _mat-select-enter 120ms cubic-bezier(0, 0, 0.2, 1) forwards;
}
.mat-select-panel-animations-enabled.mat-select-panel-exit {
  animation: _mat-select-exit 100ms linear forwards;
}

.mat-mdc-select-placeholder {
  transition: color 400ms 133.3333333333ms cubic-bezier(0.25, 0.8, 0.25, 1);
  color: var(--%NS%mat-select-placeholder-text-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field:not(.mat-form-field-animations-enabled) .mat-mdc-select-placeholder, ._mat-animation-noopable .mat-mdc-select-placeholder {
  transition: none;
}
.mat-form-field-hide-placeholder .mat-mdc-select-placeholder {
  color: transparent;
  -webkit-text-fill-color: transparent;
  transition: none;
  display: block;
}

.mat-mdc-form-field-type-mat-select:not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper {
  cursor: pointer;
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mat-mdc-floating-label {
  max-width: calc(100% - 18px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mdc-floating-label--float-above {
  max-width: calc(100% / 0.75 - 24px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-notched-outline__notch {
  max-width: calc(100% - 60px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-text-field--label-floating .mdc-notched-outline__notch {
  max-width: calc(100% - 24px);
}

.mat-mdc-select-min-line:empty::before {
  content: " ";
  white-space: pre;
  width: 1px;
  display: inline-block;
  visibility: hidden;
}

.mat-form-field-appearance-fill .mat-mdc-select-arrow-wrapper {
  transform: var(--%NS%mat-select-arrow-transform, translateY(-8px));
}
`],encapsulation:2})})()}return n})();var un=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=wt({type:n});static ɵinj=Xe({imports:[Nn$1,Ie,fy,me,Vt,Ie]})}return n})();var Te=n=>[`/clientes`,n];var Mn=()=>[`/clientes`];var wn=n=>[`/clientes`,n,`recetas`,`nueva`];var gn=(n,o)=>o.id;function kn(n,o){n&1&&xg(0,`mat-progress-bar`,1)}function En(n,o){n&1&&(PC(0,` Para `),Es(1,`strong`),PC(2),fl(),PC(3,`. Usa una receta existente como referencia. `)),n&2&&(ZE(2),Qg(o.full_name))}function In(n,o){n&1&&PC(0,` Registra un pedido para un cliente. `)}function Nn(n,o){if(n&1&&(Es(0,`div`,6)(1,`span`,3),PC(2,`error`),fl(),Es(3,`span`),PC(4),fl()()),n&2){let e=lC();ZE(4),Qg(e.error())}}function Tn(n,o){if(n&1&&(Es(0,`div`,11)(1,`span`,3),PC(2,`photo_camera_back`),fl(),Es(3,`h3`),PC(4,`Este cliente no tiene recetas`),fl(),Es(5,`p`),PC(6,`Para crear un pedido primero debes registrar la fotografía de la receta.`),fl(),Es(7,`a`,33)(8,`span`,3),PC(9,`photo_camera`),fl(),PC(10,` Registrar receta `),fl()()),n&2){let e=lC();ZE(7),Ag(`routerLink`,WC(1,wn,e.id))}}function Dn(n,o){if(n&1&&PC(0),n&2){let e=lC().$implicit;Dl(` · `,e.observations,` `)}}function Fn(n,o){if(n&1&&(Es(0,`mat-option`,18),PC(1),ZC(2,`date`),Zw(3,Dn,1,1),PC(4),fl()),n&2){let e=o.$implicit;Ag(`value`,e.id),ZE(),Dl(` `,QC(2,5,e.registered_at,`dd/MM/yyyy`),` `),ZE(2),Qw(e.observations?3:-1),ZE(),Kg(` (`,e.images.length,` foto`,e.images.length===1?``:`s`,`) `)}}function Pn(n,o){n&1&&(Es(0,`mat-error`),PC(1,`Selecciona la receta que se usará.`),fl())}function An(n,o){if(n&1){let e=oC();Es(0,`button`,37),Lg(`click`,function(){let a=hf(e).$implicit,p=lC(4);return gf(p.openImage(a))}),xg(1,`app-auth-image`,38),fl()}if(n&2){let e=o.$implicit;ZE(),Ag(`image`,e)}}function Rn(n,o){if(n&1&&(Es(0,`div`,35),Xw(1,An,2,1,`button`,36,gn),fl()),n&2){let e=lC();ZE(),Jw(e.images)}}function Vn(n,o){if(n&1&&(Es(0,`div`,19)(1,`div`,34)(2,`span`,3),PC(3,`description`),fl(),Es(4,`div`)(5,`strong`),PC(6),ZC(7,`date`),fl(),Es(8,`p`,9),PC(9),fl()()(),Zw(10,Rn,3,0,`div`,35),fl()),n&2){let e=o;ZE(6),Dl(`Receta del `,QC(7,3,e.registered_at,`dd/MM/yyyy`)),ZE(3),Qg(e.observations||`Sin observaciones.`),ZE(),Qw(e.images.length?10:-1)}}function Ln(n,o){if(n&1&&xg(0,`option`,18),n&2){let e=o.$implicit;Ag(`value`,e)}}function Bn(n,o){n&1&&PC(0,` El tipo de lentes no puede superar los 100 caracteres. `)}function zn(n,o){n&1&&PC(0,` Indica el tipo de lentes. `)}function Wn(n,o){if(n&1&&(Es(0,`mat-error`),Zw(1,Bn,1,0)(2,zn,1,0),fl()),n&2){let e=lC(2);ZE(),Qw(e.form.controls.lens_type.errors?.maxlength?1:2)}}function Gn(n,o){n&1&&PC(0,` La fecha no puede ser futura. `)}function qn(n,o){n&1&&PC(0,` Selecciona la fecha del pedido. `)}function Kn(n,o){if(n&1&&(Es(0,`mat-error`),Zw(1,Gn,1,0)(2,qn,1,0),fl()),n&2){let e=lC(2);ZE(),Qw(e.form.controls.ordered_at.errors?.futureDate?1:2)}}function jn(n,o){n&1&&PC(0,` El precio no puede superar Bs 999.999. `)}function Hn(n,o){n&1&&PC(0,` El precio no puede ser negativo. `)}function Un(n,o){if(n&1&&(Es(0,`mat-error`),Zw(1,jn,1,0)(2,Hn,1,0),fl()),n&2){let e=lC(2);ZE(),Qw(e.form.controls.price.errors?.max?1:2)}}function Qn(n,o){n&1&&PC(0,` El adelanto no puede superar el precio total. `)}function Yn(n,o){n&1&&PC(0,` El adelanto no puede superar Bs 999.999. `)}function $n(n,o){n&1&&PC(0,` El adelanto no puede ser negativo. `)}function Xn(n,o){if(n&1&&(Es(0,`mat-error`),Zw(1,Qn,1,0)(2,Yn,1,0)(3,$n,1,0),fl()),n&2){let e=lC(2);ZE(),Qw(e.form.controls.advance.errors?.exceedsPrice?1:e.form.controls.advance.errors?.max?2:3)}}function Jn(n,o){n&1&&(Es(0,`span`,41),PC(1,`El adelanto supera el precio. Corrige los montos.`),fl())}function Zn(n,o){if(n&1&&(Es(0,`div`,39)(1,`span`,3),PC(2),fl(),Es(3,`div`)(4,`span`,40),PC(5,`Saldo pendiente`),fl(),Es(6,`strong`),PC(7),fl()(),Zw(8,Jn,2,0,`span`,41),fl()),n&2){let e=lC(2);Rs(`balance-box--alert`,e.advanceExceedsPrice()),ZE(2),Qg(e.advanceExceedsPrice()?`warning`:`account_balance_wallet`),ZE(5),Qg(e.money(e.balance())),ZE(),Qw(e.advanceExceedsPrice()?8:-1)}}function ei(n,o){n&1&&(xg(0,`span`,42),PC(1,` Registrando… `))}function ti(n,o){n&1&&(Es(0,`span`,3),PC(1,`add_shopping_cart`),fl(),PC(2,` Registrar pedido `))}function ni(n,o){if(n&1){let e=oC();Es(0,`div`,7)(1,`span`,8),PC(2),fl(),Es(3,`div`)(4,`strong`),PC(5),fl(),Es(6,`span`,9),PC(7),fl()(),Es(8,`a`,10),PC(9,`Ver ficha`),fl()(),Zw(10,Tn,11,3,`div`,11),Es(11,`div`,12)(12,`form`,13),Lg(`ngSubmit`,function(){hf(e);let a=lC();return gf(a.submit())}),Es(13,`p`,14),PC(14,`Los campos con * son obligatorios.`),fl(),Es(15,`div`,15)(16,`mat-form-field`,16)(17,`mat-label`),PC(18,`Receta utilizada`),fl(),Es(19,`mat-select`,17),PI(),Xw(20,Fn,5,8,`mat-option`,18,gn),fl(),Es(22,`mat-hint`),PC(23,`Receta que respalda las medidas de este pedido.`),fl(),Zw(24,Pn,2,0,`mat-error`),fl(),Zw(25,Vn,11,6,`div`,19),Es(26,`mat-form-field`,20)(27,`mat-label`),PC(28,`Tipo de lentes`),fl(),Es(29,`input`,21),PI(),fl(),Es(30,`mat-icon`,22),PC(31,`visibility`),fl(),Es(32,`mat-hint`),PC(33,`Elige una opción o escribe el tipo exacto.`),fl(),Es(34,`datalist`,23),Xw(35,Ln,1,1,`option`,18,Kw),fl(),Zw(37,Wn,3,1,`mat-error`),fl(),Es(38,`mat-form-field`,20)(39,`mat-label`),PC(40,`Fecha del pedido`),fl(),Es(41,`input`,24),PI(),fl(),Es(42,`mat-hint`),PC(43,`No puede ser una fecha futura.`),fl(),Zw(44,Kn,3,1,`mat-error`),fl(),Es(45,`mat-form-field`,20)(46,`mat-label`),PC(47,`Precio total (opcional)`),fl(),Es(48,`span`,22),PC(49,`Bs\xA0`),fl(),Es(50,`input`,25),PI(),fl(),Es(51,`mat-hint`),PC(52,`Opcional. Si lo registras, se calcula el saldo.`),fl(),Zw(53,Un,3,1,`mat-error`),fl(),Es(54,`mat-form-field`,20)(55,`mat-label`),PC(56,`Adelanto (opcional)`),fl(),Es(57,`span`,22),PC(58,`Bs\xA0`),fl(),Es(59,`input`,26),PI(),fl(),Es(60,`mat-hint`),PC(61,`Opcional. No puede superar el precio total.`),fl(),Zw(62,Xn,4,1,`mat-error`),fl(),Zw(63,Zn,9,5,`div`,27),Es(64,`mat-form-field`,16)(65,`mat-label`),PC(66,`Observaciones del pedido (opcional)`),fl(),Es(67,`textarea`,28),PI(),fl(),Es(68,`mat-hint`),PC(69,`Opcional: detalles del tratamiento, montura o fecha prometida.`),fl(),Es(70,`mat-hint`,29),PC(71),fl()()(),Es(72,`div`,30)(73,`button`,31),Zw(74,ei,2,0)(75,ti,3,0),fl(),Es(76,`a`,32),PC(77,`Cancelar`),fl()()()()}if(n&2){let e,t=o,a=lC();ZE(2),Qg(t.full_name.charAt(0)),ZE(3),Qg(t.full_name),ZE(2),Qg(t.phone),ZE(),Ag(`routerLink`,WC(18,Te,t.id)),ZE(2),Qw(a.prescriptions.length===0?10:-1),ZE(2),Ag(`formGroup`,a.form),ZE(7),VI(),ZE(),Jw(a.prescriptions),ZE(4),Qw(a.form.controls.prescription_id.touched&&a.form.controls.prescription_id.invalid?24:-1),ZE(),Qw((e=a.selectedPrescription())?25:-1,e),ZE(4),VI(),ZE(6),Jw(a.lensTypes),ZE(2),Qw(a.form.controls.lens_type.touched&&a.form.controls.lens_type.invalid?37:-1),ZE(4),Ag(`max`,a.today),VI(),ZE(3),Qw(a.form.controls.ordered_at.touched&&a.form.controls.ordered_at.invalid?44:-1),ZE(6),VI(),ZE(3),Qw(a.form.controls.price.touched&&a.form.controls.price.invalid?53:-1),ZE(6),VI(),ZE(3),Qw(a.form.controls.advance.touched&&a.form.controls.advance.invalid?62:-1),ZE(),Qw(a.balance()!==null?63:-1),ZE(4),VI(),ZE(4),Dl(``,a.form.controls.observations.value?.length||0,` / 2000`),ZE(2),Ag(`disabled`,a.saving()||a.prescriptions.length===0),ZE(),Qw(a.saving()?74:75),ZE(2),Ag(`routerLink`,WC(20,Te,t.id))}}var hn=class n{fb=g(Wr$1);clients=g(g$1);orders=g(m);toast=g(On);route=g(B);router=g(G);dialog=g(Ft);destroyRef=g(pe);client=or(null);loading=or(!0);saving=or(!1);error=or(null);today=o();lensTypes=[`Monofocal`,`Bifocal`,`Progresivo`,`Ocupacional`,`Fotocromático`,`Antirreflejo`,`Lentes de sol`,`Otro`];form=this.fb.group({prescription_id:[null,[Me$1.required]],lens_type:[``,[Me$1.required,Me$1.maxLength(100),ts]],observations:[``,[Me$1.maxLength(2e3)]],price:[null,[Me$1.min(0),Me$1.max(999999)]],advance:[null,[Me$1.min(0),Me$1.max(999999)]],ordered_at:[o(),[Me$1.required,is]]});constructor(){this.form.controls.price.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError()),this.form.controls.advance.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError())}ngOnInit(){let o=Number(this.route.snapshot.queryParamMap.get(`clientId`)),e=Number(this.route.snapshot.queryParamMap.get(`prescriptionId`));if(!o){this.toast.info(`Selecciona primero un cliente para crear su pedido.`),this.router.navigate([`/clientes`]);return}this.clients.get(o).subscribe({next:t=>{this.client.set(t.data),this.loading.set(!1);let a=t.data.prescriptions??[],p=a.find(y=>y.id===e);p?this.form.controls.prescription_id.setValue(p.id):a.length===1&&this.form.controls.prescription_id.setValue(a[0].id)},error:t=>{this.loading.set(!1),this.error.set(Wr(t,`No se pudo cargar el cliente.`))}})}get prescriptions(){return this.client()?.prescriptions??[]}selectedPrescription(){let o=this.form.controls.prescription_id.value;return this.prescriptions.find(e=>e.id===o)??null}balance(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o==null?null:Math.round((Number(o)-Number(e??0))*100)/100}syncAdvanceError(){let o=this.form.controls.advance,e=o.errors??{};if(this.advanceExceedsPrice()){o.setErrors(W(V({},e),{exceedsPrice:!0}));return}if(e.exceedsPrice){let t=V({},e);delete t.exceedsPrice,o.setErrors(Object.keys(t).length>0?t:null)}}advanceExceedsPrice(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o!==null&&e!==null&&Number(e)>Number(o)}money(o){return c(o)}openImage(o,e){this.dialog.open(T,{data:{image:o,title:e},width:`min(1000px, 94vw)`,maxWidth:`94vw`,panelClass:`app-dialog`,autoFocus:!1})}submit(){let o$1=this.client();if(!o$1)return;if(this.prescriptions.length===0){this.error.set(`Este cliente todavía no tiene una receta. Registra una antes de crear el pedido.`);return}if(this.form.invalid){this.form.markAllAsTouched();return}if(this.advanceExceedsPrice()){this.error.set(`El adelanto no puede ser mayor que el precio total.`);return}let e=this.form.getRawValue();this.saving.set(!0),this.error.set(null),this.orders.create({client_id:o$1.id,prescription_id:Number(e.prescription_id),lens_type:(e.lens_type??``).trim(),observations:e.observations?.trim()||null,price:e.price===null?null:Number(e.price),advance:e.advance===null?null:Number(e.advance),ordered_at:e.ordered_at??o()}).subscribe({next:t=>{this.saving.set(!1),this.toast.success(`Pedido #${t.data.id} registrado correctamente.`),this.router.navigate([`/pedidos`,t.data.id])},error:t=>{this.saving.set(!1),this.error.set(Wr(t,`No se pudo registrar el pedido.`))}})}static ɵfac=function(e){return new(e||n)};static ɵcmp=To({type:n,selectors:[[`app-order-form`]],decls:15,vars:8,consts:[[1,`page`,`page--narrow`],[`mode`,`indeterminate`,1,`loading-bar`],[1,`back-link`,3,`routerLink`],[1,`material-icons`],[1,`page-header`],[1,`page-header__text`],[1,`banner`,`banner--danger`,2,`margin-bottom`,`14px`],[1,`card`,`client-summary`],[1,`client-summary__avatar`],[1,`muted`,`small`],[1,`btn`,`btn--ghost`,`btn--sm`,3,`routerLink`],[1,`empty-state`,2,`margin-bottom`,`14px`],[1,`card`],[1,`stack`,3,`ngSubmit`,`formGroup`],[1,`form-required-note`],[1,`form-grid`],[`appearance`,`outline`,1,`full`],[`formControlName`,`prescription_id`,`placeholder`,`Selecciona una receta`],[3,`value`],[1,`prescription-summary`,`full`],[`appearance`,`outline`],[`matInput`,``,`formControlName`,`lens_type`,`list`,`lensTypes`,`maxlength`,`100`,`placeholder`,`Ej. Progresivo`],[`matPrefix`,``],[`id`,`lensTypes`],[`matInput`,``,`type`,`date`,`formControlName`,`ordered_at`,3,`max`],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`price`,`inputmode`,`decimal`],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`advance`,`inputmode`,`decimal`],[1,`balance-box`,`full`,3,`balance-box--alert`],[`matInput`,``,`rows`,`3`,`maxlength`,`2000`,`formControlName`,`observations`,`placeholder`,`Ej. Tratamiento antirreflejo, montura elegida, fecha prometida…`],[`align`,`end`],[1,`form-actions`],[`type`,`submit`,1,`btn`,`btn--primary`,`btn--lg`,3,`disabled`],[1,`btn`,`btn--outline`,`btn--lg`,3,`routerLink`],[1,`btn`,`btn--primary`,2,`margin-top`,`14px`,3,`routerLink`],[1,`prescription-summary__info`],[1,`prescription-summary__photos`],[`type`,`button`,1,`photo-thumb`],[`type`,`button`,1,`photo-thumb`,3,`click`],[3,`image`],[1,`balance-box`,`full`],[1,`small`,`muted`],[1,`small`],[1,`spinner`]],template:function(e,t){if(e&1&&(Es(0,`div`,0),Zw(1,kn,1,0,`mat-progress-bar`,1),Es(2,`a`,2)(3,`span`,3),PC(4,`arrow_back`),fl(),PC(5,` Volver a la ficha del cliente `),fl(),Es(6,`header`,4)(7,`div`,5)(8,`h1`),PC(9,`Nuevo pedido`),fl(),Es(10,`p`),Zw(11,En,4,1)(12,In,1,0),fl()()(),Zw(13,Nn,5,1,`div`,6),Zw(14,ni,78,22),fl()),e&2){let a,p;ZE(),Qw(t.loading()?1:-1),ZE(),Ag(`routerLink`,t.client()?WC(5,Te,t.client()?.id):zC(7,Mn)),ZE(9),Qw((a=t.client())?11:12,a),ZE(2),Qw(t.error()?13:-1),ZE(),Qw((p=t.client())?14:-1,p)}},dependencies:[jm,Kr,Ur,qr,$r,vn,or$1,Br,Hr,ji,Pi,Ti,wt$1,sr,ua,di,Vt,ri,Dt,Ft$1,mr,hr$1,Ja,Qa,un,pn,j,J2,X2,Fr,Lr,_,eT],styles:[`.page--narrow[_ngcontent-%COMP%]{max-width:900px}.back-link[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:5px;color:var(--%NS%optic-primary-dark);font-weight:600;font-size:.82rem;margin-bottom:10px;text-decoration:none}.back-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.back-link[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}.client-summary[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:14px 18px;margin-bottom:14px}.client-summary__avatar[_ngcontent-%COMP%]{width:42px;height:42px;border-radius:12px;background:#def5f5;color:#007171;display:grid;place-items:center;font-weight:800;text-transform:uppercase;flex-shrink:0}.client-summary[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1;min-width:0}.client-summary[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.95rem}.prescription-summary[_ngcontent-%COMP%]{background:#f7fbfb;border:1px solid #e4efef;border-radius:12px;padding:12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}.prescription-summary__info[_ngcontent-%COMP%]{display:flex;gap:9px;align-items:flex-start;flex:1;min-width:200px}.prescription-summary__info[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary);font-size:21px;margin-top:1px}.prescription-summary__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.86rem}.prescription-summary__info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-top:2px}.prescription-summary__photos[_ngcontent-%COMP%]{display:flex;gap:7px;flex-wrap:wrap}.prescription-summary__photos[_ngcontent-%COMP%]   .photo-thumb[_ngcontent-%COMP%]{width:62px;height:52px;aspect-ratio:auto}.balance-box[_ngcontent-%COMP%]{display:flex;align-items:center;gap:11px;background:#f1fafa;border:1px solid #dcefee;border-radius:12px;padding:11px 14px}.balance-box[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary-dark);font-size:24px}.balance-box[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column}.balance-box[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:1.15rem;color:#164040}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:auto;text-align:right}.balance-box--alert[_ngcontent-%COMP%]{background:var(--%NS%optic-danger-soft);border-color:#f3cccc}.balance-box--alert[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%], .balance-box--alert[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--%NS%optic-danger)}.spinner[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:_ngcontent-%COMP%_spin .7s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}@media(max-width:720px){.form-actions[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}}@media(max-width:599px){.balance-box[_ngcontent-%COMP%]{flex-wrap:wrap}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:0;flex-basis:100%;text-align:left}}`]})};export{hn as OrderFormComponent};