import{$n as xg,An as or,B as Jw,C as Du,Ct as Vg,D as Es,Dn as nt,Dt as Xe,En as nm,Fn as pr,Gn as te,H as Kw,Hn as tC,Ht as _u,In as rU,J as M2,Kn as v,L as Iu,Ln as r_,M as G,Mn as ov,N as Gg,Nn as pC,O as Eu,P as Gp,Pt as ZI,Qn as vu,Qt as eU,R as J,S as Dr,Sn as nC,St as Vf,T as Ed,Tn as ne$1,Ut as aC,V as Kg,W as L,Wn as tU,X as Mg,Yn as vf,Yt as cs,Z as Mo,_ as Bm,_n as le,a as wr,an as gm,b as DC,bn as ma,c as K,cn as he,ct as Pg,d as Af,dn as hy,dt as QE,ft as QT,g as Bg,gn as kt,gt as So,h as BI,hn as jg,i as ua,ir as yf,jn as ot,jt as Yy,k as Fg,kt as Xy,ln as hr,lt as Q,m as BC,mn as iv,mt as Rs,n as G$1,nn as g,nr as yC,nt as Nr,o as x,on as gu,ot as Ot,pt as Rg,r as di,s as d,st as Pe,tt as No,u as AE,un as hu,vt as Tg,w as Ea,wt as Vn,x as Dd,xn as mu,xt as V,y as Ct,yn as mC,yt as UI}from"./main-2OBBMORU.js";import{t as f}from"./chunk-D0CtxH_j.js";import{a as jr,c as nr,i as cr,n as Fr,r as Gr,t as Ar}from"./chunk-DhBZcmzV.js";import{C as st,S as rt,T as ws,b as q,c as Q$1,d as Ve,f as W,i as De,l as Re,m as Ws,p as We,r as Ce,u as V$1}from"./chunk-WJc9g1Fu.js";import{D as xe,O as xt$1,S as rt$1,T as we,a as Tn,b as ma$1,d as an,g as jn,i as Pn,n as En,o as Vn$1,r as K$1,t as $,v as ln$1,w as ue,x as rn}from"./chunk-DjB8DsSH.js";import{i as V$2,n as Ft,r as Re$1,s as ze,t as Be}from"./chunk-CbSr9L8S.js";import{E as ji$1,F as sr,L as vn$1,N as ri,O as mr,P as rs,R as wt,_ as Qa,a as Br,b as Vt,c as Hr,f as Kr,o as Dt,p as Me,s as Ft$1,u as Ja,x as Wr,y as Ur}from"./chunk-BORAGBZk.js";import{t as g$1}from"./chunk-DpqNXlK-.js";import{t as c}from"./chunk-CgQR350t.js";import{n as U,t as T}from"./chunk-Dt1w6Les.js";import{t as E}from"./chunk-BxGPUHKp.js";var ji=new v(`MAT_BADGE_CONFIG`);var Ni=`mat-badge-content`;var Hi=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵcmp=So({type:n,selectors:[[`ng-component`]],decls:0,vars:0,template:function(e,i){},styles:[`.mat-badge {
  position: relative;
}
.mat-badge.mat-badge {
  overflow: visible;
}

.mat-badge-content {
  position: absolute;
  text-align: center;
  display: inline-block;
  transition: transform 200ms ease-in-out;
  transform: scale(0.6);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  box-sizing: border-box;
  pointer-events: none;
  background-color: var(--%NS%mat-badge-background-color, var(--%NS%mat-sys-error));
  color: var(--%NS%mat-badge-text-color, var(--%NS%mat-sys-on-error));
  font-family: var(--%NS%mat-badge-text-font, var(--%NS%mat-sys-label-small-font));
  font-weight: var(--%NS%mat-badge-text-weight, var(--%NS%mat-sys-label-small-weight));
  border-radius: var(--%NS%mat-badge-container-shape, var(--%NS%mat-sys-corner-full));
}
.mat-badge-above .mat-badge-content {
  bottom: 100%;
}
.mat-badge-below .mat-badge-content {
  top: 100%;
}
.mat-badge-before .mat-badge-content {
  right: 100%;
}
[dir=rtl] .mat-badge-before .mat-badge-content {
  right: auto;
  left: 100%;
}
.mat-badge-after .mat-badge-content {
  left: 100%;
}
[dir=rtl] .mat-badge-after .mat-badge-content {
  left: auto;
  right: 100%;
}
@media (forced-colors: active) {
  .mat-badge-content {
    outline: solid 1px;
    border-radius: 0;
  }
}

.mat-badge-disabled .mat-badge-content {
  background-color: var(--%NS%mat-badge-disabled-state-background-color, color-mix(in srgb, var(--%NS%mat-sys-error) 38%, transparent));
  color: var(--%NS%mat-badge-disabled-state-text-color, var(--%NS%mat-sys-on-error));
}

.mat-badge-hidden .mat-badge-content {
  display: none;
}

.ng-animate-disabled .mat-badge-content,
.mat-badge-content._mat-animation-noopable {
  transition: none;
}

.mat-badge-content.mat-badge-active {
  transform: none;
}

.mat-badge-small .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-small-size-container-size, unset);
  height: var(--%NS%mat-badge-legacy-small-size-container-size, unset);
  min-width: var(--%NS%mat-badge-small-size-container-size, 6px);
  min-height: var(--%NS%mat-badge-small-size-container-size, 6px);
  line-height: var(--%NS%mat-badge-small-size-line-height, 6px);
  padding: var(--%NS%mat-badge-small-size-container-padding, 0);
  font-size: var(--%NS%mat-badge-small-size-text-size, 0);
  margin: var(--%NS%mat-badge-small-size-container-offset, -6px 0);
}
.mat-badge-small.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-small-size-container-overlap-offset, -6px);
}

.mat-badge-medium .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-container-size, unset);
  height: var(--%NS%mat-badge-legacy-container-size, unset);
  min-width: var(--%NS%mat-badge-container-size, 16px);
  min-height: var(--%NS%mat-badge-container-size, 16px);
  line-height: var(--%NS%mat-badge-line-height, 16px);
  padding: var(--%NS%mat-badge-container-padding, 0 4px);
  font-size: var(--%NS%mat-badge-text-size, var(--%NS%mat-sys-label-small-size));
  margin: var(--%NS%mat-badge-container-offset, -12px 0);
}
.mat-badge-medium.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-container-overlap-offset, -12px);
}

.mat-badge-large .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-large-size-container-size, unset);
  height: var(--%NS%mat-badge-legacy-large-size-container-size, unset);
  min-width: var(--%NS%mat-badge-large-size-container-size, 16px);
  min-height: var(--%NS%mat-badge-large-size-container-size, 16px);
  line-height: var(--%NS%mat-badge-large-size-line-height, 16px);
  padding: var(--%NS%mat-badge-large-size-container-padding, 0 4px);
  font-size: var(--%NS%mat-badge-large-size-text-size, var(--%NS%mat-sys-label-small-size));
  margin: var(--%NS%mat-badge-large-size-container-offset, -12px 0);
}
.mat-badge-large.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-large-size-container-overlap-offset, -12px);
}
`],encapsulation:2})}return n})();var Ii=(()=>{class n{_ngZone=g(le);_elementRef=g(nt);_ariaDescriber=g(ws);_renderer=g(hr);_animationsDisabled=Ar();_idGenerator=g(q);get color(){return this._color}set color(t){this._setColor(t),this._color=t}_color;overlap;disabled=!1;position;get content(){return this._content}set content(t){this._updateRenderedContent(t)}_content;get description(){return this._description}set description(t){this._updateDescription(t)}_description;size;hidden=!1;_badgeElement;_inlineBadgeDescription;_isInitialized=!1;_interactivityChecker=g(De);_document=g(L);constructor(){let t=g(ji,{optional:!0}),e=g(QT);e.load(Hi),e.load(M2),this._color=t?.color||`primary`,this.overlap=t?.overlap??!0,this.position=t?.position||`above after`,this.size=t?.size||`medium`}isAbove(){return this.position.indexOf(`below`)===-1}isAfter(){return this.position.indexOf(`before`)===-1}getBadgeElement(){return this._badgeElement}ngOnInit(){this._clearExistingBadges(),this.content&&!this._badgeElement&&(this._badgeElement=this._createBadgeElement(),this._updateRenderedContent(this.content)),this._isInitialized=!0}ngAfterViewInit(){}ngOnDestroy(){this._renderer.destroyNode&&(this._renderer.destroyNode(this._badgeElement),this._inlineBadgeDescription?.remove()),this._ariaDescriber.removeDescription(this._elementRef.nativeElement,this.description)}_isHostInteractive(){return this._interactivityChecker.isFocusable(this._elementRef.nativeElement,{ignoreVisibility:!0})}_createBadgeElement(){let t=this._renderer.createElement(`span`),e=`mat-badge-active`;return t.setAttribute(`id`,this._idGenerator.getId(`mat-badge-content-`)),t.setAttribute(`aria-hidden`,`true`),t.classList.add(Ni),this._animationsDisabled&&t.classList.add(`_mat-animation-noopable`),this._elementRef.nativeElement.appendChild(t),typeof requestAnimationFrame==`function`&&!this._animationsDisabled?this._ngZone.runOutsideAngular(()=>{requestAnimationFrame(()=>{t.classList.add(e)})}):t.classList.add(e),t}_updateRenderedContent(t){let e=`${t??``}`.trim();this._isInitialized&&e&&!this._badgeElement&&(this._badgeElement=this._createBadgeElement()),this._badgeElement&&(this._badgeElement.textContent=e),this._content=e}_updateDescription(t){this._ariaDescriber.removeDescription(this._elementRef.nativeElement,this.description),(!t||this._isHostInteractive())&&this._removeInlineDescription(),this._description=t,this._isHostInteractive()?this._ariaDescriber.describe(this._elementRef.nativeElement,t):this._updateInlineDescription()}_updateInlineDescription(){this._inlineBadgeDescription||(this._inlineBadgeDescription=this._document.createElement(`span`),this._inlineBadgeDescription.classList.add(`cdk-visually-hidden`)),this._inlineBadgeDescription.textContent=this.description,this._badgeElement?.appendChild(this._inlineBadgeDescription)}_removeInlineDescription(){this._inlineBadgeDescription?.remove(),this._inlineBadgeDescription=void 0}_setColor(t){let e=this._elementRef.nativeElement.classList;e.remove(`mat-badge-${this._color}`),t&&e.add(`mat-badge-${t}`)}_clearExistingBadges(){let t=this._elementRef.nativeElement.querySelectorAll(`:scope > .${Ni}`);for(let e of Array.from(t))e!==this._badgeElement&&e.remove()}static ɵfac=function(e){return new(e||n)};static ɵdir=Mo({type:n,selectors:[[``,`matBadge`,``]],hostAttrs:[1,`mat-badge`],hostVars:20,hostBindings:function(e,i){e&2&&Rs(`mat-badge-overlap`,i.overlap)(`mat-badge-above`,i.isAbove())(`mat-badge-below`,!i.isAbove())(`mat-badge-before`,!i.isAfter())(`mat-badge-after`,i.isAfter())(`mat-badge-small`,i.size===`small`)(`mat-badge-medium`,i.size===`medium`)(`mat-badge-large`,i.size===`large`)(`mat-badge-hidden`,i.hidden||!i.content)(`mat-badge-disabled`,i.disabled)},inputs:{color:[0,`matBadgeColor`,`color`],overlap:[2,`matBadgeOverlap`,`overlap`,_u],disabled:[2,`matBadgeDisabled`,`disabled`,_u],position:[0,`matBadgePosition`,`position`],content:[0,`matBadge`,`content`],description:[0,`matBadgeDescription`,`description`],size:[0,`matBadgeSize`,`size`],hidden:[2,`matBadgeHidden`,`hidden`,_u]}})}return n})();var zi=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[rt,hy]})}return n})();var Di=(()=>{class n{get vertical(){return this._vertical}set vertical(t){this._vertical=Ws(t)}_vertical=!1;get inset(){return this._inset}set inset(t){this._inset=Ws(t)}_inset=!1;static ɵfac=function(e){return new(e||n)};static ɵcmp=So({type:n,selectors:[[`mat-divider`]],hostAttrs:[`role`,`separator`,1,`mat-divider`],hostVars:7,hostBindings:function(e,i){e&2&&(No(`aria-orientation`,i.vertical?`vertical`:`horizontal`),Rs(`mat-divider-vertical`,i.vertical)(`mat-divider-horizontal`,!i.vertical)(`mat-divider-inset`,i.inset))},inputs:{vertical:`vertical`,inset:`inset`},decls:0,vars:0,template:function(e,i){},styles:[`.mat-divider {
  display: block;
  margin: 0;
  border-top-style: solid;
  border-top-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-top-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-vertical {
  border-top: 0;
  border-right-style: solid;
  border-right-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-right-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-inset {
  margin-left: 80px;
}
[dir=rtl] .mat-divider.mat-divider-inset {
  margin-left: auto;
  margin-right: 80px;
}
`],encapsulation:2})}return n})();var jt=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[hy]})}return n})();var Ti=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[Ce,rn,E,hy,jt]})}return n})();var ne=new v(`MAT_MENU_PANEL`);var xt=(()=>{class n{_isAnchor;_elementRef=g(nt);_document=g(L);_focusMonitor=g(We);_parentMenu=g(ne,{optional:!0});_changeDetectorRef=g(gm);role=`menuitem`;disabled=!1;disabledInteractive=!1;disableRipple=!1;_hovered=new te;_focused=new te;_highlighted=!1;_triggersSubmenu=!1;constructor(){g(QT).load(an),this._parentMenu?.addItem?.(this),this._isAnchor=this._elementRef.nativeElement.tagName===`A`}focus(t,e){this._focusMonitor&&t?this._focusMonitor.focusVia(this._getHostElement(),t,e):this._getHostElement().focus(e),this._focused.next(this)}ngAfterViewInit(){this._focusMonitor&&this._focusMonitor.monitor(this._elementRef,!1)}ngOnDestroy(){this._focusMonitor&&this._focusMonitor.stopMonitoring(this._elementRef),this._parentMenu&&this._parentMenu.removeItem&&this._parentMenu.removeItem(this),this._hovered.complete(),this._focused.complete()}_getTabIndex(){return this.disabled&&!this.disabledInteractive?`-1`:`0`}_getAriaDisabled(){return this._isAnchor?this.disabled||null:this.disabled&&this.disabledInteractive?!0:null}_getDisabled(){return this.disabledInteractive||!this.disabled?null:!0}_getHostElement(){return this._elementRef.nativeElement}_checkDisabled(t){this.disabled&&(t.preventDefault(),t.stopPropagation())}_handleMouseEnter(){this._hovered.next(this)}getLabel(){let t=this._elementRef.nativeElement.cloneNode(!0),e=t.querySelectorAll(`mat-icon, .material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp`);for(let i=0;i<e.length;i++)e[i].remove();return t.textContent?.trim()||``}_setHighlighted(t){this._highlighted=t,this._changeDetectorRef.markForCheck()}_setTriggersSubmenu(t){this._triggersSubmenu=t,this._changeDetectorRef.markForCheck()}_hasFocus(){return this._document&&this._document.activeElement===this._getHostElement()}static ɵfac=function(e){return new(e||n)};static ɵcmp=(function(){let t=[[[`mat-icon`],[``,`matMenuItemIcon`,``]],`*`],e=[`mat-icon, [matMenuItemIcon]`,`*`];function i(r,a){r&1&&(Af(),Es(0,`svg`,2),Rg(1,`polygon`,3),hu())}return So({type:n,selectors:[[``,`mat-menu-item`,``]],hostAttrs:[1,`mat-mdc-menu-item`,`mat-focus-indicator`],hostVars:12,hostBindings:function(a,m){a&1&&Pg(`click`,function(_){return m._checkDisabled(_)})(`mouseenter`,function(){return m._handleMouseEnter()}),a&2&&(No(`role`,m.role)(`tabindex`,m._getTabIndex())(`aria-disabled`,m._getAriaDisabled())(`disabled`,m._getDisabled()),Rs(`mat-mdc-menu-item-highlighted`,m._highlighted)(`mat-mdc-menu-item-submenu-trigger`,m._triggersSubmenu)(`mat-mdc-menu-item-disabled`,m.disabled)(`mat-mdc-menu-item-disabled-interactive`,m.disabledInteractive))},inputs:{role:`role`,disabled:[2,`disabled`,`disabled`,_u],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,_u],disableRipple:[2,`disableRipple`,`disableRipple`,_u]},exportAs:[`matMenuItem`],ngContentSelectors:e,decls:5,vars:3,consts:[[1,`mat-mdc-menu-item-text`],[`matRipple`,``,1,`mat-mdc-menu-ripple`,3,`matRippleDisabled`,`matRippleTrigger`],[`viewBox`,`0 0 5 10`,`focusable`,`false`,`aria-hidden`,`true`,1,`mat-mdc-menu-submenu-icon`],[`points`,`0,0 5,5 0,10`]],template:function(a,m){a&1&&(vu(t),Du(0),Es(1,`span`,0),Du(2,1),hu(),Rg(3,`div`,1),Kw(4,i,2,0,`svg`,2)),a&2&&(QE(3),xg(`matRippleDisabled`,m.disableRipple||m.disabled)(`matRippleTrigger`,m._getHostElement()),QE(),Jw(m._triggersSubmenu?4:-1))},dependencies:[ma$1],encapsulation:2})})()}return n})();var qi=new v(`MatMenuContent`);var Zi=new v(`mat-menu-default-options`,{providedIn:`root`,factory:()=>({overlapTrigger:!1,xPosition:`after`,yPosition:`below`,backdropClass:`cdk-overlay-transparent-backdrop`})});var ee=`_mat-menu-enter`;var Ht=`_mat-menu-exit`;var dt=(()=>{class n{_elementRef=g(nt);_changeDetectorRef=g(gm);_injector=g(ne$1);_keyManager;_xPosition;_yPosition;_firstItemFocusRef;_exitFallbackTimeout;_animationsDisabled=Ar();_allItems;_directDescendantItems=new cs;_classList={};_panelAnimationState=`void`;_animationDone=new te;_isAnimating=or(!1);parentMenu;direction;overlayPanelClass;backdropClass;ariaLabel;ariaLabelledby;ariaDescribedby;get xPosition(){return this._xPosition}set xPosition(t){this._xPosition=t,this.setPositionClasses()}get yPosition(){return this._yPosition}set yPosition(t){this._yPosition=t,this.setPositionClasses()}templateRef;items;lazyContent;overlapTrigger=!1;hasBackdrop;get panelClass(){return this._previousPanelClass}set panelClass(t){let e=this._previousPanelClass,i=V({},this._classList);e&&e.length&&e.split(` `).forEach(r=>{i[r]=!1}),this._previousPanelClass=t,t&&t.length&&(t.split(` `).forEach(r=>{i[r]=!0}),this._elementRef.nativeElement.className=``),this._classList=i}_previousPanelClass=``;get classList(){return this.panelClass}set classList(t){this.panelClass=t}closed=new Pe;close=this.closed;panelId=g(q).getId(`mat-menu-panel-`);constructor(){let t=g(Zi);this.overlayPanelClass=t.overlayPanelClass||``,this._xPosition=t.xPosition,this._yPosition=t.yPosition,this.backdropClass=t.backdropClass,this.overlapTrigger=t.overlapTrigger,this.hasBackdrop=t.hasBackdrop}ngOnInit(){this.setPositionClasses()}ngAfterContentInit(){this._updateDirectDescendants(),this._keyManager=new Q$1(this._directDescendantItems).withWrap().withTypeAhead().withHomeAndEnd().skipPredicate(t=>t.disabled&&!t.disabledInteractive),this._keyManager.tabOut.subscribe(()=>this.closed.emit(`tab`)),this._directDescendantItems.changes.pipe(ov(this._directDescendantItems),ma(t=>Yy(...t.map(e=>e._focused)))).subscribe(t=>this._keyManager.updateActiveItem(t)),this._directDescendantItems.changes.subscribe(t=>{let e=this._keyManager;if(this._panelAnimationState===`enter`&&e.activeItem?._hasFocus()){let i=t.toArray(),r=Math.max(0,Math.min(i.length-1,e.activeItemIndex||0));i[r]&&!i[r].disabled?e.setActiveItem(r):e.setNextItemActive()}})}ngOnDestroy(){this._keyManager?.destroy(),this._directDescendantItems.destroy(),this.closed.complete(),this._firstItemFocusRef?.destroy(),clearTimeout(this._exitFallbackTimeout)}_hovered(){return this._directDescendantItems.changes.pipe(ov(this._directDescendantItems),ma(e=>Yy(...e.map(i=>i._hovered))))}addItem(t){}removeItem(t){}_handleKeydown(t){let e=t.keyCode,i=this._keyManager;switch(e){case 27:Re(t)||(t.preventDefault(),this.closed.emit(`keydown`));break;case 37:this.parentMenu&&this.direction===`ltr`&&this.closed.emit(`keydown`);break;case 39:this.parentMenu&&this.direction===`rtl`&&this.closed.emit(`keydown`);break;default:(e===38||e===40)&&i.setFocusOrigin(`keyboard`),i.onKeydown(t);return}}focusFirstItem(t=`program`){this._firstItemFocusRef?.destroy(),this._firstItemFocusRef=AE(()=>{let e=this._resolvePanel();if(!e||!e.contains(document.activeElement)){let i=this._keyManager;i.setFocusOrigin(t).setFirstItemActive(),!i.activeItem&&e&&e.focus()}},{injector:this._injector})}resetActiveItem(){this._keyManager.setActiveItem(-1)}setElevation(t){}setPositionClasses(t=this.xPosition,e=this.yPosition){this._classList=G(V({},this._classList),{"mat-menu-before":t===`before`,"mat-menu-after":t===`after`,"mat-menu-above":e===`above`,"mat-menu-below":e===`below`}),this._changeDetectorRef.markForCheck()}_onAnimationDone(t){let e=t===Ht;(e||t===ee)&&(e&&(clearTimeout(this._exitFallbackTimeout),this._exitFallbackTimeout=void 0),this._animationDone.next(e?`void`:`enter`),this._isAnimating.set(!1))}_onAnimationStart(t){(t===ee||t===Ht)&&this._isAnimating.set(!0)}_setIsOpen(t){if(this._panelAnimationState=t?`enter`:`void`,t){if(this._keyManager.activeItemIndex===0){let e=this._resolvePanel();e&&(e.scrollTop=0)}}else this._animationsDisabled||(this._exitFallbackTimeout=setTimeout(()=>this._onAnimationDone(Ht),200));this._animationsDisabled&&setTimeout(()=>{this._onAnimationDone(t?ee:Ht)}),this._changeDetectorRef.markForCheck()}_updateDirectDescendants(){this._allItems.changes.pipe(ov(this._allItems)).subscribe(t=>{this._directDescendantItems.reset(t.filter(e=>e._parentMenu===this)),this._directDescendantItems.notifyOnChanges()})}_resolvePanel(){let t=null;return this._directDescendantItems.length&&(t=this._directDescendantItems.first._getHostElement().closest(`[role="menu"]`)),t}static ɵfac=function(e){return new(e||n)};static ɵcmp=(function(){let t=[`*`];function e(i,r){if(i&1){let a=aC();gu(0,`div`,0),jg(`click`,function(){yf(a);let h=pC();return vf(h.closed.emit(`click`))})(`animationstart`,function(h){yf(a);let _=pC();return vf(_._onAnimationStart(h.animationName))})(`animationend`,function(h){yf(a);let _=pC();return vf(_._onAnimationDone(h.animationName))})(`animationcancel`,function(h){yf(a);let _=pC();return vf(_._onAnimationDone(h.animationName))}),gu(1,`div`,1),Du(2),mu()()}if(i&2){let a=pC();Eu(a._classList),Rs(`mat-menu-panel-animations-disabled`,a._animationsDisabled)(`mat-menu-panel-exit-animation`,a._panelAnimationState===`void`)(`mat-menu-panel-animating`,a._isAnimating()),Fg(`id`,a.panelId),No(`aria-label`,a.ariaLabel||null)(`aria-labelledby`,a.ariaLabelledby||null)(`aria-describedby`,a.ariaDescribedby||null)}}return So({type:n,selectors:[[`mat-menu`]],contentQueries:function(r,a,m){if(r&1&&Vg(m,qi,5)(m,xt,5)(m,xt,4),r&2){let h;mC(h=yC())&&(a.lazyContent=h.first),mC(h=yC())&&(a._allItems=h),mC(h=yC())&&(a.items=h)}},viewQuery:function(r,a){if(r&1&&Bg(pr,5),r&2){let m;mC(m=yC())&&(a.templateRef=m.first)}},hostVars:3,hostBindings:function(r,a){r&2&&No(`aria-label`,null)(`aria-labelledby`,null)(`aria-describedby`,null)},inputs:{backdropClass:`backdropClass`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],ariaDescribedby:[0,`aria-describedby`,`ariaDescribedby`],xPosition:`xPosition`,yPosition:`yPosition`,overlapTrigger:[2,`overlapTrigger`,`overlapTrigger`,_u],hasBackdrop:[2,`hasBackdrop`,`hasBackdrop`,i=>i==null?null:_u(i)],panelClass:[0,`class`,`panelClass`],classList:`classList`},outputs:{closed:`closed`,close:`close`},exportAs:[`matMenu`],features:[nm([{provide:ne,useExisting:n}])],ngContentSelectors:t,decls:1,vars:0,consts:[[`tabindex`,`-1`,`role`,`menu`,1,`mat-mdc-menu-panel`,3,`click`,`animationstart`,`animationend`,`animationcancel`,`id`],[1,`mat-mdc-menu-content`]],template:function(r,a){r&1&&(vu(),Mg(0,e,3,12,`ng-template`))},styles:[`mat-menu {
  display: none;
}

.mat-mdc-menu-content {
  margin: 0;
  padding: 8px 0;
  outline: 0;
}
.mat-mdc-menu-content,
.mat-mdc-menu-content .mat-mdc-menu-item .mat-mdc-menu-item-text {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  flex: 1;
  white-space: normal;
  font-family: var(--%NS%mat-menu-item-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-menu-item-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-menu-item-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-menu-item-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-menu-item-label-text-weight, var(--%NS%mat-sys-label-large-weight));
}

@keyframes _mat-menu-enter {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-menu-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-menu-panel {
  min-width: 112px;
  max-width: 280px;
  overflow: auto;
  box-sizing: border-box;
  outline: 0;
  animation: _mat-menu-enter 120ms cubic-bezier(0, 0, 0.2, 1);
  border-radius: var(--%NS%mat-menu-container-shape, var(--%NS%mat-sys-corner-extra-small));
  background-color: var(--%NS%mat-menu-container-color, var(--%NS%mat-sys-surface-container));
  box-shadow: var(--%NS%mat-menu-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
  will-change: transform, opacity;
}
.mat-mdc-menu-panel.mat-menu-panel-exit-animation {
  animation: _mat-menu-exit 100ms 25ms linear forwards;
}
.mat-mdc-menu-panel.mat-menu-panel-animations-disabled {
  animation: none;
}
.mat-mdc-menu-panel.mat-menu-panel-animating {
  pointer-events: none;
}
.mat-mdc-menu-panel.mat-menu-panel-animating:has(.mat-mdc-menu-content:empty) {
  display: none;
}
@media (forced-colors: active) {
  .mat-mdc-menu-panel {
    outline: solid 1px;
  }
}
.mat-mdc-menu-panel .mat-divider {
  border-top-color: var(--%NS%mat-menu-divider-color, var(--%NS%mat-sys-surface-variant));
  margin-bottom: var(--%NS%mat-menu-divider-bottom-spacing, 8px);
  margin-top: var(--%NS%mat-menu-divider-top-spacing, 8px);
}

.mat-mdc-menu-item {
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  padding: 0;
  cursor: pointer;
  width: 100%;
  text-align: left;
  box-sizing: border-box;
  color: inherit;
  font-size: inherit;
  background: none;
  text-decoration: none;
  margin: 0;
  min-height: 48px;
  padding-left: var(--%NS%mat-menu-item-leading-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-trailing-spacing, 12px);
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
  outline: none;
  border: none;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-menu-item::-moz-focus-inner {
  border: 0;
}
[dir=rtl] .mat-mdc-menu-item {
  padding-left: var(--%NS%mat-menu-item-trailing-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-leading-spacing, 12px);
}
.mat-mdc-menu-item:has(.material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp, mat-icon, [matButtonIcon]) {
  padding-left: var(--%NS%mat-menu-item-with-icon-leading-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-with-icon-trailing-spacing, 12px);
}
[dir=rtl] .mat-mdc-menu-item:has(.material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp, mat-icon, [matButtonIcon]) {
  padding-left: var(--%NS%mat-menu-item-with-icon-trailing-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-with-icon-leading-spacing, 12px);
}
.mat-mdc-menu-item, .mat-mdc-menu-item:visited, .mat-mdc-menu-item:link {
  color: var(--%NS%mat-menu-item-label-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-menu-item .mat-icon-no-color,
.mat-mdc-menu-item .mat-mdc-menu-submenu-icon {
  color: var(--%NS%mat-menu-item-icon-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-menu-item[disabled], .mat-mdc-menu-item.mat-mdc-menu-item-disabled {
  cursor: default;
  opacity: 0.38;
}
.mat-mdc-menu-item[disabled]::after, .mat-mdc-menu-item.mat-mdc-menu-item-disabled::after {
  display: block;
  position: absolute;
  content: "";
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.mat-mdc-menu-item:focus {
  outline: 0;
}
.mat-mdc-menu-item .mat-icon {
  flex-shrink: 0;
  margin-right: var(--%NS%mat-menu-item-spacing, 12px);
  height: var(--%NS%mat-menu-item-icon-size, 24px);
  width: var(--%NS%mat-menu-item-icon-size, 24px);
}
[dir=rtl] .mat-mdc-menu-item {
  text-align: right;
}
[dir=rtl] .mat-mdc-menu-item .mat-icon {
  margin-right: 0;
  margin-left: var(--%NS%mat-menu-item-spacing, 12px);
}
.mat-mdc-menu-item:not([disabled]):hover {
  background-color: var(--%NS%mat-menu-item-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-menu-item:not([disabled]).cdk-program-focused, .mat-mdc-menu-item:not([disabled]).cdk-keyboard-focused, .mat-mdc-menu-item:not([disabled]).mat-mdc-menu-item-highlighted {
  background-color: var(--%NS%mat-menu-item-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
}
@media (forced-colors: active) {
  .mat-mdc-menu-item {
    margin-top: 1px;
  }
}

.mat-mdc-menu-submenu-icon {
  width: var(--%NS%mat-menu-item-icon-size, 24px);
  height: 10px;
  fill: currentColor;
  padding-left: var(--%NS%mat-menu-item-spacing, 12px);
}
[dir=rtl] .mat-mdc-menu-submenu-icon {
  padding-right: var(--%NS%mat-menu-item-spacing, 12px);
  padding-left: 0;
}
[dir=rtl] .mat-mdc-menu-submenu-icon polygon {
  transform: scaleX(-1);
  transform-origin: center;
}
@media (forced-colors: active) {
  .mat-mdc-menu-submenu-icon {
    fill: CanvasText;
  }
}

.mat-mdc-menu-item .mat-mdc-menu-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
`],encapsulation:2})})()}return n})();var $i=new v(`mat-menu-scroll-strategy`,{providedIn:`root`,factory:()=>{let n=g(ne$1);return()=>xe(n)}});var ct=/* @__PURE__ */ new WeakMap;var Ki=(()=>{class n{_canHaveBackdrop;_element=g(nt);_viewContainerRef=g(Dr);_menuItemInstance=g(xt,{optional:!0,self:!0});_dir=g(r_,{optional:!0});_focusMonitor=g(We);_ngZone=g(le);_injector=g(ne$1);_scrollStrategy=g($i);_changeDetectorRef=g(gm);_animationsDisabled=Ar();_portal;_overlayRef=null;_menuOpen=!1;_closingActionsSubscription=J.EMPTY;_menuCloseSubscription=J.EMPTY;_pendingRemoval;_parentMaterialMenu;_parentInnerPadding;_openedBy=void 0;get _menu(){return this._menuInternal}set _menu(t){t!==this._menuInternal&&(this._menuInternal=t,this._menuCloseSubscription.unsubscribe(),t?(this._parentMaterialMenu,this._menuCloseSubscription=t.close.subscribe(e=>{this._destroyMenu(e),(e===`click`||e===`tab`)&&this._parentMaterialMenu&&this._parentMaterialMenu.closed.emit(e)})):this._destroyMenu(),this._menuItemInstance?._setTriggersSubmenu(this._triggersSubmenu()))}_menuInternal=null;constructor(t){this._canHaveBackdrop=t;let e=g(ne,{optional:!0});this._parentMaterialMenu=e instanceof dt?e:void 0}ngOnDestroy(){this._menu&&this._ownsMenu(this._menu)&&ct.delete(this._menu),this._pendingRemoval?.unsubscribe(),this._menuCloseSubscription.unsubscribe(),this._closingActionsSubscription.unsubscribe(),this._overlayRef&&(this._overlayRef.dispose(),this._overlayRef=null)}get menuOpen(){return this._menuOpen}get dir(){return this._dir&&this._dir.value===`rtl`?`rtl`:`ltr`}_triggersSubmenu(){return!!(this._menuItemInstance&&this._parentMaterialMenu&&this._menu)}_closeMenu(){this._menu?.close.emit()}_openMenu(t){if(this._triggerIsAriaDisabled())return;let e=this._menu;if(this._menuOpen||!e)return;this._pendingRemoval?.unsubscribe();let i=ct.get(e);ct.set(e,this),i&&i!==this&&i._closeMenu();let r=this._createOverlay(e),a=r.getConfig(),m=a.positionStrategy;this._setPosition(e,m),this._canHaveBackdrop?a.hasBackdrop=e.hasBackdrop==null?!this._triggersSubmenu():e.hasBackdrop:a.hasBackdrop=e.hasBackdrop??!1,r.hasAttached()||(r.attach(this._getPortal(e)),e.lazyContent?.attach(this.menuData)),this._closingActionsSubscription=this._menuClosingActions().subscribe(()=>this._closeMenu()),e.parentMenu=this._triggersSubmenu()?this._parentMaterialMenu:void 0,e.direction=this.dir,t&&e.focusFirstItem(this._openedBy||`program`),this._setIsMenuOpen(!0),e instanceof dt&&(e._setIsOpen(!0),e._directDescendantItems.changes.pipe(iv(e.close)).subscribe(()=>{m.withLockedPosition(!1).reapplyLastPosition(),m.withLockedPosition(!0)}))}focus(t,e){this._focusMonitor&&t?this._focusMonitor.focusVia(this._element,t,e):this._element.nativeElement.focus(e)}_destroyMenu(t){let e=this._overlayRef,i=this._menu;!e||!this.menuOpen||(this._closingActionsSubscription.unsubscribe(),this._pendingRemoval?.unsubscribe(),i instanceof dt&&this._ownsMenu(i)?(this._pendingRemoval=i._animationDone.pipe(kt(1)).subscribe(()=>{e.detach(),ct.has(i)||i.lazyContent?.detach()}),i._setIsOpen(!1)):(e.detach(),i?.lazyContent?.detach()),i&&this._ownsMenu(i)&&ct.delete(i),this.restoreFocus&&(t===`keydown`||!this._openedBy||!this._triggersSubmenu())&&this.focus(this._openedBy),this._openedBy=void 0,this._setIsMenuOpen(!1))}_setIsMenuOpen(t){t!==this._menuOpen&&(this._menuOpen=t,this._menuOpen?this.menuOpened.emit():this.menuClosed.emit(),this._triggersSubmenu()&&this._menuItemInstance._setHighlighted(t),this._changeDetectorRef.markForCheck())}_createOverlay(t){if(!this._overlayRef){let e=this._getOverlayConfig(t);this._subscribeToPositions(t,e.positionStrategy),this._overlayRef=xt$1(this._injector,e),this._overlayRef.keydownEvents().subscribe(i=>{this._menu instanceof dt&&this._menu._handleKeydown(i)})}return this._overlayRef}_getOverlayConfig(t){return new K$1({positionStrategy:we(this._injector,this._getOverlayOrigin()).withLockedPosition().withGrowAfterOpen().withTransformOriginOn(`.mat-menu-panel, .mat-mdc-menu-panel`),backdropClass:t.backdropClass||`cdk-overlay-transparent-backdrop`,panelClass:t.overlayPanelClass,scrollStrategy:this._scrollStrategy(),direction:this._dir||`ltr`,disableAnimations:this._animationsDisabled})}_subscribeToPositions(t,e){t.setPositionClasses&&e.positionChanges.subscribe(i=>{this._ngZone.run(()=>{let r=i.connectionPair.overlayX===`start`?`after`:`before`,a=i.connectionPair.overlayY===`top`?`below`:`above`;t.setPositionClasses(r,a)})})}_setPosition(t,e){let[i,r]=t.xPosition===`before`?[`end`,`start`]:[`start`,`end`],[a,m]=t.yPosition===`above`?[`bottom`,`top`]:[`top`,`bottom`],[h,_]=[a,m],[y,Wt]=[i,r],ht=0;if(this._triggersSubmenu()){if(Wt=i=t.xPosition===`before`?`start`:`end`,r=y=i===`end`?`start`:`end`,this._parentMaterialMenu){if(this._parentInnerPadding==null){let le=this._parentMaterialMenu.items.first;this._parentInnerPadding=le?le._getHostElement().offsetTop:0}ht=a===`bottom`?this._parentInnerPadding:-this._parentInnerPadding}}else t.overlapTrigger||(h=a===`top`?`bottom`:`top`,_=m===`top`?`bottom`:`top`);e.withPositions([{originX:i,originY:h,overlayX:y,overlayY:a,offsetY:ht},{originX:r,originY:h,overlayX:Wt,overlayY:a,offsetY:ht},{originX:i,originY:_,overlayX:y,overlayY:m,offsetY:-ht},{originX:r,originY:_,overlayX:Wt,overlayY:m,offsetY:-ht}])}_menuClosingActions(){let t=this._getOutsideClickStream(this._overlayRef),e=this._overlayRef.detachments(),i=this._parentMaterialMenu?this._parentMaterialMenu.closed:ot(),r=this._parentMaterialMenu?this._parentMaterialMenu._hovered().pipe(Ot(a=>this._menuOpen&&a!==this._menuItemInstance)):ot();return Yy(t,i,r,e)}_getPortal(t){return(!this._portal||this._portal.templateRef!==t.templateRef)&&(this._portal=new $(t.templateRef,this._viewContainerRef)),this._portal}_ownsMenu(t){return ct.get(t)===this}_triggerIsAriaDisabled(){return _u(this._element.nativeElement.getAttribute(`aria-disabled`))}static ɵfac=function(e){ZI()};static ɵdir=Mo({type:n})}return n})();var Oi=(()=>{class n extends Ki{_cleanupTouchstart;_hoverSubscription=J.EMPTY;get _deprecatedMatMenuTriggerFor(){return this.menu}set _deprecatedMatMenuTriggerFor(t){this.menu=t}get menu(){return this._menu}set menu(t){this._menu=t}menuData;restoreFocus=!0;menuOpened=new Pe;onMenuOpen=this.menuOpened;menuClosed=new Pe;onMenuClose=this.menuClosed;constructor(){super(!0);let t=g(hr);this._cleanupTouchstart=t.listen(this._element.nativeElement,`touchstart`,e=>{W(e)||(this._openedBy=`touch`)},{passive:!0})}triggersSubmenu(){return super._triggersSubmenu()}toggleMenu(){return this.menuOpen?this.closeMenu():this.openMenu()}openMenu(){this._openMenu(!0)}closeMenu(){this._closeMenu()}updatePosition(){this._overlayRef?.updatePosition()}ngAfterContentInit(){this._handleHover()}ngOnDestroy(){super.ngOnDestroy(),this._cleanupTouchstart(),this._hoverSubscription.unsubscribe()}_getOverlayOrigin(){return this._element}_getOutsideClickStream(t){return t.backdropClick()}_handleMousedown(t){V$1(t)||(this._openedBy=t.button===0?`mouse`:void 0,this.triggersSubmenu()&&t.preventDefault())}_handleKeydown(t){let e=t.keyCode;(e===13||e===32)&&(this._openedBy=`keyboard`),this.triggersSubmenu()&&(e===39&&this.dir===`ltr`||e===37&&this.dir===`rtl`)&&(this._openedBy=`keyboard`,this.openMenu())}_handleClick(t){this.triggersSubmenu()?(t.stopPropagation(),this.openMenu()):this.toggleMenu()}_handleHover(){this.triggersSubmenu()&&this._parentMaterialMenu&&(this._hoverSubscription=this._parentMaterialMenu._hovered().subscribe(t=>{t===this._menuItemInstance&&!t.disabled&&this._parentMaterialMenu?._panelAnimationState!==`void`&&(this._openedBy=`mouse`,this._openMenu(!1))}))}static ɵfac=function(e){return new(e||n)};static ɵdir=Mo({type:n,selectors:[[``,`mat-menu-trigger-for`,``],[``,`matMenuTriggerFor`,``]],hostAttrs:[1,`mat-mdc-menu-trigger`],hostVars:3,hostBindings:function(e,i){e&1&&Pg(`click`,function(a){return i._handleClick(a)})(`mousedown`,function(a){return i._handleMousedown(a)})(`keydown`,function(a){return i._handleKeydown(a)}),e&2&&No(`aria-haspopup`,i.menu?`menu`:null)(`aria-expanded`,i.menuOpen)(`aria-controls`,i.menuOpen?i.menu?.panelId:null)},inputs:{_deprecatedMatMenuTriggerFor:[0,`mat-menu-trigger-for`,`_deprecatedMatMenuTriggerFor`],menu:[0,`matMenuTriggerFor`,`menu`],menuData:[0,`matMenuTriggerData`,`menuData`],restoreFocus:[0,`matMenuTriggerRestoreFocus`,`restoreFocus`]},outputs:{menuOpened:`menuOpened`,onMenuOpen:`onMenuOpen`,menuClosed:`menuClosed`,onMenuClose:`onMenuClose`},exportAs:[`matMenuTrigger`],features:[Tg]})}return n})();var Li=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[rn,En,hy,ue]})}return n})();var tn=new v(`MAT_DRAWER_DEFAULT_AUTOSIZE`,{providedIn:`root`,factory:()=>!1});var oe=new v(`MAT_DRAWER_CONTAINER`);var yt=(()=>{class n extends jn{_platform=g(nr);_changeDetectorRef=g(gm);_element=g(nt);_ngZone=g(le);_isInert=!1;_container=g(re);ngAfterContentInit(){this._container._contentMarginChanges.subscribe(()=>this._changeDetectorRef.markForCheck())}_drawerToggled(t){t.opened?this._ngZone.runOutsideAngular(()=>{t._animationEnd.pipe(Xy(50),kt(1)).subscribe(()=>this._updateInert())}):this._updateInert()}_drawerModeChanged(){this._updateInert()}_updateInert(){let t=this._container._isShowingBackdrop();if(t!==this._isInert){let e=this._element.nativeElement;this._isInert=t,t?e.setAttribute(`inert`,`true`):e.removeAttribute(`inert`)}}_shouldBeHidden(){if(this._platform.isBrowser)return!1;let{start:t,end:e}=this._container;return t!=null&&t.mode!==`over`&&t.opened||e!=null&&e.mode!==`over`&&e.opened}static ɵfac=(()=>{let t;return function(i){return(t||(t=Gp(n)))(i||n)}})();static ɵcmp=(function(){return So({type:n,selectors:[[`mat-drawer-content`]],hostAttrs:[1,`mat-drawer-content`],hostVars:6,hostBindings:function(i,r){i&2&&(Gg(`margin-left`,r._container._contentMargins.left,`px`)(`margin-right`,r._container._contentMargins.right,`px`),Rs(`mat-drawer-content-hidden`,r._shouldBeHidden()))},features:[nm([{provide:jn,useExisting:n}]),Tg],ngContentSelectors:[`*`],decls:1,vars:0,template:function(i,r){i&1&&(vu(),Du(0))},encapsulation:2})})()}return n})();var ae=(()=>{class n{_elementRef=g(nt);_focusTrapFactory=g(st);_focusMonitor=g(We);_platform=g(nr);_ngZone=g(le);_renderer=g(hr);_interactivityChecker=g(De);_doc=g(L);_isAnimating=!1;_container=g(oe,{optional:!0});_focusTrap=null;_elementFocusedBeforeDrawerWasOpened=null;_eventCleanups;_isAttached=!1;_anchor=null;get position(){return this._position}set position(t){t=t===`end`?`end`:`start`,t!==this._position&&(this._isAttached&&this._updatePositionInParent(t),this._position=t,this.onPositionChanged.emit())}_position=`start`;get mode(){return this._mode}set mode(t){this._mode=t,this._updateFocusTrapState(),this._modeChanged.next(),this._getContent()?._drawerModeChanged()}_mode=`over`;get disableClose(){return this._disableClose}set disableClose(t){this._disableClose=Ws(t)}_disableClose=!1;get autoFocus(){return this._autoFocus??(this.mode===`side`?`dialog`:`first-tabbable`)}set autoFocus(t){(t===`true`||t===`false`||t==null)&&(t=Ws(t)),this._autoFocus=t}_autoFocus;get opened(){return this._opened()}set opened(t){this.toggle(Ws(t))}_opened=or(!1);_openedVia=null;_animationStarted=new te;_animationEnd=new te;openedChange=new Pe(!0);_openedStream=this.openedChange.pipe(Ot(t=>t),Q(()=>{}));openedStart=this._animationStarted.pipe(Ot(()=>this.opened),Ea(void 0));_closedStream=this.openedChange.pipe(Ot(t=>!t),Q(()=>{}));closedStart=this._animationStarted.pipe(Ot(()=>!this.opened),Ea(void 0));_destroyed=new te;onPositionChanged=new Pe;_content;_modeChanged=new te;_injector=g(ne$1);_changeDetectorRef=g(gm);constructor(){this.openedChange.pipe(iv(this._destroyed)).subscribe(t=>{t?(this._elementFocusedBeforeDrawerWasOpened=this._doc.activeElement,this._takeFocus()):this._isFocusWithinDrawer()&&this._restoreFocus(this._openedVia||`program`)}),this._eventCleanups=this._ngZone.runOutsideAngular(()=>{let t=this._renderer,e=this._elementRef.nativeElement;return[t.listen(e,`keydown`,i=>{i.keyCode===27&&!this.disableClose&&!Re(i)&&this._ngZone.run(()=>{this.close(),i.stopPropagation(),i.preventDefault()})}),t.listen(e,`transitionend`,this._handleTransitionEvent),t.listen(e,`transitioncancel`,this._handleTransitionEvent)]}),this._animationEnd.subscribe(()=>{this.openedChange.emit(this.opened)})}_focusByCssSelector(t,e){let i=this._elementRef.nativeElement.querySelector(t);i&&(this._interactivityChecker.isFocusable(i)||(i.tabIndex=-1,this._ngZone.runOutsideAngular(()=>{let r=()=>{a(),m(),i.removeAttribute(`tabindex`)},a=this._renderer.listen(i,`blur`,r),m=this._renderer.listen(i,`mousedown`,r)})),i.focus(e))}_takeFocus(){if(!this._focusTrap)return;let t=this._elementRef.nativeElement;switch(this.autoFocus){case!1:case`dialog`:return;case!0:case`first-tabbable`:AE(()=>{let e=this._isAnimating?{preventScroll:!0}:void 0;!this._focusTrap.focusInitialElement(e)&&typeof t.focus==`function`&&t.focus(e)},{injector:this._injector});break;case`first-heading`:this._focusByCssSelector(`h1, h2, h3, h4, h5, h6, [role="heading"]`);break;default:this._focusByCssSelector(this.autoFocus)}}_restoreFocus(t){this.autoFocus!==`dialog`&&(this._elementFocusedBeforeDrawerWasOpened?this._focusMonitor.focusVia(this._elementFocusedBeforeDrawerWasOpened,t):this._elementRef.nativeElement.blur(),this._elementFocusedBeforeDrawerWasOpened=null)}_isFocusWithinDrawer(){let t=this._doc.activeElement;return!!t&&this._elementRef.nativeElement.contains(t)}ngAfterViewInit(){this._isAttached=!0,this._position===`end`&&this._updatePositionInParent(`end`),this._platform.isBrowser&&(this._focusTrap=this._focusTrapFactory.create(this._elementRef.nativeElement),this._updateFocusTrapState())}ngOnDestroy(){this._eventCleanups.forEach(t=>t()),this._focusTrap?.destroy(),this._anchor?.remove(),this._anchor=null,this._animationStarted.complete(),this._animationEnd.complete(),this._modeChanged.complete(),this._destroyed.next(),this._destroyed.complete()}open(t){return this.toggle(!0,t)}close(){return this.toggle(!1)}_closeViaBackdropClick(){return this._setOpen(!1,!0,`mouse`)}toggle(t=!this.opened,e){t&&e&&(this._openedVia=e);let i=this._setOpen(t,!t&&this._isFocusWithinDrawer(),this._openedVia||`program`);return t||(this._openedVia=null),i}_setOpen(t,e,i){return t===this.opened?Promise.resolve(t?`open`:`close`):(this._opened.set(t),this._getContent()?._drawerToggled(this),this._container?._transitionsEnabled?this._isAnimating?(this._setIsAnimating(!1),this._simulateAnimation()):(this._setIsAnimating(!0),setTimeout(()=>this._animationStarted.next())):this._simulateAnimation(),this._elementRef.nativeElement.classList.toggle(`mat-drawer-opened`,t),!t&&e&&this._restoreFocus(i),this._changeDetectorRef.markForCheck(),this._updateFocusTrapState(),new Promise(r=>{this.openedChange.pipe(kt(1)).subscribe(a=>r(a?`open`:`close`))}))}_getContent(){return this._container?._content||this._container?._userContent}_setIsAnimating(t){t!==this._isAnimating&&(this._isAnimating=t,this._elementRef.nativeElement.classList.toggle(`mat-drawer-animating`,t))}_simulateAnimation(){setTimeout(()=>{this._animationStarted.next(),this._animationEnd.next()})}_getWidth(){return this._elementRef.nativeElement.offsetWidth||0}_updateFocusTrapState(){this._focusTrap&&(this._focusTrap.enabled=this.opened&&!!this._container?._isShowingBackdrop())}_updatePositionInParent(t){if(!this._platform.isBrowser)return;let e=this._elementRef.nativeElement,i=e.parentNode;t===`end`?(this._anchor||(this._anchor=this._doc.createComment(`mat-drawer-anchor`),i.insertBefore(this._anchor,e)),i.appendChild(e)):this._anchor&&this._anchor.parentNode.insertBefore(e,this._anchor)}_handleTransitionEvent=t=>{let e=this._elementRef.nativeElement;t.target===e&&this._ngZone.run(()=>{t.type===`transitionend`&&this._setIsAnimating(!1),this._animationEnd.next(t)})};static ɵfac=function(e){return new(e||n)};static ɵcmp=(function(){let t=[`content`];return So({type:n,selectors:[[`mat-drawer`]],viewQuery:function(r,a){if(r&1&&Bg(t,5),r&2){let m;mC(m=yC())&&(a._content=m.first)}},hostAttrs:[1,`mat-drawer`],hostVars:12,hostBindings:function(r,a){r&2&&(No(`align`,null)(`tabIndex`,a.mode!==`side`?`-1`:null),Gg(`visibility`,!a._container&&!a.opened?`hidden`:null),Rs(`mat-drawer-end`,a.position===`end`)(`mat-drawer-over`,a.mode===`over`)(`mat-drawer-push`,a.mode===`push`)(`mat-drawer-side`,a.mode===`side`))},inputs:{position:`position`,mode:`mode`,disableClose:`disableClose`,autoFocus:`autoFocus`,opened:`opened`},outputs:{openedChange:`openedChange`,_openedStream:`opened`,openedStart:`openedStart`,_closedStream:`closed`,closedStart:`closedStart`,onPositionChanged:`positionChanged`},exportAs:[`matDrawer`],ngContentSelectors:[`*`],decls:3,vars:0,consts:[[`content`,``],[`cdkScrollable`,``,1,`mat-drawer-inner-container`]],template:function(r,a){r&1&&(vu(),Es(0,`div`,1,0),Du(2),hu())},dependencies:[jn],encapsulation:2})})()}return n})();var re=(()=>{class n{_dir=g(r_,{optional:!0});_element=g(nt);_ngZone=g(le);_changeDetectorRef=g(gm);_animationDisabled=Ar();_transitionsEnabled=!1;_allDrawers;_drawers=new cs;_content;_userContent;get start(){return this._start}get end(){return this._end}get autosize(){return this._autosize}set autosize(t){this._autosize=Ws(t)}_autosize=g(tn);get hasBackdrop(){return this._drawerHasBackdrop(this._start)||this._drawerHasBackdrop(this._end)}set hasBackdrop(t){this._backdropOverride=t==null?null:Ws(t)}_backdropOverride=null;backdropClick=new Pe;_start=null;_end=null;_left=null;_right=null;_destroyed=new te;_doCheckSubject=new te;_contentMargins={left:null,right:null};_contentMarginChanges=new te;get scrollable(){return this._userContent||this._content}_injector=g(ne$1);constructor(){let t=g(nr),e=g(rt$1);this._dir?.change.pipe(iv(this._destroyed)).subscribe(()=>{this._validateDrawers(),this.updateContentMargins()}),e.change().pipe(iv(this._destroyed)).subscribe(()=>this.updateContentMargins()),!this._animationDisabled&&t.isBrowser&&this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{this._element.nativeElement.classList.add(`mat-drawer-transition`),this._transitionsEnabled=!0},200)})}ngAfterContentInit(){this._allDrawers.changes.pipe(ov(this._allDrawers),iv(this._destroyed)).subscribe(t=>{this._drawers.reset(t.filter(e=>!e._container||e._container===this)),this._drawers.notifyOnChanges()}),this._drawers.changes.pipe(ov(null)).subscribe(()=>{this._validateDrawers(),this._drawers.forEach(t=>{this._watchDrawerToggle(t),this._watchDrawerPosition(t),this._watchDrawerMode(t)}),(!this._drawers.length||this._isDrawerOpen(this._start)||this._isDrawerOpen(this._end))&&this.updateContentMargins(),this._changeDetectorRef.markForCheck()}),this._ngZone.runOutsideAngular(()=>{this._doCheckSubject.pipe(Dd(10),iv(this._destroyed)).subscribe(()=>this.updateContentMargins())})}ngOnDestroy(){this._contentMarginChanges.complete(),this._doCheckSubject.complete(),this._drawers.destroy(),this._destroyed.next(),this._destroyed.complete()}open(){this._drawers.forEach(t=>t.open())}close(){this._drawers.forEach(t=>t.close())}updateContentMargins(){let t=0,e=0;if(this._left&&this._left.opened){if(this._left.mode==`side`)t+=this._left._getWidth();else if(this._left.mode==`push`){let i=this._left._getWidth();t+=i,e-=i}}if(this._right&&this._right.opened){if(this._right.mode==`side`)e+=this._right._getWidth();else if(this._right.mode==`push`){let i=this._right._getWidth();e+=i,t-=i}}t=t||null,e=e||null,(t!==this._contentMargins.left||e!==this._contentMargins.right)&&(this._contentMargins={left:t,right:e},this._ngZone.run(()=>this._contentMarginChanges.next(this._contentMargins)))}ngDoCheck(){this._autosize&&this._isPushed()&&this._ngZone.runOutsideAngular(()=>this._doCheckSubject.next())}_watchDrawerToggle(t){t._animationStarted.pipe(iv(this._drawers.changes)).subscribe(()=>{this.updateContentMargins(),this._changeDetectorRef.markForCheck()}),t.mode!==`side`&&t.openedChange.pipe(iv(this._drawers.changes)).subscribe(()=>this._setContainerClass(t.opened))}_watchDrawerPosition(t){t.onPositionChanged.pipe(iv(this._drawers.changes)).subscribe(()=>{AE({read:()=>this._validateDrawers()},{injector:this._injector})})}_watchDrawerMode(t){t._modeChanged.pipe(iv(Yy(this._drawers.changes,this._destroyed))).subscribe(()=>{this.updateContentMargins(),this._changeDetectorRef.markForCheck()})}_setContainerClass(t){let e=this._element.nativeElement.classList,i=`mat-drawer-container-has-open`;t?e.add(i):e.remove(i)}_validateDrawers(){this._start=this._end=null,this._drawers.forEach(t=>{t.position==`end`?(this._end,this._end=t):(this._start,this._start=t)}),this._right=this._left=null,this._dir&&this._dir.value===`rtl`?(this._left=this._end,this._right=this._start):(this._left=this._start,this._right=this._end)}_isPushed(){return this._isDrawerOpen(this._start)&&this._start.mode!=`over`||this._isDrawerOpen(this._end)&&this._end.mode!=`over`}_onBackdropClicked(){this.backdropClick.emit(),this._closeModalDrawersViaBackdrop()}_closeModalDrawersViaBackdrop(){[this._start,this._end].filter(t=>t&&!t.disableClose&&this._drawerHasBackdrop(t)).forEach(t=>t._closeViaBackdropClick())}_isShowingBackdrop(){return this._isDrawerOpen(this._start)&&this._drawerHasBackdrop(this._start)||this._isDrawerOpen(this._end)&&this._drawerHasBackdrop(this._end)}_isDrawerOpen(t){return t!=null&&t.opened}_drawerHasBackdrop(t){return this._backdropOverride==null?!!t&&t.mode!==`side`:this._backdropOverride}static ɵfac=function(e){return new(e||n)};static ɵcmp=(function(){let t=[[[`mat-drawer`],[`mat-sidenav`]],[[`mat-drawer-content`],[`mat-sidenav-content`]],`*`],e=[`mat-drawer, mat-sidenav`,`mat-drawer-content, mat-sidenav-content`,`*`];function i(a,m){if(a&1){let h=aC();Es(0,`div`,1),Pg(`click`,function(){yf(h);let y=pC();return vf(y._onBackdropClicked())}),hu()}if(a&2){let h=pC();Rs(`mat-drawer-shown`,h._isShowingBackdrop())}}function r(a,m){a&1&&(Es(0,`mat-drawer-content`),Du(1,2),hu())}return So({type:n,selectors:[[`mat-drawer-container`]],contentQueries:function(m,h,_){if(m&1&&Vg(_,yt,5)(_,ae,5),m&2){let y;mC(y=yC())&&(h._content=y.first),mC(y=yC())&&(h._allDrawers=y)}},viewQuery:function(m,h){if(m&1&&Bg(yt,5),m&2){let _;mC(_=yC())&&(h._userContent=_.first)}},hostAttrs:[1,`mat-drawer-container`],hostVars:2,hostBindings:function(m,h){m&2&&Rs(`mat-drawer-container-explicit-backdrop`,h._backdropOverride)},inputs:{autosize:`autosize`,hasBackdrop:`hasBackdrop`},outputs:{backdropClick:`backdropClick`},exportAs:[`matDrawerContainer`],features:[nm([{provide:oe,useExisting:n}])],ngContentSelectors:e,decls:4,vars:2,consts:[[1,`mat-drawer-backdrop`,3,`mat-drawer-shown`],[1,`mat-drawer-backdrop`,3,`click`]],template:function(m,h){m&1&&(vu(t),Kw(0,i,1,2,`div`,0),Du(1),Du(2,1),Kw(3,r,2,0,`mat-drawer-content`)),m&2&&(Jw(h.hasBackdrop?0:-1),QE(3),Jw(h._content?-1:3))},dependencies:[yt],styles:[`.mat-drawer-container {
  position: relative;
  z-index: 1;
  color: var(--%NS%mat-sidenav-content-text-color, var(--%NS%mat-sys-on-background));
  background-color: var(--%NS%mat-sidenav-content-background-color, var(--%NS%mat-sys-background));
  box-sizing: border-box;
  display: block;
  overflow: hidden;
}
.mat-drawer-container[fullscreen] {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
}
.mat-drawer-container[fullscreen].mat-drawer-container-has-open {
  overflow: hidden;
}
.mat-drawer-container.mat-drawer-container-explicit-backdrop .mat-drawer-side {
  z-index: 3;
}
.mat-drawer-container.ng-animate-disabled .mat-drawer-backdrop,
.mat-drawer-container.ng-animate-disabled .mat-drawer-content, .ng-animate-disabled .mat-drawer-container .mat-drawer-backdrop,
.ng-animate-disabled .mat-drawer-container .mat-drawer-content {
  transition: none;
}

.mat-drawer-backdrop {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  z-index: 3;
  visibility: hidden;
}
.mat-drawer-backdrop.mat-drawer-shown {
  visibility: visible;
  background-color: var(--%NS%mat-sidenav-scrim-color, color-mix(in srgb, var(--%NS%mat-sys-neutral-variant20) 40%, transparent));
}
.mat-drawer-transition .mat-drawer-backdrop {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: background-color, visibility;
}
@media (forced-colors: active) {
  .mat-drawer-backdrop {
    opacity: 0.5;
  }
}

.mat-drawer-content {
  position: relative;
  z-index: 1;
  display: block;
  height: 100%;
  overflow: auto;
}
.mat-drawer-content.mat-drawer-content-hidden {
  opacity: 0;
}
.mat-drawer-transition .mat-drawer-content {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: transform, margin-left, margin-right;
}

.mat-drawer {
  position: relative;
  z-index: 4;
  color: var(--%NS%mat-sidenav-container-text-color, var(--%NS%mat-sys-on-surface-variant));
  box-shadow: var(--%NS%mat-sidenav-container-elevation-shadow, none);
  background-color: var(--%NS%mat-sidenav-container-background-color, var(--%NS%mat-sys-surface));
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  width: var(--%NS%mat-sidenav-container-width, 360px);
  display: block;
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 3;
  outline: 0;
  box-sizing: border-box;
  overflow-y: auto;
  transform: translate3d(-100%, 0, 0);
}
@media (forced-colors: active) {
  .mat-drawer, [dir=rtl] .mat-drawer.mat-drawer-end {
    border-right: solid 1px currentColor;
  }
}
@media (forced-colors: active) {
  [dir=rtl] .mat-drawer, .mat-drawer.mat-drawer-end {
    border-left: solid 1px currentColor;
    border-right: none;
  }
}
.mat-drawer.mat-drawer-side {
  z-index: 2;
}
.mat-drawer.mat-drawer-end {
  right: 0;
  transform: translate3d(100%, 0, 0);
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
[dir=rtl] .mat-drawer {
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transform: translate3d(100%, 0, 0);
}
[dir=rtl] .mat-drawer.mat-drawer-end {
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  left: 0;
  right: auto;
  transform: translate3d(-100%, 0, 0);
}
.mat-drawer-transition .mat-drawer {
  transition: transform 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) {
  visibility: hidden;
  box-shadow: none;
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) .mat-drawer-inner-container {
  display: none;
}
.mat-drawer.mat-drawer-opened.mat-drawer-opened {
  transform: none;
}

.mat-drawer-side {
  box-shadow: none;
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
}
.mat-drawer-side.mat-drawer-end {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side.mat-drawer-end {
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
  border-left: none;
}

.mat-drawer-inner-container {
  width: 100%;
  height: 100%;
  overflow: auto;
}

.mat-sidenav-fixed {
  position: fixed;
}
`],encapsulation:2})})()}return n})();var Gt=(()=>{class n extends yt{static ɵfac=(()=>{let t;return function(i){return(t||(t=Gp(n)))(i||n)}})();static ɵcmp=(function(){return So({type:n,selectors:[[`mat-sidenav-content`]],hostAttrs:[1,`mat-drawer-content`,`mat-sidenav-content`],features:[nm([{provide:jn,useExisting:n},{provide:yt,useExisting:n}]),Tg],ngContentSelectors:[`*`],decls:1,vars:0,template:function(i,r){i&1&&(vu(),Du(0))},encapsulation:2})})()}return n})();var se=(()=>{class n extends ae{get fixedInViewport(){return this._fixedInViewport}set fixedInViewport(t){this._fixedInViewport=Ws(t)}_fixedInViewport=!1;get fixedTopGap(){return this._fixedTopGap}set fixedTopGap(t){this._fixedTopGap=Ve(t)}_fixedTopGap=0;get fixedBottomGap(){return this._fixedBottomGap}set fixedBottomGap(t){this._fixedBottomGap=Ve(t)}_fixedBottomGap=0;static ɵfac=(()=>{let t;return function(i){return(t||(t=Gp(n)))(i||n)}})();static ɵcmp=(function(){return So({type:n,selectors:[[`mat-sidenav`]],hostAttrs:[1,`mat-drawer`,`mat-sidenav`],hostVars:16,hostBindings:function(i,r){i&2&&(No(`tabIndex`,r.mode!==`side`?`-1`:null)(`align`,null),Gg(`top`,r.fixedInViewport?r.fixedTopGap:null,`px`)(`bottom`,r.fixedInViewport?r.fixedBottomGap:null,`px`),Rs(`mat-drawer-end`,r.position===`end`)(`mat-drawer-over`,r.mode===`over`)(`mat-drawer-push`,r.mode===`push`)(`mat-drawer-side`,r.mode===`side`)(`mat-sidenav-fixed`,r.fixedInViewport))},inputs:{fixedInViewport:`fixedInViewport`,fixedTopGap:`fixedTopGap`,fixedBottomGap:`fixedBottomGap`},exportAs:[`matSidenav`],features:[nm([{provide:ae,useExisting:n}]),Tg],ngContentSelectors:[`*`],decls:3,vars:0,consts:[[`content`,``],[`cdkScrollable`,``,1,`mat-drawer-inner-container`]],template:function(i,r){i&1&&(vu(),Es(0,`div`,1,0),Du(2),hu())},dependencies:[jn],encapsulation:2})})()}return n})();var Pi=(()=>{class n extends re{_allDrawers=void 0;_content=void 0;static ɵfac=(()=>{let t;return function(i){return(t||(t=Gp(n)))(i||n)}})();static ɵcmp=(function(){let t=[[[`mat-drawer`],[`mat-sidenav`]],[[`mat-drawer-content`],[`mat-sidenav-content`]],`*`],e=[`mat-drawer, mat-sidenav`,`mat-drawer-content, mat-sidenav-content`,`*`];function i(a,m){if(a&1){let h=aC();Es(0,`div`,1),Pg(`click`,function(){yf(h);let y=pC();return vf(y._onBackdropClicked())}),hu()}if(a&2){let h=pC();Rs(`mat-drawer-shown`,h._isShowingBackdrop())}}function r(a,m){a&1&&(Es(0,`mat-sidenav-content`),Du(1,2),hu())}return So({type:n,selectors:[[`mat-sidenav-container`]],contentQueries:function(m,h,_){if(m&1&&Vg(_,Gt,5)(_,se,5),m&2){let y;mC(y=yC())&&(h._content=y.first),mC(y=yC())&&(h._allDrawers=y)}},hostAttrs:[1,`mat-drawer-container`,`mat-sidenav-container`],hostVars:2,hostBindings:function(m,h){m&2&&Rs(`mat-drawer-container-explicit-backdrop`,h._backdropOverride)},exportAs:[`matSidenavContainer`],features:[nm([{provide:oe,useExisting:n},{provide:re,useExisting:n}]),Tg],ngContentSelectors:e,decls:4,vars:2,consts:[[1,`mat-drawer-backdrop`,3,`mat-drawer-shown`],[1,`mat-drawer-backdrop`,3,`click`]],template:function(m,h){m&1&&(vu(t),Kw(0,i,1,2,`div`,0),Du(1),Du(2,1),Kw(3,r,2,0,`mat-sidenav-content`)),m&2&&(Jw(h.hasBackdrop?0:-1),QE(3),Jw(h._content?-1:3))},dependencies:[Gt],styles:[`.mat-drawer-container {
  position: relative;
  z-index: 1;
  color: var(--%NS%mat-sidenav-content-text-color, var(--%NS%mat-sys-on-background));
  background-color: var(--%NS%mat-sidenav-content-background-color, var(--%NS%mat-sys-background));
  box-sizing: border-box;
  display: block;
  overflow: hidden;
}
.mat-drawer-container[fullscreen] {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
}
.mat-drawer-container[fullscreen].mat-drawer-container-has-open {
  overflow: hidden;
}
.mat-drawer-container.mat-drawer-container-explicit-backdrop .mat-drawer-side {
  z-index: 3;
}
.mat-drawer-container.ng-animate-disabled .mat-drawer-backdrop,
.mat-drawer-container.ng-animate-disabled .mat-drawer-content, .ng-animate-disabled .mat-drawer-container .mat-drawer-backdrop,
.ng-animate-disabled .mat-drawer-container .mat-drawer-content {
  transition: none;
}

.mat-drawer-backdrop {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  z-index: 3;
  visibility: hidden;
}
.mat-drawer-backdrop.mat-drawer-shown {
  visibility: visible;
  background-color: var(--%NS%mat-sidenav-scrim-color, color-mix(in srgb, var(--%NS%mat-sys-neutral-variant20) 40%, transparent));
}
.mat-drawer-transition .mat-drawer-backdrop {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: background-color, visibility;
}
@media (forced-colors: active) {
  .mat-drawer-backdrop {
    opacity: 0.5;
  }
}

.mat-drawer-content {
  position: relative;
  z-index: 1;
  display: block;
  height: 100%;
  overflow: auto;
}
.mat-drawer-content.mat-drawer-content-hidden {
  opacity: 0;
}
.mat-drawer-transition .mat-drawer-content {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: transform, margin-left, margin-right;
}

.mat-drawer {
  position: relative;
  z-index: 4;
  color: var(--%NS%mat-sidenav-container-text-color, var(--%NS%mat-sys-on-surface-variant));
  box-shadow: var(--%NS%mat-sidenav-container-elevation-shadow, none);
  background-color: var(--%NS%mat-sidenav-container-background-color, var(--%NS%mat-sys-surface));
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  width: var(--%NS%mat-sidenav-container-width, 360px);
  display: block;
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 3;
  outline: 0;
  box-sizing: border-box;
  overflow-y: auto;
  transform: translate3d(-100%, 0, 0);
}
@media (forced-colors: active) {
  .mat-drawer, [dir=rtl] .mat-drawer.mat-drawer-end {
    border-right: solid 1px currentColor;
  }
}
@media (forced-colors: active) {
  [dir=rtl] .mat-drawer, .mat-drawer.mat-drawer-end {
    border-left: solid 1px currentColor;
    border-right: none;
  }
}
.mat-drawer.mat-drawer-side {
  z-index: 2;
}
.mat-drawer.mat-drawer-end {
  right: 0;
  transform: translate3d(100%, 0, 0);
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
[dir=rtl] .mat-drawer {
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transform: translate3d(100%, 0, 0);
}
[dir=rtl] .mat-drawer.mat-drawer-end {
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  left: 0;
  right: auto;
  transform: translate3d(-100%, 0, 0);
}
.mat-drawer-transition .mat-drawer {
  transition: transform 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) {
  visibility: hidden;
  box-shadow: none;
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) .mat-drawer-inner-container {
  display: none;
}
.mat-drawer.mat-drawer-opened.mat-drawer-opened {
  transform: none;
}

.mat-drawer-side {
  box-shadow: none;
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
}
.mat-drawer-side.mat-drawer-end {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side.mat-drawer-end {
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
  border-left: none;
}

.mat-drawer-inner-container {
  width: 100%;
  height: 100%;
  overflow: auto;
}

.mat-sidenav-fixed {
  position: fixed;
}
`],encapsulation:2})})()}return n})();var Ri=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[ue,hy,ue]})}return n})();var nn=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵdir=Mo({type:n,selectors:[[`mat-toolbar-row`]],hostAttrs:[1,`mat-toolbar-row`],exportAs:[`matToolbarRow`]})}return n})();var Bi=(()=>{class n{_elementRef=g(nt);_platform=g(nr);_document=g(L);color;_toolbarRows;ngAfterViewInit(){this._platform.isBrowser&&(this._checkToolbarMixedModes(),this._toolbarRows.changes.subscribe(()=>this._checkToolbarMixedModes()))}_checkToolbarMixedModes(){this._toolbarRows.length}static ɵfac=function(e){return new(e||n)};static ɵcmp=(function(){let t=[`*`,[[`mat-toolbar-row`]]];return So({type:n,selectors:[[`mat-toolbar`]],contentQueries:function(r,a,m){if(r&1&&Vg(m,nn,5),r&2){let h;mC(h=yC())&&(a._toolbarRows=h)}},hostAttrs:[1,`mat-toolbar`],hostVars:6,hostBindings:function(r,a){r&2&&(Eu(a.color?`mat-`+a.color:``),Rs(`mat-toolbar-multiple-rows`,a._toolbarRows.length>0)(`mat-toolbar-single-row`,a._toolbarRows.length===0))},inputs:{color:`color`},exportAs:[`matToolbar`],ngContentSelectors:[`*`,`mat-toolbar-row`],decls:2,vars:0,template:function(r,a){r&1&&(vu(t),Du(0),Du(1,1))},styles:[`.mat-toolbar {
  background: var(--%NS%mat-toolbar-container-background-color, var(--%NS%mat-sys-surface));
  color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-toolbar, .mat-toolbar h1, .mat-toolbar h2, .mat-toolbar h3, .mat-toolbar h4, .mat-toolbar h5, .mat-toolbar h6 {
  font-family: var(--%NS%mat-toolbar-title-text-font, var(--%NS%mat-sys-title-large-font));
  font-size: var(--%NS%mat-toolbar-title-text-size, var(--%NS%mat-sys-title-large-size));
  line-height: var(--%NS%mat-toolbar-title-text-line-height, var(--%NS%mat-sys-title-large-line-height));
  font-weight: var(--%NS%mat-toolbar-title-text-weight, var(--%NS%mat-sys-title-large-weight));
  letter-spacing: var(--%NS%mat-toolbar-title-text-tracking, var(--%NS%mat-sys-title-large-tracking));
  margin: 0;
}
@media (forced-colors: active) {
  .mat-toolbar {
    outline: solid 1px;
  }
}
.mat-toolbar .mat-form-field-underline,
.mat-toolbar .mat-form-field-ripple,
.mat-toolbar .mat-focused .mat-form-field-ripple {
  background-color: currentColor;
}
.mat-toolbar .mat-form-field-label,
.mat-toolbar .mat-focused .mat-form-field-label,
.mat-toolbar .mat-select-value,
.mat-toolbar .mat-select-arrow,
.mat-toolbar .mat-form-field.mat-focused .mat-select-arrow {
  color: inherit;
}
.mat-toolbar .mat-input-element {
  caret-color: currentColor;
}
.mat-toolbar .mat-mdc-button-base.mat-mdc-button-base.mat-unthemed {
  --%NS%mat-button-text-label-text-color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
  --%NS%mat-button-outlined-label-text-color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
}

.mat-toolbar-row, .mat-toolbar-single-row {
  display: flex;
  box-sizing: border-box;
  padding: 0 16px;
  width: 100%;
  flex-direction: row;
  align-items: center;
  white-space: nowrap;
  height: var(--%NS%mat-toolbar-standard-height, 64px);
}
@media (max-width: 599px) {
  .mat-toolbar-row, .mat-toolbar-single-row {
    height: var(--%NS%mat-toolbar-mobile-height, 56px);
  }
}

.mat-toolbar-multiple-rows {
  display: flex;
  box-sizing: border-box;
  flex-direction: column;
  width: 100%;
  min-height: var(--%NS%mat-toolbar-standard-height, 64px);
}
@media (max-width: 599px) {
  .mat-toolbar-multiple-rows {
    min-height: var(--%NS%mat-toolbar-mobile-height, 56px);
  }
}
`],encapsulation:2})})()}return n})();var Fi=(()=>{class n{static ɵfac=function(e){return new(e||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[hy]})}return n})();function sn(n,c){n&1&&Rg(0,`mat-progress-bar`,1)}function ln(n,c){n&1&&(Es(0,`mat-error`),BC(1,`Escribe tu contraseña actual.`),hu())}function mn(n,c){n&1&&(Es(0,`mat-error`),BC(1,`Debe tener al menos 8 caracteres.`),hu())}function cn(n,c){n&1&&BC(0,` Las contraseñas no coinciden. `)}function dn(n,c){n&1&&BC(0,` Repite la nueva contraseña. `)}function hn(n,c){if(n&1&&(Es(0,`mat-error`),Kw(1,cn,1,0)(2,dn,1,0),hu()),n&2){let t=pC();QE(),Jw(t.form.controls.password_confirmation.errors?.mismatch?1:2)}}function pn(n,c){if(n&1&&(Es(0,`div`,7)(1,`span`,11),BC(2,`error`),hu(),Es(3,`span`),BC(4),hu()()),n&2){let t=pC();QE(4),Kg(t.error())}}var Qt=class n{auth=g(d);toast=g(Pn);dialogRef=g(V$2);fb=g(Wr);saving=or(!1);error=or(null);form=this.fb.nonNullable.group({current_password:[``,[Me.required,Me.maxLength(255)]],password:[``,[Me.required,Me.minLength(8),Me.maxLength(255)]],password_confirmation:[``,[Me.required,Me.maxLength(255)]]},{validators:rs});save(){if(this.form.invalid){this.form.markAllAsTouched();return}if(this.form.controls.password.value!==this.form.controls.password_confirmation.value){this.form.controls.password_confirmation.setErrors({mismatch:!0});return}this.saving.set(!0),this.error.set(null),this.auth.changePassword(this.form.getRawValue()).subscribe({next:c=>{this.saving.set(!1),this.toast.success(c.message||rU.auth.changePasswordSuccess),this.dialogRef.close(!0)},error:c=>{this.saving.set(!1),this.error.set(Gr(c,rU.auth.changePasswordFallback))}})}close(){this.dialogRef.close(!1)}static ɵfac=function(t){return new(t||n)};static ɵcmp=So({type:n,selectors:[[`app-change-password-dialog`]],decls:32,vars:7,consts:[[`mat-dialog-title`,``],[`mode`,`indeterminate`],[1,`stack`,2,`margin-top`,`8px`,3,`ngSubmit`,`formGroup`],[`appearance`,`outline`],[`matInput`,``,`type`,`password`,`formControlName`,`current_password`,`autocomplete`,`current-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password`,`autocomplete`,`new-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password_confirmation`,`autocomplete`,`new-password`,`maxlength`,`255`],[1,`banner`,`banner--danger`],[1,`btn-row`,2,`justify-content`,`flex-end`],[`type`,`button`,1,`btn`,`btn--outline`,3,`click`],[`type`,`submit`,1,`btn`,`btn--primary`,3,`disabled`],[1,`material-icons`]],template:function(t,e){t&1&&(Es(0,`h2`,0),BC(1,`Cambiar contraseña`),hu(),Es(2,`mat-dialog-content`),Kw(3,sn,1,0,`mat-progress-bar`,1),Es(4,`form`,2),Pg(`ngSubmit`,function(){return e.save()}),Es(5,`mat-form-field`,3)(6,`mat-label`),BC(7,`Contraseña actual`),hu(),Es(8,`input`,4),BI(),hu(),Es(9,`mat-hint`),BC(10,`La contraseña con la que ingresaste hoy.`),hu(),Kw(11,ln,2,0,`mat-error`),hu(),Es(12,`mat-form-field`,3)(13,`mat-label`),BC(14,`Nueva contraseña`),hu(),Es(15,`input`,5),BI(),hu(),Es(16,`mat-hint`),BC(17,`Mínimo 8 caracteres.`),hu(),Kw(18,mn,2,0,`mat-error`),hu(),Es(19,`mat-form-field`,3)(20,`mat-label`),BC(21,`Repetir nueva contraseña`),hu(),Es(22,`input`,6),BI(),hu(),Es(23,`mat-hint`),BC(24,`Debe coincidir exactamente con la nueva contraseña.`),hu(),Kw(25,hn,3,1,`mat-error`),hu(),Kw(26,pn,5,1,`div`,7),Es(27,`div`,8)(28,`button`,9),Pg(`click`,function(){return e.close()}),BC(29,`Cancelar`),hu(),Es(30,`button`,10),BC(31,` Guardar contraseña `),hu()()()()),t&2&&(QE(3),Jw(e.saving()?3:-1),QE(),xg(`formGroup`,e.form),QE(4),UI(),QE(3),Jw(e.form.controls.current_password.touched&&e.form.controls.current_password.invalid?11:-1),QE(4),UI(),QE(3),Jw(e.form.controls.password.touched&&e.form.controls.password.invalid?18:-1),QE(4),UI(),QE(3),Jw(e.form.controls.password_confirmation.touched&&e.form.controls.password_confirmation.invalid?25:-1),QE(),Jw(e.error()?26:-1),QE(4),xg(`disabled`,e.saving()))},dependencies:[Kr,Ur,vn$1,Br,Hr,ji$1,wt,sr,ze,Re$1,Be,Vt,ri,Dt,Ft$1,mr,Ja,Qa,jr,Fr],encapsulation:2})};var gn=(n,c)=>c.route;var un=(n,c)=>c.id;function _n(n,c){if(n&1&&(Es(0,`span`,36),BC(1),hu()),n&2){let t=pC(2);QE(),Kg(t.unreadCount())}}function bn(n,c){if(n&1){let t=aC();Es(0,`a`,35),Pg(`click`,function(){yf(t);let i=pC();return vf(i.isMobile()&&i.sidenavOpen.set(!1))}),Es(1,`mat-icon`),BC(2),hu(),Es(3,`span`),BC(4),hu(),Kw(5,_n,2,1,`span`,36),hu()}if(n&2){let t=c.$implicit,e=pC();Rs(`nav-item--active`,e.isActive(t)),xg(`routerLink`,t.route),QE(2),Kg(t.icon),QE(2),Kg(t.label),QE(),Jw(t.route===`/avisos`&&e.unreadCount()>0?5:-1)}}function fn(n,c){if(n&1){let t=aC();Es(0,`button`,37),Pg(`click`,function(){yf(t);let i=pC();return vf(i.onInstallClick())}),Es(1,`mat-icon`),BC(2,`install_mobile`),hu(),Es(3,`span`),BC(4,`Instalar app`),hu()()}}function vn(n,c){n&1&&(Es(0,`div`,38),Rg(1,`mat-progress-bar`,42),hu())}function wn(n,c){n&1&&(Es(0,`div`,39),BC(1,` No encontramos clientes con ese dato. `),hu())}function xn(n,c){if(n&1){let t=aC();Es(0,`button`,43),Pg(`click`,function(){let i=yf(t).$implicit,r=pC(2);return vf(r.selectClient(i))}),Es(1,`span`,44),BC(2),hu(),Es(3,`span`,45)(4,`strong`),BC(5),hu(),Es(6,`span`),BC(7),hu()(),Es(8,`span`,6),BC(9,`chevron_right`),hu()()}if(n&2){let t=c.$implicit;QE(2),Kg(t.full_name.charAt(0)),QE(3),Kg(t.full_name),QE(2),Kg(t.phone)}}function yn(n,c){if(n&1){let t=aC();Es(0,`button`,46),Pg(`click`,function(){yf(t);let i=pC(2);return vf(i.submitGlobalSearch())}),BC(1,` Ver todos los resultados `),hu()}}function kn(n,c){if(n&1&&(Es(0,`div`,24),Kw(1,vn,2,0,`div`,38),Kw(2,wn,2,0,`div`,39),tC(3,xn,10,3,`button`,40,un),Kw(5,yn,2,0,`button`,41),hu()),n&2){let t=pC();QE(),Jw(t.searching()?1:-1),QE(),Jw(!t.searching()&&t.results().length===0&&t.searchTerm().trim()!==``?2:-1),QE(),nC(t.results()),QE(2),Jw(t.results().length>0?5:-1)}}var Vi=class n{auth=g(d);notifications=g(c);clients=g(g$1);images=g(f);router=g(G$1);dialog=g(Ft);breakpoint=g(cr);destroyRef=g(he);toast=g(Pn);pwa=g(K);user=this.auth.user;isMobile=T(this.breakpoint.observe(`(max-width: 900px)`).pipe(Q(c=>c.matches)),{initialValue:!1});sidenavOpen=or(!0);currentUrl=or(this.router.url);navItems=[{label:`Inicio`,icon:`dashboard`,route:`/inicio`},{label:`Nuevo cliente`,icon:`person_add`,route:`/clientes/nuevo`},{label:`Buscar cliente`,icon:`manage_search`,route:`/clientes`},{label:`Pedidos`,icon:`shopping_bag`,route:`/pedidos`},{label:`Avisos de entrega`,icon:`local_shipping`,route:`/entregas`},{label:`Historial`,icon:`history`,route:`/historial`},{label:`Avisos`,icon:`notifications`,route:`/avisos`},{label:`Crear usuario`,icon:`group_add`,route:`/usuarios`}];searching=or(!1);results=or([]);showResults=or(!1);searchTerm=or(``);unreadCount=this.notifications.unreadCount;searchSubject=new te;constructor(){Vf(()=>{this.sidenavOpen.set(!this.isMobile())}),this.searchSubject.pipe(Dd(300),Ed(),ma(c=>c.trim()===``?ot({current_page:1,data:[],last_page:1,per_page:6,total:0}):(this.searching.set(!0),this.clients.list({search:c,per_page:6}).pipe(Vn(()=>this.searching.set(!1))))),U(this.destroyRef)).subscribe({next:c=>{this.results.set(c.data),this.showResults.set(!0)},error:()=>{this.results.set([]),this.searching.set(!1)}}),this.router.events.pipe(Ot(c=>c instanceof x),U(this.destroyRef)).subscribe(c=>{this.currentUrl.set(c.urlAfterRedirects),this.closeResults(),this.notifications.refreshUnreadCount(),this.isMobile()&&this.sidenavOpen.set(!1)}),Nr(0,6e4).pipe(U(this.destroyRef)).subscribe(()=>this.notifications.refreshUnreadCount())}isActive(c){let t=this.currentUrl().split(`?`)[0];return c.route===`/clientes`?t.startsWith(`/clientes`)&&!t.startsWith(`/clientes/nuevo`):c.route===`/clientes/nuevo`?t.startsWith(`/clientes/nuevo`):t===c.route||t.startsWith(c.route+`/`)}toggleSidenav(){this.sidenavOpen.update(c=>!c)}onSearchInput(c){let t=c.target.value;if(this.searchTerm.set(t),t.trim()===``){this.results.set([]),this.showResults.set(!1);return}this.searchSubject.next(t)}onSearchFocus(){(this.results().length||this.searchTerm().trim()!==``)&&this.showResults.set(!0)}onSearchBlur(){setTimeout(()=>this.showResults.set(!1),180)}submitGlobalSearch(){let c=this.searchTerm().trim();c!==``&&this.router.navigate([`/clientes`],{queryParams:{q:c}})}selectClient(c){this.router.navigate([`/clientes`,c.id]),this.clearSearch()}clearSearch(){this.searchTerm.set(``),this.results.set([]),this.showResults.set(!1)}closeResults(){this.showResults.set(!1)}openSearchPage(){this.router.navigate([`/clientes`],{queryParams:{focus:1}})}goToNotifications(){this.router.navigate([`/avisos`])}changePassword(){this.dialog.open(Qt,{width:`430px`,maxWidth:`92vw`,panelClass:`app-dialog`,autoFocus:!1})}onInstallClick(){this.isMobile()&&this.sidenavOpen.set(!1),this.installApp()}async installApp(){if(!this.pwa.installed()){if(this.pwa.canInstall()){let c=await this.pwa.promptInstall();c===`accepted`?this.toast.success(rU.layout.installAccepted):c===`dismissed`&&this.toast.info(rU.layout.installDismissed);return}this.toast.info(rU.layout.installInstructions)}}logout(){this.auth.logout().subscribe({next:()=>this.finishLogout(),error:()=>this.finishLogout()})}finishLogout(){this.images.clear(),this.router.navigate([`/login`])}static ɵfac=function(t){return new(t||n)};static ɵcmp=So({type:n,selectors:[[`app-layout`]],decls:80,vars:16,consts:[[`sidenav`,``],[`userMenu`,`matMenu`],[1,`shell`],[1,`sidebar`,3,`openedChange`,`mode`,`opened`],[`routerLink`,`/inicio`,1,`brand`,3,`click`],[1,`brand__mark`],[1,`material-icons`],[1,`brand__name`],[1,`brand__sub`],[1,`nav`],[1,`nav-item`,3,`nav-item--active`,`routerLink`],[`type`,`button`,1,`nav-item`,`nav-item--button`],[1,`sidebar__footer`],[1,`sidebar__user`],[1,`avatar`],[1,`sidebar__user-info`],[`type`,`button`,1,`btn`,`btn--ghost`,`btn--sm`,`btn--block`,3,`click`],[1,`content`],[1,`topbar`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Abrir menú`,1,`topbar__icon`,`mobile-only`,3,`click`],[`routerLink`,`/inicio`,1,`topbar__brand`,`mobile-only`],[1,`topbar__search`,`desktop-only`],[1,`search-box`],[`type`,`search`,`maxlength`,`100`,`placeholder`,`Buscar por nombre o celular…`,`aria-label`,`Buscar cliente`,1,`search-input`,3,`input`,`focus`,`blur`,`keydown.enter`,`value`],[1,`search-results`],[1,`spacer`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Buscar cliente`,1,`topbar__icon`,`mobile-only`,3,`click`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Avisos`,1,`topbar__icon`,3,`click`],[`matBadgeColor`,`warn`,`matBadgeSize`,`small`,3,`matBadge`,`matBadgeHidden`],[`mat-button`,``,`type`,`button`,1,`topbar__user`,`desktop-only`,3,`matMenuTriggerFor`],[1,`avatar`,`avatar--sm`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Cuenta`,1,`topbar__icon`,`mobile-only`,3,`matMenuTriggerFor`],[1,`menu-user`],[`mat-menu-item`,``,`type`,`button`,3,`click`],[1,`main`],[1,`nav-item`,3,`click`,`routerLink`],[1,`nav-item__badge`],[`type`,`button`,1,`nav-item`,`nav-item--button`,3,`click`],[1,`search-results__status`],[1,`search-results__empty`],[`type`,`button`,1,`search-result`],[`type`,`button`,1,`search-results__all`],[`mode`,`indeterminate`],[`type`,`button`,1,`search-result`,3,`click`],[1,`search-result__avatar`],[1,`search-result__info`],[`type`,`button`,1,`search-results__all`,3,`click`]],template:function(t,e){if(t&1&&(Es(0,`mat-sidenav-container`,2)(1,`mat-sidenav`,3,0),Pg(`openedChange`,function(r){return e.sidenavOpen.set(r)}),Es(3,`div`,4),Pg(`click`,function(){return e.isMobile()&&e.sidenavOpen.set(!1)}),Es(4,`div`,5)(5,`span`,6),BC(6,`visibility`),hu()(),Es(7,`div`)(8,`div`,7),BC(9,`Óptica`),hu(),Es(10,`div`,8),BC(11,`Gestión del local`),hu()()(),Es(12,`nav`,9),tC(13,bn,6,6,`a`,10,gn),Kw(15,fn,5,0,`button`,11),hu(),Es(16,`div`,12)(17,`div`,13)(18,`div`,14),BC(19),hu(),Es(20,`div`,15)(21,`strong`),BC(22),hu(),Es(23,`span`),BC(24),hu()()(),Es(25,`button`,16),Pg(`click`,function(){return e.logout()}),Es(26,`mat-icon`),BC(27,`logout`),hu(),BC(28,` Cerrar sesión `),hu()()(),Es(29,`mat-sidenav-content`,17)(30,`mat-toolbar`,18)(31,`button`,19),Pg(`click`,function(){return e.toggleSidenav()}),Es(32,`mat-icon`),BC(33,`menu`),hu()(),Es(34,`a`,20)(35,`span`,6),BC(36,`visibility`),hu(),BC(37,` Óptica `),hu(),Es(38,`div`,21)(39,`div`,22)(40,`mat-icon`),BC(41,`search`),hu(),Es(42,`input`,23),Pg(`input`,function(r){return e.onSearchInput(r)})(`focus`,function(){return e.onSearchFocus()})(`blur`,function(){return e.onSearchBlur()})(`keydown.enter`,function(){return e.submitGlobalSearch()}),hu()(),Kw(43,kn,6,3,`div`,24),hu(),Rg(44,`span`,25),Es(45,`button`,26),Pg(`click`,function(){return e.openSearchPage()}),Es(46,`mat-icon`),BC(47,`search`),hu()(),Es(48,`button`,27),Pg(`click`,function(){return e.goToNotifications()}),Es(49,`mat-icon`,28),BC(50,`notifications`),hu()(),Es(51,`button`,29)(52,`span`,30),BC(53),hu(),BC(54),Es(55,`mat-icon`),BC(56,`expand_more`),hu()(),Es(57,`button`,31)(58,`mat-icon`),BC(59,`account_circle`),hu()(),Es(60,`mat-menu`,null,1)(62,`div`,32)(63,`strong`),BC(64),hu(),Es(65,`span`),BC(66),hu()(),Rg(67,`mat-divider`),Es(68,`button`,33),Pg(`click`,function(){return e.changePassword()}),Es(69,`mat-icon`),BC(70,`lock_reset`),hu(),Es(71,`span`),BC(72,`Cambiar contraseña`),hu()(),Es(73,`button`,33),Pg(`click`,function(){return e.logout()}),Es(74,`mat-icon`),BC(75,`logout`),hu(),Es(76,`span`),BC(77,`Cerrar sesión`),hu()()()(),Es(78,`main`,34),Rg(79,`router-outlet`),hu()()()),t&2){let i=DC(61);QE(),xg(`mode`,e.isMobile()?`over`:`side`)(`opened`,e.sidenavOpen()),QE(12),nC(e.navItems),QE(2),Jw(e.pwa.installed()?-1:15),QE(4),Kg((e.user()?.name||`U`).charAt(0)),QE(3),Kg(e.user()?.name),QE(2),Kg(e.user()?.username),QE(18),xg(`value`,e.searchTerm()),QE(),Jw(e.showResults()?43:-1),QE(6),xg(`matBadge`,e.unreadCount())(`matBadgeHidden`,e.unreadCount()===0),QE(2),xg(`matMenuTriggerFor`,i),QE(2),Kg((e.user()?.name||`U`).charAt(0)),QE(),Iu(` `,e.user()?.name,` `),QE(3),xg(`matMenuTriggerFor`,i),QE(7),Kg(e.user()?.name),QE(2),Kg(e.user()?.username)}},dependencies:[Bm,ua,wr,di,Ri,se,Pi,Gt,Fi,Bi,tU,eU,Vn$1,ln$1,Tn,Li,dt,xt,Oi,zi,Ii,jt,Di,Ti,jr,Fr],styles:[`.shell[_ngcontent-%COMP%]{height:100dvh;min-height:100dvh;background:var(--%NS%optic-bg)}.sidebar[_ngcontent-%COMP%]{width:256px;border-right:1px solid var(--%NS%optic-border);background:#fff;display:flex;flex-direction:column}.brand[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:22px 20px 18px;cursor:pointer;-webkit-user-select:none;user-select:none}.brand__mark[_ngcontent-%COMP%]{width:44px;height:44px;border-radius:14px;background:linear-gradient(145deg,#00b3b3,#008585);display:grid;place-items:center;color:#fff;box-shadow:0 6px 14px #00a0a04d}.brand__mark[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:26px}.brand__name[_ngcontent-%COMP%]{font-size:1.2rem;font-weight:800;color:#123333;letter-spacing:-.02em}.brand__sub[_ngcontent-%COMP%]{font-size:.73rem;color:var(--%NS%optic-muted);margin-top:1px}.nav[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:3px;padding:6px 12px;overflow-y:auto;flex:1}.nav-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:11px 13px;border-radius:11px;color:#445858;font-weight:500;font-size:.92rem;text-decoration:none;transition:background .14s ease,color .14s ease}.nav-item--button[_ngcontent-%COMP%]{width:100%;border:none;background:transparent;cursor:pointer;font-family:inherit;text-align:left}.nav-item[_ngcontent-%COMP%]:hover{background:#f1f8f8;color:var(--%NS%optic-primary-dark);text-decoration:none}.nav-item--active[_ngcontent-%COMP%]{background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);font-weight:700}.nav-item[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:21px;color:inherit}.nav-item__badge[_ngcontent-%COMP%]{margin-left:auto;background:var(--%NS%optic-danger);color:#fff;border-radius:999px;font-size:.7rem;font-weight:700;min-width:20px;height:20px;display:grid;place-items:center;padding:0 6px}.sidebar__footer[_ngcontent-%COMP%]{border-top:1px solid var(--%NS%optic-border);padding:14px 14px 18px;display:flex;flex-direction:column;gap:10px}.sidebar__user[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:2px 4px}.avatar[_ngcontent-%COMP%]{width:38px;height:38px;border-radius:50%;background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);display:grid;place-items:center;font-weight:800;flex-shrink:0;text-transform:uppercase}.avatar--sm[_ngcontent-%COMP%]{width:28px;height:28px;font-size:.8rem}.sidebar__user-info[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0}.sidebar__user-info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.86rem;color:#244040;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sidebar__user-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.74rem;color:var(--%NS%optic-muted)}.content[_ngcontent-%COMP%]{background:var(--%NS%optic-bg);overflow-x:hidden}.topbar[_ngcontent-%COMP%]{height:68px;background:#fffffff5;border-bottom:1px solid var(--%NS%optic-border);position:sticky;top:0;z-index:20;padding:0 20px;display:flex;gap:8px;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}.topbar__icon[_ngcontent-%COMP%]{color:#4b6262}.topbar__brand[_ngcontent-%COMP%]{display:flex;align-items:center;gap:7px;font-weight:800;color:#143636;font-size:1.05rem;text-decoration:none;margin-right:4px}.topbar__brand[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary)}.topbar__search[_ngcontent-%COMP%]{position:relative;width:min(460px,42vw);margin-left:14px}.topbar__search[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%], .topbar__search[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#789191;font-size:21px;pointer-events:none}.topbar__search[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{min-height:44px;border-radius:12px;background:#f5f9f9;border-color:transparent}.topbar__search[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]:focus{background:#fff}.search-results[_ngcontent-%COMP%]{position:absolute;top:calc(100% + 8px);left:0;right:0;background:#fff;border:1px solid var(--%NS%optic-border);border-radius:14px;box-shadow:var(--%NS%shadow-md);overflow:hidden;z-index:30}.search-results__status[_ngcontent-%COMP%]{padding:4px}.search-results__empty[_ngcontent-%COMP%]{padding:18px;color:var(--%NS%optic-muted);font-size:.88rem;text-align:center}.search-result[_ngcontent-%COMP%]{width:100%;display:flex;align-items:center;gap:10px;padding:10px 14px;border:none;background:#fff;cursor:pointer;text-align:left;border-bottom:1px solid #f0f5f5}.search-result[_ngcontent-%COMP%]:hover{background:#f4fafa}.search-result__avatar[_ngcontent-%COMP%]{width:34px;height:34px;border-radius:50%;background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);display:grid;place-items:center;font-weight:700;flex-shrink:0}.search-result__info[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0;flex:1}.search-result__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.9rem;color:#233c3c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.search-result__info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.78rem;color:var(--%NS%optic-muted)}.search-result[_ngcontent-%COMP%] > .material-icons[_ngcontent-%COMP%]{color:#9ab3b3;font-size:19px}.search-results__all[_ngcontent-%COMP%]{width:100%;border:none;background:#f7fbfb;color:var(--%NS%optic-primary-dark);font-weight:600;font-size:.84rem;padding:11px;cursor:pointer}.search-results__all[_ngcontent-%COMP%]:hover{background:var(--%NS%optic-primary-soft)}.topbar__user[_ngcontent-%COMP%]{font-weight:600;color:#344c4c}.menu-user[_ngcontent-%COMP%]{padding:12px 16px;display:flex;flex-direction:column}.menu-user[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.9rem}.menu-user[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.76rem;color:var(--%NS%optic-muted)}.main[_ngcontent-%COMP%]{min-height:calc(100dvh - 68px)}@media(max-width:900px){.sidebar[_ngcontent-%COMP%]{width:min(280px,86vw)}.topbar[_ngcontent-%COMP%]{padding:0 10px 0 6px;height:62px}.main[_ngcontent-%COMP%]{min-height:calc(100dvh - 62px)}}@media(max-width:360px){.topbar[_ngcontent-%COMP%]{gap:2px;padding:0 4px}.topbar__brand[_ngcontent-%COMP%]{gap:4px;font-size:.96rem}}`]})};export{Vi as LayoutComponent};