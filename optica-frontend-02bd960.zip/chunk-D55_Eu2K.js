import{$n as vu,A as Fg,An as oT,Bt as Zy,Cn as nC,Dn as nm,Dt as XC,En as ne,Gn as tU,H as Kg,Kn as te,Ln as rU,Lt as Zi,Mt as Yy,N as G$1,Nn as ov,O as Es,On as nt,Ot as Xe,Pn as pC,Pt as ZC,R as Iu,Rn as r_,St as V,U as Kw,Un as tC,Ut as _u,V as Jw,Wt as aC,Xn as vf,Y as M2,Zt as eC,_ as Bg,_n as kt,_t as So,ar as yf,b as Ct,bn as mC,bt as UI,ct as Pe$1,dn as hu,en as eb,er as xg,et as Nl,f as Af,fn as hy,ft as QE,g as BI,gt as Sg,h as BC,hn as iv,ht as Rs,i as ua,it as Ob,j as Fs,jn as or,jt as YC,k as Eu,kt as Xg,ln as he,lt as Pg,mt as Rg,n as G,nt as No,on as gm,pt as QT,qn as v,r as di,rn as g,rr as yC,s as u,st as Ot,t as B,un as hr,ut as Q$1,v as Bm,w as Du,wt as Vg,x as DC,xn as ma}from"./main-FJ7FCX5K.js";import"./chunk-CBfdjfTI.js";import{t as C}from"./chunk-DtP5YzVZ.js";import{n as Lr,r as Xr,s as qr,t as Fr}from"./chunk-d6EJ4Xmn.js";import{S as tt,l as Le,t as $,v as g$1,w as z}from"./chunk-BnhEUUFB.js";import{_ as li$1,b as tt$1,g as le,m as he$1,n as Je,p as gt,r as Jt,v as se}from"./chunk-D9-DhgAV.js";import{t as D}from"./chunk-DrHSDWCP.js";import{A as or$1,D as li$2,E as ji,F as sr,I as ts,L as vn,M as qr$1,N as ri$1,O as mr,R as wt,S as Y,T as is,_ as Qa,a as Br,b as Vt,c as Hr,d as Ke,f as Kr,g as Pi,h as Nt,i as Bn$1,l as It,n as $r,o as Dt,p as Me,r as At,s as Ft,t as $n$1,u as Ja,v as Ti,w as hr$1,x as Wr,y as Ur}from"./chunk-CwrR66eH.js";import{a as m,r as f}from"./chunk-D_JcBML1.js";import{t as g$2}from"./chunk-tTMGsaVa.js";import{n as U}from"./chunk-D1IS_wMH.js";import{t as m$1}from"./chunk-CWkjky6-.js";import{i as lt,r as ct}from"./chunk-p4ElF8ZG.js";import{i as x,n as N,r as d,t as C$1}from"./chunk-7rOEdIKp.js";var Ee=new v(`MAT_OPTION_PARENT_COMPONENT`);var Ie=new v(`MatOptgroup`);var we=class{source;isUserInput;constructor(o,e=!1){this.source=o,this.isUserInput=e}};var Q=(()=>{class n{_element=g(nt);_changeDetectorRef=g(gm);_parent=g(Ee,{optional:!0});group=g(Ie,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue=``;get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=g(z).getId(`mat-option-`);get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=or(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new Pe$1;_text;_stateChanges=new te;constructor(){let e=g(QT);e.load(ct),e.load(M2),this._signalDisableRipple=!!this._parent&&Zi(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||``).trim()}select(e=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}deselect(e=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}focus(e,t){let i=this._getHostElement();typeof i.focus==`function`&&i.focus(t)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!Le(e)&&(this._selectViaInteraction(),e.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?`-1`:`0`}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let e=this.viewValue;e!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=e)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(e=!1){this.onSelectionChange.emit(new we(this,e))}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`text`],t=[[[`mat-icon`]],`*`],i=[`mat-icon`,`*`];function u(_,C){if(_&1&&Rg(0,`mat-pseudo-checkbox`,1),_&2){let h=pC();xg(`disabled`,h.disabled)(`state`,h.selected?`checked`:`unchecked`)}}function y(_,C){if(_&1&&Rg(0,`mat-pseudo-checkbox`,3),_&2){let h=pC();xg(`disabled`,h.disabled)}}function w(_,C){if(_&1&&(Es(0,`span`,4),BC(1),hu()),_&2){let h=pC();QE(),Iu(`(`,h.group.label,`)`)}}return So({type:n,selectors:[[`mat-option`]],viewQuery:function(C,h){if(C&1&&Bg(e,7),C&2){let g;mC(g=yC())&&(h._text=g.first)}},hostAttrs:[`role`,`option`,1,`mat-mdc-option`,`mdc-list-item`],hostVars:11,hostBindings:function(C,h){C&1&&Pg(`click`,function(){return h._selectViaInteraction()})(`keydown`,function(v){return h._handleKeydown(v)}),C&2&&(Fg(`id`,h.id),No(`aria-selected`,h.selected)(`aria-disabled`,h.disabled.toString()),Rs(`mdc-list-item--selected`,h.selected)(`mat-mdc-option-multiple`,h.multiple)(`mat-mdc-option-active`,h.active)(`mdc-list-item--disabled`,h.disabled))},inputs:{value:`value`,id:`id`,disabled:[2,`disabled`,`disabled`,_u]},outputs:{onSelectionChange:`onSelectionChange`},exportAs:[`matOption`],ngContentSelectors:i,decls:8,vars:5,consts:[[`text`,``],[`aria-hidden`,`true`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`,`state`],[1,`mdc-list-item__primary-text`],[`state`,`checked`,`aria-hidden`,`true`,`appearance`,`minimal`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`],[1,`cdk-visually-hidden`],[`aria-hidden`,`true`,`mat-ripple`,``,1,`mat-mdc-option-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`]],template:function(C,h){C&1&&(vu(t),Kw(0,u,1,2,`mat-pseudo-checkbox`,1),Du(1),Es(2,`span`,2,0),Du(4,1),hu(),Kw(5,y,1,1,`mat-pseudo-checkbox`,3),Kw(6,w,2,1,`span`,4),Rg(7,`div`,5)),C&2&&(Jw(h.multiple?0:-1),QE(5),Jw(!h.multiple&&h.selected&&!h.hideSingleSelectionIndicator?5:-1),QE(),Jw(h.group&&h.group._inert?6:-1),QE(),xg(`matRippleTrigger`,h._getHostElement())(`matRippleDisabled`,h.disabled||h.disableRipple))},dependencies:[C$1,lt],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--%NS%mat-option-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-option-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-option-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-option-label-text-size, var(--%NS%mat-sys-body-large-size));
  letter-spacing: var(--%NS%mat-option-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-option-label-text-weight, var(--%NS%mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--%NS%mat-option-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--%NS%mat-option-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--%NS%mat-option-selected-state-layer-color, var(--%NS%mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --%NS%mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --%NS%mat-list-list-item-selected-container-color: var(--%NS%mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2})})()}return n})();function cn(n,o,e){if(e.length){let t=o.toArray(),i=e.toArray(),u=0;for(let y=0;y<n+1;y++)t[y].group&&t[y].group===i[u]&&u++;return u}return 0}function dn(n,o,e,t){return n<e?n:n+o>e+t?Math.max(0,n-t+o):e}var Te=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[x,N,Q,hy]})}return n})();var Cn=new v(`mat-select-scroll-strategy`,{providedIn:`root`,factory:()=>{let n=g(ne);return()=>le(n)}});var On=new v(`MAT_SELECT_CONFIG`);var Sn=new v(`MatSelectTrigger`);var Ne=class{source;value;constructor(o,e){this.source=o,this.value=e}};var un=(()=>{class n{_viewportRuler=g(tt$1);_changeDetectorRef=g(gm);_elementRef=g(nt);_dir=g(r_,{optional:!0});_idGenerator=g(z);_renderer=g(hr);_parentFormField=g(It,{optional:!0});ngControl=g(Y,{self:!0,optional:!0});_liveAnnouncer=g(tt);_defaultOptions=g(On,{optional:!0});_animationsDisabled=Xr();_popoverLocation;_initialized=new te;_cleanupDetach;options;optionGroups;customTrigger;_positions=[{originX:`start`,originY:`bottom`,overlayX:`start`,overlayY:`top`},{originX:`end`,originY:`bottom`,overlayX:`end`,overlayY:`top`},{originX:`start`,originY:`top`,overlayX:`start`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`},{originX:`end`,originY:`top`,overlayX:`end`,overlayY:`bottom`,panelClass:`mat-mdc-select-panel-above`}];_scrollOptionIntoView(e){let t=this.options.toArray()[e];if(t){let i=this.panel.nativeElement,u=cn(e,this.options,this.optionGroups),y=t._getHostElement();e===0&&u===1?i.scrollTop=0:i.scrollTop=dn(y.offsetTop,y.offsetHeight,i.scrollTop,i.offsetHeight)}}_positioningSettled(){this._scrollOptionIntoView(this._keyManager.activeItemIndex||0)}_getChangeEvent(e){return new Ne(this,e)}_scrollStrategyFactory=g(Cn);_panelOpen=!1;_compareWith=(e,t)=>e===t;_uid=this._idGenerator.getId(`mat-select-`);_triggerAriaLabelledBy=null;_previousControl;_destroy=new te;_errorStateTracker;stateChanges=new te;disableAutomaticLabeling=!0;userAriaDescribedBy;_selectionModel;_keyManager;_preferredOverlayOrigin;_overlayWidth;_onChange=()=>{};_onTouched=()=>{};_valueId=this._idGenerator.getId(`mat-select-value-`);_scrollStrategy;_overlayPanelClass=this._defaultOptions?.overlayPanelClass||``;get focused(){return this._focused||this._panelOpen}_focused=!1;controlType=`mat-select`;trigger;panel;_overlayDir;panelClass;disabled=!1;get disableRipple(){return this._disableRipple()}set disableRipple(e){this._disableRipple.set(e)}_disableRipple=or(!1);tabIndex=0;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._syncParentProperties()}_hideSingleSelectionIndicator=this._defaultOptions?.hideSingleSelectionIndicator??!1;get placeholder(){return this._placeholder}set placeholder(e){this._placeholder=e,this.stateChanges.next()}_placeholder;get required(){return this._required??this.ngControl?.control?.hasValidator(Me.required)??!1}set required(e){this._required=e,this.stateChanges.next()}_required;get multiple(){return this._multiple}set multiple(e){this._selectionModel,this._multiple=e}_multiple=!1;disableOptionCentering=this._defaultOptions?.disableOptionCentering??!1;get compareWith(){return this._compareWith}set compareWith(e){this._compareWith=e,this._selectionModel&&this._initializeSelection()}get value(){return this._value}set value(e){this._assignValue(e)&&this._onChange(e)}_value;ariaLabel=``;ariaLabelledby;get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}typeaheadDebounceInterval;sortComparator;get id(){return this._id}set id(e){this._id=e||this._uid,this.stateChanges.next()}_id;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}panelWidth=this._defaultOptions&&typeof this._defaultOptions.panelWidth<`u`?this._defaultOptions.panelWidth:`auto`;canSelectNullableOptions=this._defaultOptions?.canSelectNullableOptions??!1;optionSelectionChanges=Zy(()=>{let e=this.options;return e?e.changes.pipe(ov(e),ma(()=>Yy(...e.map(t=>t.onSelectionChange)))):this._initialized.pipe(ma(()=>this.optionSelectionChanges))});openedChange=new Pe$1;_openedStream=this.openedChange.pipe(Ot(e=>e),Q$1(()=>{}));_closedStream=this.openedChange.pipe(Ot(e=>!e),Q$1(()=>{}));selectionChange=new Pe$1;valueChange=new Pe$1;constructor(){let e=g(li$2),t=g(Nt,{optional:!0}),i=g(wt,{optional:!0}),u=g(new Fs(`tabindex`),{optional:!0}),y=g(he$1,{optional:!0}),w=g($n$1,{optional:!0,self:!0});this.ngControl&&(this.ngControl.valueAccessor=this),this._defaultOptions?.typeaheadDebounceInterval!=null&&(this.typeaheadDebounceInterval=this._defaultOptions.typeaheadDebounceInterval),this._errorStateTracker=new Ke(e,w||this.ngControl,i,t,this.stateChanges),this._scrollStrategy=this._scrollStrategyFactory(),this.tabIndex=u==null?0:parseInt(u)||0,this._popoverLocation=y?.usePopover===!1?null:`inline`,this.id=this.id}ngOnInit(){this._selectionModel=new d(this.multiple),this.stateChanges.next(),this._viewportRuler.change().pipe(iv(this._destroy)).subscribe(()=>{this.panelOpen&&(this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._changeDetectorRef.detectChanges())})}ngAfterContentInit(){this._initialized.next(),this._initialized.complete(),this._initKeyManager(),this._selectionModel.changed.pipe(iv(this._destroy)).subscribe(e=>{e.added.forEach(t=>t.select()),e.removed.forEach(t=>t.deselect())}),this.options.changes.pipe(ov(null),iv(this._destroy)).subscribe(()=>{this._resetOptions(),this._initializeSelection()})}ngDoCheck(){let e=this._getTriggerAriaLabelledby(),t=this.ngControl;if(e!==this._triggerAriaLabelledBy){let i=this._elementRef.nativeElement;this._triggerAriaLabelledBy=e,e?i.setAttribute(`aria-labelledby`,e):i.removeAttribute(`aria-labelledby`)}t&&(this._previousControl!==t.control&&(this._previousControl!==void 0&&t.disabled!==null&&t.disabled!==this.disabled&&(this.disabled=t.disabled),this._previousControl=t.control),this.updateErrorState())}ngOnChanges(e){(e.disabled||e.userAriaDescribedBy)&&this.stateChanges.next(),e.typeaheadDebounceInterval&&this._keyManager&&this._keyManager.withTypeAhead(this.typeaheadDebounceInterval),e.panelClass&&this.panelClass instanceof Set&&(this.panelClass=Array.from(this.panelClass))}ngOnDestroy(){this._cleanupDetach?.(),this._keyManager?.destroy(),this._destroy.next(),this._destroy.complete(),this.stateChanges.complete()}toggle(){this.panelOpen?this.close():this.open()}open(){this._canOpen()&&(this._parentFormField&&(this._preferredOverlayOrigin=this._parentFormField.getConnectedOverlayOrigin()),this._cleanupDetach?.(),this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._panelOpen=!0,this._overlayDir.positionChange.pipe(kt(1)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this._positioningSettled()}),this._overlayDir.attachOverlay(),this._keyManager.withHorizontalOrientation(null),this._highlightCorrectOption(),this._changeDetectorRef.markForCheck(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!0)))}close(){this._panelOpen&&(this._panelOpen=!1,this._exitAndDetach(),this._keyManager.withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`),this._changeDetectorRef.markForCheck(),this._onTouched(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!1)))}_exitAndDetach(){if(this._animationsDisabled||!this.panel){this._detachOverlay();return}this._cleanupDetach?.(),this._cleanupDetach=()=>{t(),clearTimeout(i),this._cleanupDetach=void 0};let e=this.panel.nativeElement,t=this._renderer.listen(e,`animationend`,u=>{u.animationName===`_mat-select-exit`&&(this._cleanupDetach?.(),this._detachOverlay())}),i=setTimeout(()=>{this._cleanupDetach?.(),this._detachOverlay()},200);e.classList.add(`mat-select-panel-exit`)}_detachOverlay(){this._overlayDir.detachOverlay(),this._changeDetectorRef.markForCheck()}writeValue(e){this._assignValue(e)}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck(),this.stateChanges.next()}get panelOpen(){return this._panelOpen}get selected(){return this.multiple?this._selectionModel?.selected||[]:this._selectionModel?.selected[0]}get triggerValue(){if(this.empty)return``;if(this._multiple){let e=this._selectionModel.selected.map(t=>t.viewValue);return this._isRtl()&&e.reverse(),e.join(`, `)}return this._selectionModel.selected[0].viewValue}updateErrorState(){this._errorStateTracker.updateErrorState()}_isRtl(){return this._dir?this._dir.value===`rtl`:!1}_handleKeydown(e){this.disabled||(this.panelOpen?this._handleOpenKeydown(e):this._handleClosedKeydown(e))}_handleClosedKeydown(e){let t=e.keyCode,i=t===40||t===38||t===37||t===39,u=t===13||t===32,y=this._keyManager;if(!y.isTyping()&&u&&!Le(e)||(this.multiple||e.altKey)&&i)e.preventDefault(),this.open();else if(!this.multiple){let w=this.selected;y.onKeydown(e);let _=this.selected;_&&w!==_&&this._liveAnnouncer.announce(_.viewValue,1e4)}}_handleOpenKeydown(e){let t=this._keyManager,i=e.keyCode,u=i===40||i===38,y=t.isTyping();if(u&&e.altKey)e.preventDefault(),this.close();else if(!y&&(i===13||i===32)&&t.activeItem&&!Le(e))e.preventDefault(),t.activeItem._selectViaInteraction();else if(!y&&this._multiple&&i===65&&e.ctrlKey){e.preventDefault();let w=this.options.some(_=>!_.disabled&&!_.selected);this.options.forEach(_=>{_.disabled||(w?_.select():_.deselect())})}else{let w=t.activeItemIndex;t.onKeydown(e),this._multiple&&u&&e.shiftKey&&t.activeItem&&t.activeItemIndex!==w&&t.activeItem._selectViaInteraction()}}_handleOverlayKeydown(e){e.keyCode===27&&!Le(e)&&(e.preventDefault(),this.close())}_onFocus(){this.disabled||(this._focused=!0,this.stateChanges.next())}_onBlur(){this._focused=!1,this._keyManager?.cancelTypeahead(),!this.disabled&&!this.panelOpen&&(this._onTouched(),this._changeDetectorRef.markForCheck(),this.stateChanges.next())}get empty(){return!this._selectionModel||this._selectionModel.isEmpty()}_initializeSelection(){Promise.resolve().then(()=>{this.ngControl&&(this._value=this.ngControl.value),this._setSelectionByValue(this._value),this.stateChanges.next()})}_setSelectionByValue(e){if(this.options.forEach(t=>t.setInactiveStyles()),this._selectionModel.clear(),this.multiple&&e)e.forEach(t=>this._selectOptionByValue(t)),this._sortValues();else{let t=this._selectOptionByValue(e);t?this._keyManager.updateActiveItem(t):this.panelOpen||this._keyManager.updateActiveItem(-1)}this._changeDetectorRef.markForCheck()}_selectOptionByValue(e){let t=this.options.find(i=>{if(this._selectionModel.isSelected(i))return!1;try{return(i.value!=null||this.canSelectNullableOptions)&&this._compareWith(i.value,e)}catch{return!1}});return t&&this._selectionModel.select(t),t}_assignValue(e){return e!==this._value||this._multiple&&Array.isArray(e)?(this.options&&this._setSelectionByValue(e),this._value=e,!0):!1}_skipPredicate=e=>this.panelOpen?!1:e.disabled;_getOverlayWidth(e){return this.panelWidth===`auto`?(e instanceof se?e.elementRef:e||this._elementRef).nativeElement.getBoundingClientRect().width:this.panelWidth===null?``:this.panelWidth}_syncParentProperties(){if(this.options)for(let e of this.options)e._changeDetectorRef.markForCheck()}_initKeyManager(){this._keyManager=new $(this.options).withTypeAhead(this.typeaheadDebounceInterval).withVerticalOrientation().withHorizontalOrientation(this._isRtl()?`rtl`:`ltr`).withHomeAndEnd().withPageUpDown().withAllowedModifierKeys([`shiftKey`]).skipPredicate(this._skipPredicate),this._keyManager.tabOut.subscribe(()=>{this.panelOpen&&(!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction(),this.focus(),this.close())}),this._keyManager.change.subscribe(()=>{this._panelOpen&&this.panel?this._scrollOptionIntoView(this._keyManager.activeItemIndex||0):!this._panelOpen&&!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction()})}_resetOptions(){let e=Yy(this.options.changes,this._destroy);this.optionSelectionChanges.pipe(iv(e)).subscribe(t=>{this._onSelect(t.source,t.isUserInput),t.isUserInput&&!this.multiple&&this._panelOpen&&(this.close(),this.focus())}),Yy(...this.options.map(t=>t._stateChanges)).pipe(iv(e)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this.stateChanges.next()})}_onSelect(e,t){let i=this._selectionModel.isSelected(e);!this.canSelectNullableOptions&&e.value==null&&!this._multiple?(e.deselect(),this._selectionModel.clear(),this.value!=null&&this._propagateChanges(e.value)):(i!==e.selected&&(e.selected?this._selectionModel.select(e):this._selectionModel.deselect(e)),t&&this._keyManager.setActiveItem(e),this.multiple&&(this._sortValues(),t&&this.focus())),i!==this._selectionModel.isSelected(e)&&this._propagateChanges(),this.stateChanges.next()}_sortValues(){if(this.multiple){let e=this.options.toArray();this._selectionModel.sort((t,i)=>this.sortComparator?this.sortComparator(t,i,e):e.indexOf(t)-e.indexOf(i)),this.stateChanges.next()}}_propagateChanges(e){let t;this.multiple?t=this.selected.map(i=>i.value):t=this.selected?this.selected.value:e,this._value=t,this.valueChange.emit(t),this._onChange(t),this.selectionChange.emit(this._getChangeEvent(t)),this._changeDetectorRef.markForCheck()}_highlightCorrectOption(){if(this._keyManager)if(this.empty){let e=-1;for(let t=0;t<this.options.length;t++)if(!this.options.get(t).disabled){e=t;break}this._keyManager.setActiveItem(e)}else this._keyManager.setActiveItem(this._selectionModel.selected[0])}_canOpen(){return!this._panelOpen&&!this.disabled&&this.options?.length>0&&!!this._overlayDir}focus(e){this._elementRef.nativeElement.focus(e)}_getPanelAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||null,t=e?e+` `:``;return this.ariaLabelledby?t+this.ariaLabelledby:e}_getAriaActiveDescendant(){return this.panelOpen&&this._keyManager&&this._keyManager.activeItem?this._keyManager.activeItem.id:null}_getTriggerAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||``;return this.ariaLabelledby&&(e+=` `+this.ariaLabelledby),e||(e=this._valueId),e}get describedByIds(){return this._elementRef.nativeElement.getAttribute(`aria-describedby`)?.split(` `)||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute(`aria-describedby`,e.join(` `)):t.removeAttribute(`aria-describedby`)}onContainerClick(e){let t=g$1(e);t&&(t.tagName===`MAT-OPTION`||t.classList.contains(`cdk-overlay-backdrop`)||t.closest(`.mat-mdc-select-panel`))||(this.focus(),this.open())}get shouldLabelFloat(){return this.panelOpen||!this.empty||this.focused&&!!this.placeholder}static ɵfac=function(t){return new(t||n)};static ɵcmp=(function(){let e=[`trigger`],t=[`panel`],i=[[[`mat-select-trigger`]],`*`],u=[`mat-select-trigger`,`*`];function y(g,v){if(g&1&&(Es(0,`span`,4),BC(1),hu()),g&2){let c=pC();QE(),Kg(c.placeholder)}}function w(g,v){g&1&&Du(0)}function _(g,v){if(g&1&&(Es(0,`span`,11),BC(1),hu()),g&2){let c=pC(2);QE(),Kg(c.triggerValue)}}function C(g,v){if(g&1&&(Es(0,`span`,5),Kw(1,w,1,0)(2,_,2,1,`span`,11),hu()),g&2){let c=pC();QE(),Jw(c.customTrigger?1:2)}}function h(g,v){if(g&1){let c=aC();Es(0,`div`,12,1),Pg(`keydown`,function(M){yf(c);let _n=pC();return vf(_n._handleKeydown(M))}),Du(2,1),hu()}if(g&2){let c=pC();Eu(c.panelClass),Rs(`mat-select-panel-animations-enabled`,!c._animationsDisabled)(`mat-primary`,c._parentFormField?.color===`primary`)(`mat-accent`,c._parentFormField?.color===`accent`)(`mat-warn`,c._parentFormField?.color===`warn`)(`mat-undefined`,!c._parentFormField?.color),No(`id`,c.id+`-panel`)(`aria-multiselectable`,c.multiple)(`aria-label`,c.ariaLabel||null)(`aria-labelledby`,c._getPanelAriaLabelledby())}}return So({type:n,selectors:[[`mat-select`]],contentQueries:function(v,c,b){if(v&1&&Vg(b,Sn,5)(b,Q,5)(b,Ie,5),v&2){let M;mC(M=yC())&&(c.customTrigger=M.first),mC(M=yC())&&(c.options=M),mC(M=yC())&&(c.optionGroups=M)}},viewQuery:function(v,c){if(v&1&&Bg(e,5)(t,5)(li$1,5),v&2){let b;mC(b=yC())&&(c.trigger=b.first),mC(b=yC())&&(c.panel=b.first),mC(b=yC())&&(c._overlayDir=b.first)}},hostAttrs:[`role`,`combobox`,`aria-haspopup`,`listbox`,1,`mat-mdc-select`],hostVars:21,hostBindings:function(v,c){v&1&&Pg(`keydown`,function(M){return c._handleKeydown(M)})(`focus`,function(){return c._onFocus()})(`blur`,function(){return c._onBlur()}),v&2&&(No(`id`,c.id)(`tabindex`,c.disabled?-1:c.tabIndex)(`aria-controls`,c.panelOpen?c.id+`-panel`:null)(`aria-expanded`,c.panelOpen)(`aria-label`,c.ariaLabel||null)(`aria-required`,c.required.toString())(`aria-disabled`,c.disabled.toString())(`aria-invalid`,c.errorState)(`aria-activedescendant`,c._getAriaActiveDescendant()),Rs(`mat-mdc-select-disabled`,c.disabled)(`mat-mdc-select-invalid`,c.errorState)(`mat-mdc-select-required`,c.required)(`mat-mdc-select-empty`,c.empty)(`mat-mdc-select-multiple`,c.multiple)(`mat-select-open`,c.panelOpen))},inputs:{userAriaDescribedBy:[0,`aria-describedby`,`userAriaDescribedBy`],panelClass:`panelClass`,disabled:[2,`disabled`,`disabled`,_u],disableRipple:[2,`disableRipple`,`disableRipple`,_u],tabIndex:[2,`tabIndex`,`tabIndex`,g=>g==null?0:Ob(g)],hideSingleSelectionIndicator:[2,`hideSingleSelectionIndicator`,`hideSingleSelectionIndicator`,_u],placeholder:`placeholder`,required:[2,`required`,`required`,_u],multiple:[2,`multiple`,`multiple`,_u],disableOptionCentering:[2,`disableOptionCentering`,`disableOptionCentering`,_u],compareWith:`compareWith`,value:`value`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],errorStateMatcher:`errorStateMatcher`,typeaheadDebounceInterval:[2,`typeaheadDebounceInterval`,`typeaheadDebounceInterval`,Ob],sortComparator:`sortComparator`,id:`id`,panelWidth:`panelWidth`,canSelectNullableOptions:[2,`canSelectNullableOptions`,`canSelectNullableOptions`,_u]},outputs:{openedChange:`openedChange`,_openedStream:`opened`,_closedStream:`closed`,selectionChange:`selectionChange`,valueChange:`valueChange`},exportAs:[`matSelect`],features:[nm([{provide:At,useExisting:n},{provide:Ee,useExisting:n}]),Nl],ngContentSelectors:u,decls:11,vars:10,consts:[[`fallbackOverlayOrigin`,`cdkOverlayOrigin`,`trigger`,``],[`panel`,``],[`cdk-overlay-origin`,``,1,`mat-mdc-select-trigger`,3,`click`],[1,`mat-mdc-select-value`],[1,`mat-mdc-select-placeholder`,`mat-mdc-select-min-line`],[1,`mat-mdc-select-value-text`],[1,`mat-mdc-select-arrow-wrapper`],[1,`mat-mdc-select-arrow`],[`viewBox`,`0 0 24 24`,`width`,`24px`,`height`,`24px`,`focusable`,`false`,`aria-hidden`,`true`],[`d`,`M7 10l5 5 5-5z`],[`cdk-connected-overlay`,``,`cdkConnectedOverlayHasBackdrop`,``,`cdkConnectedOverlayBackdropClass`,`cdk-overlay-transparent-backdrop`,3,`detach`,`backdropClick`,`overlayKeydown`,`cdkConnectedOverlayDisableClose`,`cdkConnectedOverlayPanelClass`,`cdkConnectedOverlayScrollStrategy`,`cdkConnectedOverlayOrigin`,`cdkConnectedOverlayPositions`,`cdkConnectedOverlayWidth`,`cdkConnectedOverlayFlexibleDimensions`,`cdkConnectedOverlayUsePopover`],[1,`mat-mdc-select-min-line`],[`role`,`listbox`,`tabindex`,`-1`,1,`mat-mdc-select-panel`,`mdc-menu-surface`,`mdc-menu-surface--open`,3,`keydown`]],template:function(v,c){if(v&1&&(vu(i),Es(0,`div`,2,0),Pg(`click`,function(){return c.open()}),Es(3,`div`,3),Kw(4,y,2,1,`span`,4)(5,C,3,1,`span`,5),hu(),Es(6,`div`,6)(7,`div`,7),Af(),Es(8,`svg`,8),Rg(9,`path`,9),hu()()()(),Sg(10,h,3,16,`ng-template`,10),Pg(`detach`,function(){return c.close()})(`backdropClick`,function(){return c.close()})(`overlayKeydown`,function(M){return c._handleOverlayKeydown(M)})),v&2){let b=DC(1);QE(3),No(`id`,c._valueId),QE(),Jw(c.empty?4:5),QE(6),xg(`cdkConnectedOverlayDisableClose`,!0)(`cdkConnectedOverlayPanelClass`,c._overlayPanelClass)(`cdkConnectedOverlayScrollStrategy`,c._scrollStrategy)(`cdkConnectedOverlayOrigin`,c._preferredOverlayOrigin||b)(`cdkConnectedOverlayPositions`,c._positions)(`cdkConnectedOverlayWidth`,c._overlayWidth)(`cdkConnectedOverlayFlexibleDimensions`,!0)(`cdkConnectedOverlayUsePopover`,c._popoverLocation)}},dependencies:[se,li$1],styles:[`@keyframes _mat-select-enter {
  from {
    opacity: 0;
    transform: scaleY(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-select-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-select {
  display: inline-block;
  width: 100%;
  outline: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  color: var(--%NS%mat-select-enabled-trigger-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-select-trigger-text-font, var(--%NS%mat-sys-body-large-font));
  line-height: var(--%NS%mat-select-trigger-text-line-height, var(--%NS%mat-sys-body-large-line-height));
  font-size: var(--%NS%mat-select-trigger-text-size, var(--%NS%mat-sys-body-large-size));
  font-weight: var(--%NS%mat-select-trigger-text-weight, var(--%NS%mat-sys-body-large-weight));
  letter-spacing: var(--%NS%mat-select-trigger-text-tracking, var(--%NS%mat-sys-body-large-tracking));
}

div.mat-mdc-select-panel {
  box-shadow: var(--%NS%mat-select-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}

.mat-mdc-select-disabled {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-select-disabled .mat-mdc-select-placeholder {
  color: var(--%NS%mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-select-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}
.mat-mdc-select-disabled .mat-mdc-select-trigger {
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
}

.mat-mdc-select-value {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mat-mdc-select-value-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mat-mdc-select-arrow-wrapper {
  height: 24px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
}
.mat-form-field-appearance-fill .mdc-text-field--no-label .mat-mdc-select-arrow-wrapper {
  transform: none;
}

.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-invalid .mat-mdc-select-arrow,
.mat-form-field-invalid:not(.mat-form-field-disabled) .mat-mdc-form-field-infix::after {
  color: var(--%NS%mat-select-invalid-arrow-color, var(--%NS%mat-sys-error));
}

.mat-mdc-select-arrow {
  width: 10px;
  height: 5px;
  position: relative;
  color: var(--%NS%mat-select-enabled-arrow-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field.mat-focused .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-focused-arrow-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-disabled .mat-mdc-select-arrow {
  color: var(--%NS%mat-select-disabled-arrow-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-select-open .mat-mdc-select-arrow {
  transform: rotate(180deg);
}
.mat-form-field-animations-enabled .mat-mdc-select-arrow {
  transition: transform 80ms linear;
}
.mat-mdc-select-arrow svg {
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (forced-colors: active) {
  .mat-mdc-select-arrow svg {
    fill: CanvasText;
  }
  .mat-mdc-select-disabled .mat-mdc-select-arrow svg {
    fill: GrayText;
  }
}

div.mat-mdc-select-panel {
  width: 100%;
  max-height: 275px;
  outline: 0;
  overflow: auto;
  padding: 8px 0;
  box-sizing: border-box;
  transform-origin: top center;
  border-radius: 0 0 4px 4px;
  position: relative;
  background-color: var(--%NS%mat-select-panel-background-color, var(--%NS%mat-sys-surface-container));
}
.mat-mdc-select-panel-above div.mat-mdc-select-panel {
  border-radius: 4px 4px 0 0;
  transform-origin: bottom center;
}
@media (forced-colors: active) {
  div.mat-mdc-select-panel {
    outline: solid 1px;
  }
}

.mat-select-panel-animations-enabled {
  animation: _mat-select-enter 120ms cubic-bezier(0, 0, 0.2, 1) forwards;
}
.mat-select-panel-animations-enabled.mat-select-panel-exit {
  animation: _mat-select-exit 100ms linear forwards;
}

.mat-mdc-select-placeholder {
  transition: color 400ms 133.3333333333ms cubic-bezier(0.25, 0.8, 0.25, 1);
  color: var(--%NS%mat-select-placeholder-text-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-form-field:not(.mat-form-field-animations-enabled) .mat-mdc-select-placeholder, ._mat-animation-noopable .mat-mdc-select-placeholder {
  transition: none;
}
.mat-form-field-hide-placeholder .mat-mdc-select-placeholder {
  color: transparent;
  -webkit-text-fill-color: transparent;
  transition: none;
  display: block;
}

.mat-mdc-form-field-type-mat-select:not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper {
  cursor: pointer;
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mat-mdc-floating-label {
  max-width: calc(100% - 18px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mdc-floating-label--float-above {
  max-width: calc(100% / 0.75 - 24px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-notched-outline__notch {
  max-width: calc(100% - 60px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-text-field--label-floating .mdc-notched-outline__notch {
  max-width: calc(100% - 24px);
}

.mat-mdc-select-min-line:empty::before {
  content: " ";
  white-space: pre;
  width: 1px;
  display: inline-block;
  visibility: hidden;
}

.mat-form-field-appearance-fill .mat-mdc-select-arrow-wrapper {
  transform: var(--%NS%mat-select-arrow-transform, translateY(-8px));
}
`],encapsulation:2})})()}return n})();var hn=(()=>{class n{static ɵfac=function(t){return new(t||n)};static ɵmod=Ct({type:n});static ɵinj=Xe({imports:[gt,Te,hy,Jt,Vt,Te]})}return n})();var Pe=n=>[`/clientes`,n];var wn=()=>[`/clientes`];var kn=n=>[`/clientes`,n,`recetas`,`nueva`];var gn=(n,o)=>o.id;function En(n,o){n&1&&Rg(0,`mat-progress-bar`,1)}function In(n,o){n&1&&(BC(0,` Para `),Es(1,`strong`),BC(2),hu(),BC(3,`. Usa una receta existente como referencia. `)),n&2&&(QE(2),Kg(o.full_name))}function Tn(n,o){n&1&&BC(0,` Registra un pedido para un cliente. `)}function Nn(n,o){if(n&1&&(Es(0,`div`,6)(1,`span`,3),BC(2,`error`),hu(),Es(3,`span`),BC(4),hu()()),n&2){let e=pC();QE(4),Kg(e.error())}}function Pn(n,o){if(n&1&&(Es(0,`div`,11)(1,`span`,3),BC(2,`photo_camera_back`),hu(),Es(3,`h3`),BC(4,`Este cliente no tiene recetas`),hu(),Es(5,`p`),BC(6,`Para crear un pedido primero debes registrar la fotografía de la receta.`),hu(),Es(7,`a`,32)(8,`span`,3),BC(9,`photo_camera`),hu(),BC(10,` Registrar receta `),hu()()),n&2){let e=pC();QE(7),xg(`routerLink`,YC(1,kn,e.id))}}function Fn(n,o){if(n&1&&BC(0),n&2){let e=pC().$implicit;Iu(` · `,e.observations,` `)}}function Dn(n,o){if(n&1&&(Es(0,`mat-option`,18),BC(1),XC(2,`date`),Kw(3,Fn,1,1),BC(4),hu()),n&2){let e=o.$implicit;xg(`value`,e.id),QE(),Iu(` `,eb(2,5,e.registered_at,`dd/MM/yyyy`),` `),QE(2),Jw(e.observations?3:-1),QE(),Xg(` (`,e.images.length,` foto`,e.images.length===1?``:`s`,`) `)}}function An(n,o){n&1&&(Es(0,`mat-error`),BC(1,`Selecciona la receta que se usará.`),hu())}function Rn(n,o){if(n&1){let e=aC();Es(0,`button`,36),Pg(`click`,function(){let i=yf(e).$implicit,u=pC(4);return vf(u.openImage(i))}),Rg(1,`app-auth-image`,37),hu()}if(n&2){let e=o.$implicit;QE(),xg(`image`,e)}}function Vn(n,o){if(n&1&&(Es(0,`div`,34),tC(1,Rn,2,1,`button`,35,gn),hu()),n&2){let e=pC();QE(),nC(e.images)}}function Ln(n,o){if(n&1&&(Es(0,`div`,19)(1,`div`,33)(2,`span`,3),BC(3,`description`),hu(),Es(4,`div`)(5,`strong`),BC(6),XC(7,`date`),hu(),Es(8,`p`,9),BC(9),hu()()(),Kw(10,Vn,3,0,`div`,34),hu()),n&2){let e=o;QE(6),Iu(`Receta del `,eb(7,3,e.registered_at,`dd/MM/yyyy`)),QE(3),Kg(e.observations||`Sin observaciones.`),QE(),Jw(e.images.length?10:-1)}}function Bn(n,o){if(n&1&&(Es(0,`option`,18),BC(1),hu()),n&2){let e=o.$implicit;xg(`value`,e),QE(),Kg(e)}}function zn(n,o){n&1&&BC(0,` El tipo de lentes no puede superar los 100 caracteres. `)}function Gn(n,o){n&1&&BC(0,` Indica el tipo de lentes. `)}function Wn(n,o){if(n&1&&(Es(0,`mat-error`),Kw(1,zn,1,0)(2,Gn,1,0),hu()),n&2){let e=pC(2);QE(),Jw(e.form.controls.lens_type.errors?.maxlength?1:2)}}function qn(n,o){n&1&&BC(0,` Escribe el tipo de lentes. `)}function Kn(n,o){n&1&&BC(0,` El tipo de lentes no puede superar los 100 caracteres. `)}function jn(n,o){if(n&1&&(Es(0,`mat-error`),Kw(1,qn,1,0)(2,Kn,1,0),hu()),n&2){let e=pC(3);QE(),Jw(e.form.controls.lens_type_other.errors?.required?1:e.form.controls.lens_type_other.errors?.maxlength?2:-1)}}function Hn(n,o){if(n&1&&(Es(0,`mat-form-field`,16)(1,`mat-label`),BC(2,`Escribe el tipo de lentes`),hu(),Es(3,`input`,38),BI(),hu(),Es(4,`mat-hint`),BC(5,`Máximo 100 caracteres.`),hu(),Kw(6,jn,3,1,`mat-error`),hu()),n&2){let e=pC(2);QE(3),UI(),QE(3),Jw(e.form.controls.lens_type_other.touched&&e.form.controls.lens_type_other.invalid?6:-1)}}function Un(n,o){n&1&&BC(0,` La fecha no puede ser futura. `)}function Qn(n,o){n&1&&BC(0,` Selecciona la fecha del pedido. `)}function Yn(n,o){if(n&1&&(Es(0,`mat-error`),Kw(1,Un,1,0)(2,Qn,1,0),hu()),n&2){let e=pC(2);QE(),Jw(e.form.controls.ordered_at.errors?.futureDate?1:2)}}function $n(n,o){n&1&&BC(0,` El precio no puede superar Bs 999.999. `)}function Xn(n,o){n&1&&BC(0,` El precio no puede ser negativo. `)}function Jn(n,o){if(n&1&&(Es(0,`mat-error`),Kw(1,$n,1,0)(2,Xn,1,0),hu()),n&2){let e=pC(2);QE(),Jw(e.form.controls.price.errors?.max?1:2)}}function Zn(n,o){n&1&&BC(0,` El adelanto no puede superar el precio total. `)}function ei(n,o){n&1&&BC(0,` El adelanto no puede superar Bs 999.999. `)}function ti(n,o){n&1&&BC(0,` El adelanto no puede ser negativo. `)}function ni(n,o){if(n&1&&(Es(0,`mat-error`),Kw(1,Zn,1,0)(2,ei,1,0)(3,ti,1,0),hu()),n&2){let e=pC(2);QE(),Jw(e.form.controls.advance.errors?.exceedsPrice?1:e.form.controls.advance.errors?.max?2:3)}}function ii(n,o){n&1&&(Es(0,`span`,41),BC(1,`El adelanto supera el precio. Corrige los montos.`),hu())}function ai(n,o){if(n&1&&(Es(0,`div`,39)(1,`span`,3),BC(2),hu(),Es(3,`div`)(4,`span`,40),BC(5,`Saldo pendiente`),hu(),Es(6,`strong`),BC(7),hu()(),Kw(8,ii,2,0,`span`,41),hu()),n&2){let e=pC(2);Rs(`balance-box--alert`,e.advanceExceedsPrice()),QE(2),Kg(e.advanceExceedsPrice()?`warning`:`account_balance_wallet`),QE(5),Kg(e.money(e.balance())),QE(),Jw(e.advanceExceedsPrice()?8:-1)}}function oi(n,o){n&1&&(Rg(0,`span`,42),BC(1,` Registrando… `))}function ri(n,o){n&1&&(Es(0,`span`,3),BC(1,`add_shopping_cart`),hu(),BC(2,` Registrar pedido `))}function li(n,o){if(n&1){let e=aC();Es(0,`div`,7)(1,`span`,8),BC(2),hu(),Es(3,`div`)(4,`strong`),BC(5),hu(),Es(6,`span`,9),BC(7),hu()(),Es(8,`a`,10),BC(9,`Ver ficha`),hu()(),Kw(10,Pn,11,3,`div`,11),Es(11,`div`,12)(12,`form`,13),Pg(`ngSubmit`,function(){yf(e);let i=pC();return vf(i.submit())}),Es(13,`p`,14),BC(14,`Los campos con * son obligatorios.`),hu(),Es(15,`div`,15)(16,`mat-form-field`,16)(17,`mat-label`),BC(18,`Receta utilizada`),hu(),Es(19,`mat-select`,17),BI(),tC(20,Dn,5,8,`mat-option`,18,gn),hu(),Es(22,`mat-hint`),BC(23,`Receta que respalda las medidas de este pedido.`),hu(),Kw(24,An,2,0,`mat-error`),hu(),Kw(25,Ln,11,6,`div`,19),Es(26,`mat-form-field`,20)(27,`mat-label`),BC(28,`Tipo de lentes`),hu(),Es(29,`select`,21),BI(),Pg(`change`,function(i){yf(e);let u=pC();return vf(u.onLensTypeChange(i))}),tC(30,Bn,2,2,`option`,18,eC),hu(),Es(32,`mat-hint`),BC(33,`Selecciona el tipo de lentes.`),hu(),Kw(34,Wn,3,1,`mat-error`),hu(),Kw(35,Hn,7,1,`mat-form-field`,16),Es(36,`mat-form-field`,20)(37,`mat-label`),BC(38,`Fecha del pedido`),hu(),Es(39,`input`,22),BI(),hu(),Es(40,`mat-hint`),BC(41,`No puede ser una fecha futura.`),hu(),Kw(42,Yn,3,1,`mat-error`),hu(),Es(43,`mat-form-field`,20)(44,`mat-label`),BC(45,`Precio total (opcional)`),hu(),Es(46,`span`,23),BC(47,`Bs\xA0`),hu(),Es(48,`input`,24),BI(),hu(),Es(49,`mat-hint`),BC(50,`Opcional. Si lo registras, se calcula el saldo.`),hu(),Kw(51,Jn,3,1,`mat-error`),hu(),Es(52,`mat-form-field`,20)(53,`mat-label`),BC(54,`Adelanto (opcional)`),hu(),Es(55,`span`,23),BC(56,`Bs\xA0`),hu(),Es(57,`input`,25),BI(),hu(),Es(58,`mat-hint`),BC(59,`Opcional. No puede superar el precio total.`),hu(),Kw(60,ni,4,1,`mat-error`),hu(),Kw(61,ai,9,5,`div`,26),Es(62,`mat-form-field`,16)(63,`mat-label`),BC(64,`Observaciones del pedido (opcional)`),hu(),Es(65,`textarea`,27),BI(),hu(),Es(66,`mat-hint`),BC(67,`Opcional: detalles del tratamiento, montura o fecha prometida.`),hu(),Es(68,`mat-hint`,28),BC(69),hu()()(),Es(70,`div`,29)(71,`button`,30),Kw(72,oi,2,0)(73,ri,3,0),hu(),Es(74,`a`,31),BC(75,`Cancelar`),hu()()()()}if(n&2){let e,t=o,i=pC();QE(2),Kg(t.full_name.charAt(0)),QE(3),Kg(t.full_name),QE(2),Kg(t.phone),QE(),xg(`routerLink`,YC(19,Pe,t.id)),QE(2),Jw(i.prescriptions.length===0?10:-1),QE(2),xg(`formGroup`,i.form),QE(7),UI(),QE(),nC(i.prescriptions),QE(4),Jw(i.form.controls.prescription_id.touched&&i.form.controls.prescription_id.invalid?24:-1),QE(),Jw((e=i.selectedPrescription())?25:-1,e),QE(4),UI(),QE(),nC(i.lensTypes),QE(4),Jw(i.form.controls.lens_type.touched&&i.form.controls.lens_type.invalid?34:-1),QE(),Jw(i.showLensTypeOther()?35:-1),QE(4),xg(`max`,i.today),UI(),QE(3),Jw(i.form.controls.ordered_at.touched&&i.form.controls.ordered_at.invalid?42:-1),QE(6),UI(),QE(3),Jw(i.form.controls.price.touched&&i.form.controls.price.invalid?51:-1),QE(6),UI(),QE(3),Jw(i.form.controls.advance.touched&&i.form.controls.advance.invalid?60:-1),QE(),Jw(i.balance()!==null?61:-1),QE(4),UI(),QE(4),Iu(``,i.form.controls.observations.value?.length||0,` / 2000`),QE(2),xg(`disabled`,i.saving()||i.prescriptions.length===0),QE(),Jw(i.saving()?72:73),QE(2),xg(`routerLink`,YC(21,Pe,t.id))}}var fn=class n{fb=g(Wr);clients=g(g$2);orders=g(m$1);toast=g(u);route=g(B);router=g(G);dialog=g(Je);destroyRef=g(he);client=or(null);loading=or(!0);saving=or(!1);error=or(null);today=m();lensTypes=[`Monofocal`,`Bifocal`,`Progresivo`,`Ocupacional`,`Fotocromático`,`Antirreflejo`,`Lentes de sol`,`Otro`];showLensTypeOther=or(!1);lensTypeOther=or(``);form=this.fb.group({prescription_id:[null,[Me.required]],lens_type:[``,[Me.required,Me.maxLength(100),ts]],lens_type_other:[``,[Me.maxLength(100)]],observations:[``,[Me.maxLength(2e3)]],price:[null,[Me.min(0),Me.max(999999)]],advance:[null,[Me.min(0),Me.max(999999)]],ordered_at:[m(),[Me.required,is]]});constructor(){this.form.controls.price.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError()),this.form.controls.advance.valueChanges.pipe(U(this.destroyRef)).subscribe(()=>this.syncAdvanceError())}ngOnInit(){let o=Number(this.route.snapshot.queryParamMap.get(`clientId`)),e=Number(this.route.snapshot.queryParamMap.get(`prescriptionId`));if(!o){this.toast.info(rU.orders.selectClientFirst),this.router.navigate([`/clientes`]);return}this.clients.get(o).subscribe({next:t=>{this.client.set(t.data),this.loading.set(!1);let i=t.data.prescriptions??[],u=i.find(y=>y.id===e);u?this.form.controls.prescription_id.setValue(u.id):i.length===1&&this.form.controls.prescription_id.setValue(i[0].id)},error:t=>{this.loading.set(!1),this.error.set(qr(t,rU.clients.loadFallback))}})}get prescriptions(){return this.client()?.prescriptions??[]}selectedPrescription(){let o=this.form.controls.prescription_id.value;return this.prescriptions.find(e=>e.id===o)??null}balance(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o==null?null:Math.round((Number(o)-Number(e??0))*100)/100}syncAdvanceError(){let o=this.form.controls.advance,e=o.errors??{};if(this.advanceExceedsPrice()){o.setErrors(G$1(V({},e),{exceedsPrice:!0}));return}if(e.exceedsPrice){let t=V({},e);delete t.exceedsPrice,o.setErrors(Object.keys(t).length>0?t:null)}}advanceExceedsPrice(){let o=this.form.controls.price.value,e=this.form.controls.advance.value;return o!==null&&e!==null&&Number(e)>Number(o)}money(o){return f(o)}onLensTypeChange(o){let e=o.target.value;this.showLensTypeOther.set(e===`Otro`),e!==`Otro`&&(this.lensTypeOther.set(``),this.form.controls.lens_type_other.setValue(``))}openImage(o,e){this.dialog.open(D,{data:{image:o,title:e},width:`min(1000px, 94vw)`,maxWidth:`94vw`,panelClass:`app-dialog`,autoFocus:!1})}submit(){let o=this.client();if(!o)return;if(this.prescriptions.length===0){this.error.set(rU.orders.noPrescription);return}if(this.form.controls.lens_type.value===`Otro`&&!(this.form.controls.lens_type_other.value??``).trim()){this.form.controls.lens_type_other.markAsTouched(),this.error.set(`Escribe el tipo de lentes.`);return}if(this.form.invalid){this.form.markAllAsTouched();return}if(this.advanceExceedsPrice()){this.error.set(rU.orders.advanceExceedsPrice);return}let e=this.form.getRawValue(),t=e.lens_type===`Otro`?(e.lens_type_other??``).trim():(e.lens_type??``).trim();this.saving.set(!0),this.error.set(null),this.orders.create({client_id:o.id,prescription_id:Number(e.prescription_id),lens_type:t,observations:e.observations?.trim()||null,price:e.price===null?null:Number(e.price),advance:e.advance===null?null:Number(e.advance),ordered_at:e.ordered_at??m()}).subscribe({next:i=>{this.saving.set(!1),this.toast.success(rU.orders.createSuccess(i.data.id)),this.router.navigate([`/pedidos`,i.data.id])},error:i=>{this.saving.set(!1),this.error.set(qr(i,rU.orders.createFallback))}})}static ɵfac=function(e){return new(e||n)};static ɵcmp=So({type:n,selectors:[[`app-order-form`]],decls:15,vars:8,consts:[[1,`page`,`page--narrow`],[`mode`,`indeterminate`,1,`loading-bar`],[1,`back-link`,3,`routerLink`],[1,`material-icons`],[1,`page-header`],[1,`page-header__text`],[1,`banner`,`banner--danger`,2,`margin-bottom`,`14px`],[1,`card`,`client-summary`],[1,`client-summary__avatar`],[1,`muted`,`small`],[1,`btn`,`btn--ghost`,`btn--sm`,3,`routerLink`],[1,`empty-state`,2,`margin-bottom`,`14px`],[1,`card`],[1,`stack`,3,`ngSubmit`,`formGroup`],[1,`form-required-note`],[1,`form-grid`],[`appearance`,`outline`,1,`full`],[`formControlName`,`prescription_id`,`placeholder`,`Selecciona una receta`],[3,`value`],[1,`prescription-summary`,`full`],[`appearance`,`outline`],[`matNativeControl`,``,`formControlName`,`lens_type`,3,`change`],[`matInput`,``,`type`,`date`,`formControlName`,`ordered_at`,3,`max`],[`matPrefix`,``],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`price`,`inputmode`,`decimal`],[`matInput`,``,`type`,`number`,`min`,`0`,`max`,`999999`,`step`,`0.01`,`formControlName`,`advance`,`inputmode`,`decimal`],[1,`balance-box`,`full`,3,`balance-box--alert`],[`matInput`,``,`rows`,`3`,`maxlength`,`2000`,`formControlName`,`observations`,`placeholder`,`Ej. Tratamiento antirreflejo, montura elegida, fecha prometida…`],[`align`,`end`],[1,`form-actions`],[`type`,`submit`,1,`btn`,`btn--primary`,`btn--lg`,3,`disabled`],[1,`btn`,`btn--outline`,`btn--lg`,3,`routerLink`],[1,`btn`,`btn--primary`,2,`margin-top`,`14px`,3,`routerLink`],[1,`prescription-summary__info`],[1,`prescription-summary__photos`],[`type`,`button`,1,`photo-thumb`],[`type`,`button`,1,`photo-thumb`,3,`click`],[3,`image`],[`matInput`,``,`formControlName`,`lens_type_other`,`maxlength`,`100`,`placeholder`,`Ej. Bifocal azul`],[1,`balance-box`,`full`],[1,`small`,`muted`],[1,`small`],[1,`spinner`]],template:function(e,t){if(e&1&&(Es(0,`div`,0),Kw(1,En,1,0,`mat-progress-bar`,1),Es(2,`a`,2)(3,`span`,3),BC(4,`arrow_back`),hu(),BC(5,` Volver a la ficha del cliente `),hu(),Es(6,`header`,4)(7,`div`,5)(8,`h1`),BC(9,`Nuevo pedido`),hu(),Es(10,`p`),Kw(11,In,4,1)(12,Tn,1,0),hu()()(),Kw(13,Nn,5,1,`div`,6),Kw(14,li,76,23),hu()),e&2){let i,u;QE(),Jw(t.loading()?1:-1),QE(),xg(`routerLink`,t.client()?YC(5,Pe,t.client()?.id):ZC(7,wn)),QE(9),Jw((i=t.client())?11:12,i),QE(2),Jw(t.error()?13:-1),QE(),Jw((u=t.client())?14:-1,u)}},dependencies:[Bm,Kr,Ur,qr$1,$r,vn,or$1,Bn$1,Br,Hr,ji,Pi,Ti,wt,sr,ua,di,Vt,ri$1,Dt,Ft,mr,hr$1,Ja,Qa,hn,un,Q,tU,Fr,Lr,C,oT],styles:[`.page--narrow[_ngcontent-%COMP%]{max-width:900px}.back-link[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:5px;color:var(--%NS%optic-primary-dark);font-weight:600;font-size:.82rem;margin-bottom:10px;text-decoration:none}.back-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.back-link[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}.client-summary[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:14px 18px;margin-bottom:14px}.client-summary__avatar[_ngcontent-%COMP%]{width:42px;height:42px;border-radius:12px;background:#def5f5;color:#007171;display:grid;place-items:center;font-weight:800;text-transform:uppercase;flex-shrink:0}.client-summary[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1;min-width:0}.client-summary[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.95rem}.prescription-summary[_ngcontent-%COMP%]{background:#f7fbfb;border:1px solid #e4efef;border-radius:12px;padding:12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}.prescription-summary__info[_ngcontent-%COMP%]{display:flex;gap:9px;align-items:flex-start;flex:1;min-width:200px}.prescription-summary__info[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary);font-size:21px;margin-top:1px}.prescription-summary__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.86rem}.prescription-summary__info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin-top:2px}.prescription-summary__photos[_ngcontent-%COMP%]{display:flex;gap:7px;flex-wrap:wrap}.prescription-summary__photos[_ngcontent-%COMP%]   .photo-thumb[_ngcontent-%COMP%]{width:62px;height:52px;aspect-ratio:auto}.balance-box[_ngcontent-%COMP%]{display:flex;align-items:center;gap:11px;background:#f1fafa;border:1px solid #dcefee;border-radius:12px;padding:11px 14px}.balance-box[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary-dark);font-size:24px}.balance-box[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:column}.balance-box[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:1.15rem;color:#164040}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:auto;text-align:right}.balance-box--alert[_ngcontent-%COMP%]{background:var(--%NS%optic-danger-soft);border-color:#f3cccc}.balance-box--alert[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%], .balance-box--alert[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--%NS%optic-danger)}mat-form-field[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]{min-height:44px;border-radius:11px;border:1px solid var(--%NS%optic-border);background:#fff;padding:9px 12px;color:var(--%NS%optic-text);outline:none;min-width:150px;width:100%}mat-form-field[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus{border-color:var(--%NS%optic-primary);box-shadow:0 0 0 3px #00a0a01f}mat-form-field[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:hover{border-color:#4fa8a8}mat-form-field[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]   option[_ngcontent-%COMP%]{background:#fff;color:var(--%NS%optic-text);padding:10px}mat-form-field[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]   option[_ngcontent-%COMP%]:checked{background:#e8f7f7;color:#007171;font-weight:600}.spinner[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:_ngcontent-%COMP%_spin .7s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}@media(max-width:720px){.form-actions[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}}@media(max-width:599px){.balance-box[_ngcontent-%COMP%]{flex-wrap:wrap}.balance-box[_ngcontent-%COMP%] > .small[_ngcontent-%COMP%]{margin-left:0;flex-basis:100%;text-align:left}}`]})};export{fn as OrderFormComponent};