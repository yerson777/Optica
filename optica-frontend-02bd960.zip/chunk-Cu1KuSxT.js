import{$n as vu,$t as eU,A as Fg,At as Xy,C as Dr,Cn as nC,Ct as Vf,Dn as nm,E as Ed,En as ne,F as Gp,Fn as pV,Ft as ZI,G as L,Gn as tU,H as Kg,In as pr,Kn as te,Ln as rU,Mn as ot,Mt as Yy,N as G,Nn as ov,O as Es,On as nt,Ot as Xe,P as Gg,Pn as pC,Q as Mo,R as Iu,Rn as r_,S as Dd,Sn as mu,St as V,T as Ea,Tt as Vn$1,U as Kw,Un as tC,Ut as _u,V as Jw,Wt as aC,Xn as vf,Xt as cs,Y as M2,Z as Mg,_ as Bg,_n as kt,_t as So,a as wr,an as ge$1,ar as yf,b as Ct$1,bn as mC,bt as UI,c as d,ct as Pe,d as AE,dn as hu,er as xg,f as Af,fn as hy,ft as QE,g as BI,gn as jg,h as BC,hn as iv,ht as Rs,i as ua,it as Ob,jn as or,k as Eu,l as K,ln as he$1,lt as Pg,mt as Rg,n as G$1,nt as No,o as x,on as gm,ot as Og,pt as QT,qn as v,qt as bn,r as di$1,rn as g,rr as yC,rt as Nr,s as u,sn as gu,st as Ot,un as hr,ut as Q,v as Bm,vn as le$1,w as Du,wt as Vg,x as DC,xn as ma,yt as Tg,z as J}from"./main-FJ7FCX5K.js";import{t as f}from"./chunk-CBfdjfTI.js";import{i as cr,n as Lr,o as nr,r as Xr,s as qr,t as Fr}from"./chunk-d6EJ4Xmn.js";import{a as He,d as Oe,f as V$1,l as Le,m as Y,o as Ie,p as Vs,r as Be,s as Je,u as Ls,v as g$1,w as z,x as st,y as j}from"./chunk-BnhEUUFB.js";import{b as tt,f as ft,g as le$2,h as j$1,i as Lo,l as de,n as Je$1,o as Nt,p as gt,r as Jt,s as X,t as Bo,x as zo,y as te$1}from"./chunk-D9-DhgAV.js";import{E as ji$1,F as sr,L as vn,N as ri$1,O as mr,P as rs,R as wt,_ as Qa,a as Br,b as Vt,c as Hr,f as Kr,o as Dt,p as Me,s as Ft,u as Ja,x as Wr,y as Ur}from"./chunk-CwrR66eH.js";import{t as g$2}from"./chunk-tTMGsaVa.js";import{t as c}from"./chunk-DwJKCcBy.js";import{n as U,t as T}from"./chunk-D1IS_wMH.js";import{a as y,i as lt,n as K$1,r as ct,t as H}from"./chunk-p4ElF8ZG.js";import{i as x$1,n as N}from"./chunk-7rOEdIKp.js";var oi=new v(`MAT_BADGE_CONFIG`);var Fn=`mat-badge-content`;var ri=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵcmp=So({type:i,selectors:[[`ng-component`]],decls:0,vars:0,template:function(e,n){},styles:[`.mat-badge {
  position: relative;
}
.mat-badge.mat-badge {
  overflow: visible;
}

.mat-badge-content {
  position: absolute;
  text-align: center;
  display: inline-block;
  transition: transform 200ms ease-in-out;
  transform: scale(0.6);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  box-sizing: border-box;
  pointer-events: none;
  background-color: var(--%NS%mat-badge-background-color, var(--%NS%mat-sys-error));
  color: var(--%NS%mat-badge-text-color, var(--%NS%mat-sys-on-error));
  font-family: var(--%NS%mat-badge-text-font, var(--%NS%mat-sys-label-small-font));
  font-weight: var(--%NS%mat-badge-text-weight, var(--%NS%mat-sys-label-small-weight));
  border-radius: var(--%NS%mat-badge-container-shape, var(--%NS%mat-sys-corner-full));
}
.mat-badge-above .mat-badge-content {
  bottom: 100%;
}
.mat-badge-below .mat-badge-content {
  top: 100%;
}
.mat-badge-before .mat-badge-content {
  right: 100%;
}
[dir=rtl] .mat-badge-before .mat-badge-content {
  right: auto;
  left: 100%;
}
.mat-badge-after .mat-badge-content {
  left: 100%;
}
[dir=rtl] .mat-badge-after .mat-badge-content {
  left: auto;
  right: 100%;
}
@media (forced-colors: active) {
  .mat-badge-content {
    outline: solid 1px;
    border-radius: 0;
  }
}

.mat-badge-disabled .mat-badge-content {
  background-color: var(--%NS%mat-badge-disabled-state-background-color, color-mix(in srgb, var(--%NS%mat-sys-error) 38%, transparent));
  color: var(--%NS%mat-badge-disabled-state-text-color, var(--%NS%mat-sys-on-error));
}

.mat-badge-hidden .mat-badge-content {
  display: none;
}

.ng-animate-disabled .mat-badge-content,
.mat-badge-content._mat-animation-noopable {
  transition: none;
}

.mat-badge-content.mat-badge-active {
  transform: none;
}

.mat-badge-small .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-small-size-container-size, unset);
  height: var(--%NS%mat-badge-legacy-small-size-container-size, unset);
  min-width: var(--%NS%mat-badge-small-size-container-size, 6px);
  min-height: var(--%NS%mat-badge-small-size-container-size, 6px);
  line-height: var(--%NS%mat-badge-small-size-line-height, 6px);
  padding: var(--%NS%mat-badge-small-size-container-padding, 0);
  font-size: var(--%NS%mat-badge-small-size-text-size, 0);
  margin: var(--%NS%mat-badge-small-size-container-offset, -6px 0);
}
.mat-badge-small.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-small-size-container-overlap-offset, -6px);
}

.mat-badge-medium .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-container-size, unset);
  height: var(--%NS%mat-badge-legacy-container-size, unset);
  min-width: var(--%NS%mat-badge-container-size, 16px);
  min-height: var(--%NS%mat-badge-container-size, 16px);
  line-height: var(--%NS%mat-badge-line-height, 16px);
  padding: var(--%NS%mat-badge-container-padding, 0 4px);
  font-size: var(--%NS%mat-badge-text-size, var(--%NS%mat-sys-label-small-size));
  margin: var(--%NS%mat-badge-container-offset, -12px 0);
}
.mat-badge-medium.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-container-overlap-offset, -12px);
}

.mat-badge-large .mat-badge-content {
  width: var(--%NS%mat-badge-legacy-large-size-container-size, unset);
  height: var(--%NS%mat-badge-legacy-large-size-container-size, unset);
  min-width: var(--%NS%mat-badge-large-size-container-size, 16px);
  min-height: var(--%NS%mat-badge-large-size-container-size, 16px);
  line-height: var(--%NS%mat-badge-large-size-line-height, 16px);
  padding: var(--%NS%mat-badge-large-size-container-padding, 0 4px);
  font-size: var(--%NS%mat-badge-large-size-text-size, var(--%NS%mat-sys-label-small-size));
  margin: var(--%NS%mat-badge-large-size-container-offset, -12px 0);
}
.mat-badge-large.mat-badge-overlap .mat-badge-content {
  margin: var(--%NS%mat-badge-large-size-container-overlap-offset, -12px);
}
`],encapsulation:2})}return i})();var jn=(()=>{class i{_ngZone=g(le$1);_elementRef=g(nt);_ariaDescriber=g(Ls);_renderer=g(hr);_animationsDisabled=Xr();_idGenerator=g(z);get color(){return this._color}set color(t){this._setColor(t),this._color=t}_color;overlap;disabled=!1;position;get content(){return this._content}set content(t){this._updateRenderedContent(t)}_content;get description(){return this._description}set description(t){this._updateDescription(t)}_description;size;hidden=!1;_badgeElement;_inlineBadgeDescription;_isInitialized=!1;_interactivityChecker=g(Oe);_document=g(L);constructor(){let t=g(oi,{optional:!0}),e=g(QT);e.load(ri),e.load(M2),this._color=t?.color||`primary`,this.overlap=t?.overlap??!0,this.position=t?.position||`above after`,this.size=t?.size||`medium`}isAbove(){return this.position.indexOf(`below`)===-1}isAfter(){return this.position.indexOf(`before`)===-1}getBadgeElement(){return this._badgeElement}ngOnInit(){this._clearExistingBadges(),this.content&&!this._badgeElement&&(this._badgeElement=this._createBadgeElement(),this._updateRenderedContent(this.content)),this._isInitialized=!0}ngAfterViewInit(){}ngOnDestroy(){this._renderer.destroyNode&&(this._renderer.destroyNode(this._badgeElement),this._inlineBadgeDescription?.remove()),this._ariaDescriber.removeDescription(this._elementRef.nativeElement,this.description)}_isHostInteractive(){return this._interactivityChecker.isFocusable(this._elementRef.nativeElement,{ignoreVisibility:!0})}_createBadgeElement(){let t=this._renderer.createElement(`span`),e=`mat-badge-active`;return t.setAttribute(`id`,this._idGenerator.getId(`mat-badge-content-`)),t.setAttribute(`aria-hidden`,`true`),t.classList.add(Fn),this._animationsDisabled&&t.classList.add(`_mat-animation-noopable`),this._elementRef.nativeElement.appendChild(t),typeof requestAnimationFrame==`function`&&!this._animationsDisabled?this._ngZone.runOutsideAngular(()=>{requestAnimationFrame(()=>{t.classList.add(e)})}):t.classList.add(e),t}_updateRenderedContent(t){let e=`${t??``}`.trim();this._isInitialized&&e&&!this._badgeElement&&(this._badgeElement=this._createBadgeElement()),this._badgeElement&&(this._badgeElement.textContent=e),this._content=e}_updateDescription(t){this._ariaDescriber.removeDescription(this._elementRef.nativeElement,this.description),(!t||this._isHostInteractive())&&this._removeInlineDescription(),this._description=t,this._isHostInteractive()?this._ariaDescriber.describe(this._elementRef.nativeElement,t):this._updateInlineDescription()}_updateInlineDescription(){this._inlineBadgeDescription||(this._inlineBadgeDescription=this._document.createElement(`span`),this._inlineBadgeDescription.classList.add(`cdk-visually-hidden`)),this._inlineBadgeDescription.textContent=this.description,this._badgeElement?.appendChild(this._inlineBadgeDescription)}_removeInlineDescription(){this._inlineBadgeDescription?.remove(),this._inlineBadgeDescription=void 0}_setColor(t){let e=this._elementRef.nativeElement.classList;e.remove(`mat-badge-${this._color}`),t&&e.add(`mat-badge-${t}`)}_clearExistingBadges(){let t=this._elementRef.nativeElement.querySelectorAll(`:scope > .${Fn}`);for(let e of Array.from(t))e!==this._badgeElement&&e.remove()}static ɵfac=function(e){return new(e||i)};static ɵdir=Mo({type:i,selectors:[[``,`matBadge`,``]],hostAttrs:[1,`mat-badge`],hostVars:20,hostBindings:function(e,n){e&2&&Rs(`mat-badge-overlap`,n.overlap)(`mat-badge-above`,n.isAbove())(`mat-badge-below`,!n.isAbove())(`mat-badge-before`,!n.isAfter())(`mat-badge-after`,n.isAfter())(`mat-badge-small`,n.size===`small`)(`mat-badge-medium`,n.size===`medium`)(`mat-badge-large`,n.size===`large`)(`mat-badge-hidden`,n.hidden||!n.content)(`mat-badge-disabled`,n.disabled)},inputs:{color:[0,`matBadgeColor`,`color`],overlap:[2,`matBadgeOverlap`,`overlap`,_u],disabled:[2,`matBadgeDisabled`,`disabled`,_u],position:[0,`matBadgePosition`,`position`],content:[0,`matBadge`,`content`],description:[0,`matBadgeDescription`,`description`],size:[0,`matBadgeSize`,`size`],hidden:[2,`matBadgeHidden`,`hidden`,_u]}})}return i})();var Vn=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[st,hy]})}return i})();var mi={capture:!0};var li=[`focus`,`mousedown`,`mouseenter`,`touchstart`];var re=`mat-ripple-loader-uninitialized`;var se=`mat-ripple-loader-class-name`;var Hn=`mat-ripple-loader-centered`;var Ut=`mat-ripple-loader-disabled`;var Gn=(()=>{class i{_document=g(L);_animationsDisabled=Xr();_globalRippleOptions=g(K$1,{optional:!0});_platform=g(nr);_ngZone=g(le$1);_injector=g(ne);_eventCleanups;_hosts=/* @__PURE__ */ new Map;constructor(){let t=g(bn).createRenderer(null,null);this._eventCleanups=this._ngZone.runOutsideAngular(()=>li.map(e=>t.listen(this._document,e,this._onInteraction,mi)))}ngOnDestroy(){let t=this._hosts.keys();for(let e of t)this.destroyRipple(e);this._eventCleanups.forEach(e=>e())}configureRipple(t,e){t.setAttribute(re,this._globalRippleOptions?.namespace??``),(e.className||!t.hasAttribute(se))&&t.setAttribute(se,e.className||``),e.centered&&t.setAttribute(Hn,``),e.disabled&&t.setAttribute(Ut,``)}setDisabled(t,e){let n=this._hosts.get(t);n?(n.target.rippleDisabled=e,!e&&!n.hasSetUpEvents&&(n.hasSetUpEvents=!0,n.renderer.setupTriggerEvents(t))):e?t.setAttribute(Ut,``):t.removeAttribute(Ut)}_onInteraction=t=>{let e=g$1(t);if(e instanceof HTMLElement){let n=e.closest(`[${re}="${this._globalRippleOptions?.namespace??``}"]`);n&&this._createRipple(n)}};_createRipple(t){if(!this._document||this._hosts.has(t))return;t.querySelector(`.mat-ripple`)?.remove();let e=this._document.createElement(`span`);e.classList.add(`mat-ripple`,t.getAttribute(se)),t.append(e);let n=this._globalRippleOptions,o=this._animationsDisabled?0:n?.animation?.enterDuration??H.enterDuration,a=this._animationsDisabled?0:n?.animation?.exitDuration??H.exitDuration,m={rippleDisabled:this._animationsDisabled||n?.disabled||t.hasAttribute(Ut),rippleConfig:{centered:t.hasAttribute(Hn),terminateOnPointerUp:n?.terminateOnPointerUp,animation:{enterDuration:o,exitDuration:a}}},d=new y(m,this._ngZone,e,this._platform,this._injector),f=!m.rippleDisabled;f&&d.setupTriggerEvents(t),this._hosts.set(t,{target:m,renderer:d,hasSetUpEvents:f}),t.removeAttribute(re)}destroyRipple(t){let e=this._hosts.get(t);e&&(e.renderer._removeTriggerEvents(),this._hosts.delete(t))}static ɵfac=function(e){return new(e||i)};static ɵprov=ge$1({token:i,factory:i.ɵfac})}return i})();var ci=new v(`MAT_BUTTON_CONFIG`);function Qn(i){return i==null?void 0:Ob(i)}var me=(()=>{class i{_elementRef=g(nt);_ngZone=g(le$1);_animationsDisabled=Xr();_config=g(ci,{optional:!0});_focusMonitor=g(He);_cleanupClick;_renderer=g(hr);_rippleLoader=g(Gn);_isAnchor;_isFab=!1;color;get disableRipple(){return this._disableRipple}set disableRipple(t){this._disableRipple=t,this._updateRippleDisabled()}_disableRipple=!1;get disabled(){return this._disabled}set disabled(t){this._disabled=t,this._updateRippleDisabled()}_disabled=!1;ariaDisabled;disabledInteractive;tabIndex;set _tabindex(t){this.tabIndex=t}showProgress=pV(!1,{transform:_u});constructor(){g(QT).load(ct);let t=this._elementRef.nativeElement;this._isAnchor=t.tagName===`A`,this.disabledInteractive=this._config?.disabledInteractive??!1,this.color=this._config?.color??null,this._rippleLoader?.configureRipple(t,{className:`mat-mdc-button-ripple`})}ngAfterViewInit(){this._focusMonitor.monitor(this._elementRef,!0),this._isAnchor&&this._setupAsAnchor()}ngOnDestroy(){this._cleanupClick?.(),this._focusMonitor.stopMonitoring(this._elementRef),this._rippleLoader?.destroyRipple(this._elementRef.nativeElement)}focus(t=`program`,e){t?this._focusMonitor.focusVia(this._elementRef.nativeElement,t,e):this._elementRef.nativeElement.focus(e)}_getAriaDisabled(){return this.ariaDisabled!=null?this.ariaDisabled:this._isAnchor?this.disabled||null:this.disabled&&this.disabledInteractive?!0:null}_getDisabledAttribute(){return this.disabledInteractive||!this.disabled?null:!0}_updateRippleDisabled(){this._rippleLoader?.setDisabled(this._elementRef.nativeElement,this.disableRipple||this.disabled)}_getTabIndex(){return this._isAnchor?this.disabled&&!this.disabledInteractive?-1:this.tabIndex:this.tabIndex}_setupAsAnchor(){this._cleanupClick=this._ngZone.runOutsideAngular(()=>this._renderer.listen(this._elementRef.nativeElement,`click`,t=>{this.disabled&&(t.preventDefault(),t.stopImmediatePropagation())}))}static ɵfac=function(e){return new(e||i)};static ɵdir=Mo({type:i,hostAttrs:[1,`mat-mdc-button-base`],hostVars:15,hostBindings:function(e,n){e&2&&(No(`disabled`,n._getDisabledAttribute())(`aria-disabled`,n._getAriaDisabled())(`tabindex`,n._getTabIndex()),Eu(n.color?`mat-`+n.color:``),Rs(`mat-mdc-button-progress-indicator-shown`,n.showProgress())(`mat-mdc-button-disabled`,n.disabled)(`mat-mdc-button-disabled-interactive`,n.disabledInteractive)(`mat-unthemed`,!n.color)(`_mat-animation-noopable`,n._animationsDisabled))},inputs:{color:`color`,disableRipple:[2,`disableRipple`,`disableRipple`,_u],disabled:[2,`disabled`,`disabled`,_u],ariaDisabled:[2,`aria-disabled`,`ariaDisabled`,_u],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,_u],tabIndex:[2,`tabIndex`,`tabIndex`,Qn],_tabindex:[2,`tabindex`,`_tabindex`,Qn],showProgress:[1,`showProgress`]}})}return i})();var le=(()=>{class i extends me{constructor(){super(),this._rippleLoader.configureRipple(this._elementRef.nativeElement,{centered:!0})}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[`*`,[[``,`progressIndicator`,``]]],e=[`*`,`[progressIndicator]`];function n(o,a){o&1&&(gu(0,`div`,1),Du(1,1),mu())}return So({type:i,selectors:[[`button`,`mat-icon-button`,``],[`a`,`mat-icon-button`,``],[`button`,`matIconButton`,``],[`a`,`matIconButton`,``]],hostAttrs:[1,`mdc-icon-button`,`mat-mdc-icon-button`],exportAs:[`matButton`,`matAnchor`],features:[Tg],ngContentSelectors:e,decls:5,vars:1,consts:[[1,`mat-mdc-button-persistent-ripple`,`mdc-icon-button__ripple`],[1,`mat-mdc-button-progress-indicator-container`],[1,`mat-focus-indicator`],[1,`mat-mdc-button-touch-target`]],template:function(a,m){a&1&&(vu(t),Og(0,`span`,0),Du(1),Kw(2,n,2,0,`div`,1),Og(3,`span`,2)(4,`span`,3)),a&2&&(QE(2),Jw(m.showProgress()?2:-1))},styles:[`.mat-mdc-icon-button {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  position: relative;
  box-sizing: border-box;
  border: none;
  outline: none;
  background-color: transparent;
  fill: currentColor;
  text-decoration: none;
  cursor: pointer;
  z-index: 0;
  overflow: visible;
  border-radius: var(--%NS%mat-icon-button-container-shape, var(--%NS%mat-sys-corner-full, 50%));
  flex-shrink: 0;
  text-align: center;
  width: var(--%NS%mat-icon-button-state-layer-size, 40px);
  height: var(--%NS%mat-icon-button-state-layer-size, 40px);
  padding: calc(calc(var(--%NS%mat-icon-button-state-layer-size, 40px) - var(--%NS%mat-icon-button-icon-size, 24px)) / 2);
  font-size: var(--%NS%mat-icon-button-icon-size, 24px);
  color: var(--%NS%mat-icon-button-icon-color, var(--%NS%mat-sys-on-surface-variant));
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-icon-button .mat-mdc-button-ripple,
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple,
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: inherit;
}
.mat-mdc-icon-button .mat-mdc-button-ripple {
  overflow: hidden;
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  content: "";
  opacity: 0;
}
.mat-mdc-icon-button .mdc-button__label,
.mat-mdc-icon-button .mat-icon {
  z-index: 1;
  position: relative;
}
.mat-mdc-icon-button .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
}
.mat-mdc-icon-button:focus-visible > .mat-focus-indicator::before {
  content: "";
  border-radius: inherit;
}
.mat-mdc-icon-button .mat-ripple-element {
  background-color: var(--%NS%mat-icon-button-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface-variant) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-icon-button-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-icon-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-icon-button-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-icon-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-icon-button-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-mdc-icon-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-icon-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-icon-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-icon-button-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-mdc-icon-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-icon-button-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-icon-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-icon-button-touch-target-size, 48px);
  display: var(--%NS%mat-icon-button-touch-target-display, block);
  left: 50%;
  width: var(--%NS%mat-icon-button-touch-target-size, 48px);
  transform: translate(-50%, -50%);
}
.mat-mdc-icon-button._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-icon-button[disabled], .mat-mdc-icon-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-icon-button-disabled-icon-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-icon-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-icon-button img,
.mat-mdc-icon-button svg {
  width: var(--%NS%mat-icon-button-icon-size, 24px);
  height: var(--%NS%mat-icon-button-icon-size, 24px);
  vertical-align: baseline;
}
.mat-mdc-icon-button .mat-mdc-button-progress-indicator-container .mdc-circular-progress__determinate-circle-graphic {
  width: inherit;
  height: inherit;
}
.mat-mdc-icon-button .mat-mdc-button-progress-indicator-container .mdc-circular-progress__indeterminate-circle-graphic {
  height: 100%;
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple {
  border-radius: var(--%NS%mat-icon-button-container-shape, var(--%NS%mat-sys-corner-full, 50%));
}
.mat-mdc-icon-button[hidden] {
  display: none;
}
.mat-mdc-icon-button.mat-unthemed:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-primary:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-accent:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-warn:not(.mdc-ripple-upgraded):focus::before {
  background: transparent;
  opacity: 1;
}

.mat-mdc-button-progress-indicator-container {
  position: absolute;
  inset-inline-start: 0;
  inset-block-start: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
}

.mat-mdc-button-progress-indicator-shown mat-icon {
  visibility: hidden;
}
`,`@media (forced-colors: active) {
  .mat-mdc-button:not(.mdc-button--outlined),
  .mat-mdc-unelevated-button:not(.mdc-button--outlined),
  .mat-mdc-raised-button:not(.mdc-button--outlined),
  .mat-mdc-outlined-button:not(.mdc-button--outlined),
  .mat-mdc-button-base.mat-tonal-button,
  .mat-mdc-icon-button.mat-mdc-icon-button,
  .mat-mdc-outlined-button .mdc-button__ripple {
    outline: solid 1px;
  }
}
`],encapsulation:2})})()}return i})();var Un=/* @__PURE__ */ new Map([[`text`,[`mat-mdc-button`]],[`filled`,[`mdc-button--unelevated`,`mat-mdc-unelevated-button`]],[`elevated`,[`mdc-button--raised`,`mat-mdc-raised-button`]],[`outlined`,[`mdc-button--outlined`,`mat-mdc-outlined-button`]],[`tonal`,[`mat-tonal-button`]]]);var Wn=(()=>{class i extends me{get appearance(){return this._appearance}set appearance(t){this.setAppearance(t||this._config?.defaultAppearance||`text`)}_appearance=null;constructor(){super();let t=di(this._elementRef.nativeElement);t&&this.setAppearance(t)}setAppearance(t){if(t===this._appearance)return;let e=this._elementRef.nativeElement.classList,n=this._appearance?Un.get(this._appearance):null,o=Un.get(t);n&&e.remove(...n),e.add(...o),this._appearance=t}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[[[``,8,`material-icons`,3,`iconPositionEnd`,``],[`mat-icon`,3,`iconPositionEnd`,``],[``,`matButtonIcon`,``,3,`iconPositionEnd`,``],[``,8,`material-symbols-outlined`,3,`iconPositionEnd`,``],[``,8,`material-symbols-rounded`,3,`iconPositionEnd`,``],[``,8,`material-symbols-sharp`,3,`iconPositionEnd`,``]],`*`,[[``,`iconPositionEnd`,``,8,`material-icons`],[`mat-icon`,`iconPositionEnd`,``],[``,`matButtonIcon`,``,`iconPositionEnd`,``],[``,`iconPositionEnd`,``,8,`material-symbols-outlined`],[``,`iconPositionEnd`,``,8,`material-symbols-rounded`],[``,`iconPositionEnd`,``,8,`material-symbols-sharp`]],[[``,`progressIndicator`,``]]],e=[`.material-icons:not([iconPositionEnd]), mat-icon:not([iconPositionEnd]), [matButtonIcon]:not([iconPositionEnd]), .material-symbols-outlined:not([iconPositionEnd]), .material-symbols-rounded:not([iconPositionEnd]), .material-symbols-sharp:not([iconPositionEnd])`,`*`,`.material-icons[iconPositionEnd], mat-icon[iconPositionEnd], [matButtonIcon][iconPositionEnd], .material-symbols-outlined[iconPositionEnd], .material-symbols-rounded[iconPositionEnd], .material-symbols-sharp[iconPositionEnd]`,`[progressIndicator]`];function n(o,a){o&1&&(gu(0,`div`,2),Du(1,3),mu())}return So({type:i,selectors:[[`button`,`matButton`,``],[`a`,`matButton`,``],[`button`,`mat-button`,``],[`button`,`mat-raised-button`,``],[`button`,`mat-flat-button`,``],[`button`,`mat-stroked-button`,``],[`a`,`mat-button`,``],[`a`,`mat-raised-button`,``],[`a`,`mat-flat-button`,``],[`a`,`mat-stroked-button`,``]],hostAttrs:[1,`mdc-button`],inputs:{appearance:[0,`matButton`,`appearance`]},exportAs:[`matButton`,`matAnchor`],features:[Tg],ngContentSelectors:e,decls:8,vars:5,consts:[[1,`mat-mdc-button-persistent-ripple`],[1,`mdc-button__label`],[1,`mat-mdc-button-progress-indicator-container`],[1,`mat-focus-indicator`],[1,`mat-mdc-button-touch-target`]],template:function(a,m){a&1&&(vu(t),Og(0,`span`,0),Du(1),gu(2,`span`,1),Du(3,1),mu(),Du(4,2),Kw(5,n,2,0,`div`,2),Og(6,`span`,3)(7,`span`,4)),a&2&&(Rs(`mdc-button__ripple`,!m._isFab)(`mdc-fab__ripple`,m._isFab),QE(5),Jw(m.showProgress()?5:-1))},styles:[`.mat-mdc-button-base {
  text-decoration: none;
}
.mat-mdc-button-base .mat-icon {
  min-height: fit-content;
  flex-shrink: 0;
}
@media (hover: none) {
  .mat-mdc-button-base:hover > span.mat-mdc-button-persistent-ripple::before {
    opacity: 0;
  }
}

.mdc-button {
  -webkit-user-select: none;
  user-select: none;
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  min-width: 64px;
  border: none;
  outline: none;
  line-height: inherit;
  -webkit-appearance: none;
  overflow: visible;
  vertical-align: middle;
  background: transparent;
  padding: 0 8px;
}
.mdc-button::-moz-focus-inner {
  padding: 0;
  border: 0;
}
.mdc-button:active {
  outline: none;
}
.mdc-button:hover {
  cursor: pointer;
}
.mdc-button:disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-button[hidden] {
  display: none;
}
.mdc-button .mdc-button__label {
  position: relative;
}

.mat-mdc-button {
  padding: 0 var(--%NS%mat-button-text-horizontal-padding, 12px);
  height: var(--%NS%mat-button-text-container-height, 40px);
  font-family: var(--%NS%mat-button-text-label-text-font, var(--%NS%mat-sys-label-large-font));
  font-size: var(--%NS%mat-button-text-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-button-text-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  text-transform: var(--%NS%mat-button-text-label-text-transform);
  font-weight: var(--%NS%mat-button-text-label-text-weight, var(--%NS%mat-sys-label-large-weight));
}
.mat-mdc-button, .mat-mdc-button .mdc-button__ripple {
  border-radius: var(--%NS%mat-button-text-container-shape, var(--%NS%mat-sys-corner-full));
}
.mat-mdc-button:not(:disabled) {
  color: var(--%NS%mat-button-text-label-text-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-button[disabled], .mat-mdc-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-button-text-disabled-label-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-button:has(.material-icons, .material-symbols-outlined, .material-symbols-rounded,
.material-symbols-sharp, mat-icon, [matButtonIcon]) {
  padding: 0 var(--%NS%mat-button-text-with-icon-horizontal-padding, 16px);
}
.mat-mdc-button > .mat-icon {
  margin-right: var(--%NS%mat-button-text-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-text-icon-offset, -4px);
}
[dir=rtl] .mat-mdc-button > .mat-icon {
  margin-right: var(--%NS%mat-button-text-icon-offset, -4px);
  margin-left: var(--%NS%mat-button-text-icon-spacing, 8px);
}
.mat-mdc-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-text-icon-offset, -4px);
  margin-left: var(--%NS%mat-button-text-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-text-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-text-icon-offset, -4px);
}
.mat-mdc-button .mat-ripple-element {
  background-color: var(--%NS%mat-button-text-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-primary) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-text-state-layer-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-text-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-text-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-mdc-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-text-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-mdc-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-text-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-button-text-touch-target-size, 48px);
  display: var(--%NS%mat-button-text-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}

.mat-mdc-unelevated-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--%NS%mat-button-filled-container-height, 40px);
  font-family: var(--%NS%mat-button-filled-label-text-font, var(--%NS%mat-sys-label-large-font));
  font-size: var(--%NS%mat-button-filled-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-button-filled-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  text-transform: var(--%NS%mat-button-filled-label-text-transform);
  font-weight: var(--%NS%mat-button-filled-label-text-weight, var(--%NS%mat-sys-label-large-weight));
  padding: 0 var(--%NS%mat-button-filled-horizontal-padding, 24px);
}
.mat-mdc-unelevated-button > .mat-icon {
  margin-right: var(--%NS%mat-button-filled-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-filled-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-unelevated-button > .mat-icon {
  margin-right: var(--%NS%mat-button-filled-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-filled-icon-spacing, 8px);
}
.mat-mdc-unelevated-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-filled-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-filled-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-unelevated-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-filled-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-filled-icon-offset, -8px);
}
.mat-mdc-unelevated-button .mat-ripple-element {
  background-color: var(--%NS%mat-button-filled-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-on-primary) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-filled-state-layer-color, var(--%NS%mat-sys-on-primary));
}
.mat-mdc-unelevated-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-filled-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-unelevated-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-filled-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-mdc-unelevated-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-unelevated-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-unelevated-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-filled-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-mdc-unelevated-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-filled-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-unelevated-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-button-filled-touch-target-size, 48px);
  display: var(--%NS%mat-button-filled-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-unelevated-button:not(:disabled) {
  color: var(--%NS%mat-button-filled-label-text-color, var(--%NS%mat-sys-on-primary));
  background-color: var(--%NS%mat-button-filled-container-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-unelevated-button, .mat-mdc-unelevated-button .mdc-button__ripple {
  border-radius: var(--%NS%mat-button-filled-container-shape, var(--%NS%mat-sys-corner-full));
}
.mat-mdc-unelevated-button .mat-mdc-button-progress-indicator-container {
  --%NS%mat-progress-spinner-active-indicator-color: var(--%NS%mat-button-filled-progress-active-indicator-color, var(--%NS%mat-sys-on-primary));
}
.mat-mdc-unelevated-button[disabled], .mat-mdc-unelevated-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-button-filled-disabled-label-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
  background-color: var(--%NS%mat-button-filled-disabled-container-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-unelevated-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-mdc-raised-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: var(--%NS%mat-button-protected-container-elevation-shadow, var(--%NS%mat-sys-level1));
  height: var(--%NS%mat-button-protected-container-height, 40px);
  font-family: var(--%NS%mat-button-protected-label-text-font, var(--%NS%mat-sys-label-large-font));
  font-size: var(--%NS%mat-button-protected-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-button-protected-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  text-transform: var(--%NS%mat-button-protected-label-text-transform);
  font-weight: var(--%NS%mat-button-protected-label-text-weight, var(--%NS%mat-sys-label-large-weight));
  padding: 0 var(--%NS%mat-button-protected-horizontal-padding, 24px);
}
.mat-mdc-raised-button > .mat-icon {
  margin-right: var(--%NS%mat-button-protected-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-protected-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-raised-button > .mat-icon {
  margin-right: var(--%NS%mat-button-protected-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-protected-icon-spacing, 8px);
}
.mat-mdc-raised-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-protected-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-protected-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-raised-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-protected-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-protected-icon-offset, -8px);
}
.mat-mdc-raised-button .mat-ripple-element {
  background-color: var(--%NS%mat-button-protected-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-primary) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-protected-state-layer-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-raised-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-protected-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-raised-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-protected-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-mdc-raised-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-raised-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-raised-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-protected-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-mdc-raised-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-protected-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-raised-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-button-protected-touch-target-size, 48px);
  display: var(--%NS%mat-button-protected-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-raised-button:not(:disabled) {
  color: var(--%NS%mat-button-protected-label-text-color, var(--%NS%mat-sys-primary));
  background-color: var(--%NS%mat-button-protected-container-color, var(--%NS%mat-sys-surface));
}
.mat-mdc-raised-button, .mat-mdc-raised-button .mdc-button__ripple {
  border-radius: var(--%NS%mat-button-protected-container-shape, var(--%NS%mat-sys-corner-full));
}
@media (hover: hover) {
  .mat-mdc-raised-button:hover {
    box-shadow: var(--%NS%mat-button-protected-hover-container-elevation-shadow, var(--%NS%mat-sys-level2));
  }
}
.mat-mdc-raised-button:focus {
  box-shadow: var(--%NS%mat-button-protected-focus-container-elevation-shadow, var(--%NS%mat-sys-level1));
}
.mat-mdc-raised-button:active, .mat-mdc-raised-button:focus:active {
  box-shadow: var(--%NS%mat-button-protected-pressed-container-elevation-shadow, var(--%NS%mat-sys-level1));
}
.mat-mdc-raised-button[disabled], .mat-mdc-raised-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-button-protected-disabled-label-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
  background-color: var(--%NS%mat-button-protected-disabled-container-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-raised-button[disabled].mat-mdc-button-disabled, .mat-mdc-raised-button.mat-mdc-button-disabled.mat-mdc-button-disabled {
  box-shadow: var(--%NS%mat-button-protected-disabled-container-elevation-shadow, var(--%NS%mat-sys-level0));
}
.mat-mdc-raised-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-mdc-outlined-button {
  border-style: solid;
  transition: border 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--%NS%mat-button-outlined-container-height, 40px);
  font-family: var(--%NS%mat-button-outlined-label-text-font, var(--%NS%mat-sys-label-large-font));
  font-size: var(--%NS%mat-button-outlined-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-button-outlined-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  text-transform: var(--%NS%mat-button-outlined-label-text-transform);
  font-weight: var(--%NS%mat-button-outlined-label-text-weight, var(--%NS%mat-sys-label-large-weight));
  border-radius: var(--%NS%mat-button-outlined-container-shape, var(--%NS%mat-sys-corner-full));
  border-width: var(--%NS%mat-button-outlined-outline-width, 1px);
  padding: 0 var(--%NS%mat-button-outlined-horizontal-padding, 24px);
}
.mat-mdc-outlined-button > .mat-icon {
  margin-right: var(--%NS%mat-button-outlined-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-outlined-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-outlined-button > .mat-icon {
  margin-right: var(--%NS%mat-button-outlined-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-outlined-icon-spacing, 8px);
}
.mat-mdc-outlined-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-outlined-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-outlined-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-outlined-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-outlined-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-outlined-icon-offset, -8px);
}
.mat-mdc-outlined-button .mat-ripple-element {
  background-color: var(--%NS%mat-button-outlined-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-primary) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-outlined-state-layer-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-outlined-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-outlined-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-outlined-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-outlined-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-mdc-outlined-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-outlined-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-outlined-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-outlined-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-mdc-outlined-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-outlined-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-outlined-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-button-outlined-touch-target-size, 48px);
  display: var(--%NS%mat-button-outlined-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-outlined-button:not(:disabled) {
  color: var(--%NS%mat-button-outlined-label-text-color, var(--%NS%mat-sys-primary));
  border-color: var(--%NS%mat-button-outlined-outline-color, var(--%NS%mat-sys-outline));
}
.mat-mdc-outlined-button[disabled], .mat-mdc-outlined-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-button-outlined-disabled-label-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
  border-color: var(--%NS%mat-button-outlined-disabled-outline-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-outlined-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-tonal-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--%NS%mat-button-tonal-container-height, 40px);
  font-family: var(--%NS%mat-button-tonal-label-text-font, var(--%NS%mat-sys-label-large-font));
  font-size: var(--%NS%mat-button-tonal-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-button-tonal-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  text-transform: var(--%NS%mat-button-tonal-label-text-transform);
  font-weight: var(--%NS%mat-button-tonal-label-text-weight, var(--%NS%mat-sys-label-large-weight));
  padding: 0 var(--%NS%mat-button-tonal-horizontal-padding, 24px);
}
.mat-tonal-button:not(:disabled) {
  color: var(--%NS%mat-button-tonal-label-text-color, var(--%NS%mat-sys-on-secondary-container));
  background-color: var(--%NS%mat-button-tonal-container-color, var(--%NS%mat-sys-secondary-container));
}
.mat-tonal-button, .mat-tonal-button .mdc-button__ripple {
  border-radius: var(--%NS%mat-button-tonal-container-shape, var(--%NS%mat-sys-corner-full));
}
.mat-tonal-button[disabled], .mat-tonal-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--%NS%mat-button-tonal-disabled-label-text-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
  background-color: var(--%NS%mat-button-tonal-disabled-container-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 12%, transparent));
}
.mat-tonal-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-tonal-button > .mat-icon {
  margin-right: var(--%NS%mat-button-tonal-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-tonal-icon-offset, -8px);
}
[dir=rtl] .mat-tonal-button > .mat-icon {
  margin-right: var(--%NS%mat-button-tonal-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-tonal-icon-spacing, 8px);
}
.mat-tonal-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-tonal-icon-offset, -8px);
  margin-left: var(--%NS%mat-button-tonal-icon-spacing, 8px);
}
[dir=rtl] .mat-tonal-button .mdc-button__label + .mat-icon {
  margin-right: var(--%NS%mat-button-tonal-icon-spacing, 8px);
  margin-left: var(--%NS%mat-button-tonal-icon-offset, -8px);
}
.mat-tonal-button .mat-ripple-element {
  background-color: var(--%NS%mat-button-tonal-ripple-color, color-mix(in srgb, var(--%NS%mat-sys-on-secondary-container) calc(var(--%NS%mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-tonal-state-layer-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-tonal-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--%NS%mat-button-tonal-disabled-state-layer-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-tonal-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-tonal-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mat-tonal-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-tonal-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-tonal-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-tonal-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mat-tonal-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--%NS%mat-button-tonal-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
}
.mat-tonal-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--%NS%mat-button-tonal-touch-target-size, 48px);
  display: var(--%NS%mat-button-tonal-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}

.mat-mdc-button,
.mat-mdc-unelevated-button,
.mat-mdc-raised-button,
.mat-mdc-outlined-button,
.mat-tonal-button {
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-button .mat-mdc-button-ripple,
.mat-mdc-button .mat-mdc-button-persistent-ripple,
.mat-mdc-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-unelevated-button .mat-mdc-button-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-raised-button .mat-mdc-button-ripple,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before,
.mat-tonal-button .mat-mdc-button-ripple,
.mat-tonal-button .mat-mdc-button-persistent-ripple,
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: inherit;
}
.mat-mdc-button .mat-mdc-button-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-ripple,
.mat-mdc-raised-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-tonal-button .mat-mdc-button-ripple {
  overflow: hidden;
}
.mat-mdc-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before,
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  content: "";
  opacity: 0;
}
.mat-mdc-button .mdc-button__label,
.mat-mdc-button .mat-icon,
.mat-mdc-unelevated-button .mdc-button__label,
.mat-mdc-unelevated-button .mat-icon,
.mat-mdc-raised-button .mdc-button__label,
.mat-mdc-raised-button .mat-icon,
.mat-mdc-outlined-button .mdc-button__label,
.mat-mdc-outlined-button .mat-icon,
.mat-tonal-button .mdc-button__label,
.mat-tonal-button .mat-icon {
  z-index: 1;
  position: relative;
}
.mat-mdc-button .mat-focus-indicator,
.mat-mdc-unelevated-button .mat-focus-indicator,
.mat-mdc-raised-button .mat-focus-indicator,
.mat-mdc-outlined-button .mat-focus-indicator,
.mat-tonal-button .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
}
.mat-mdc-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-unelevated-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-raised-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-outlined-button:focus-visible > .mat-focus-indicator::before,
.mat-tonal-button:focus-visible > .mat-focus-indicator::before {
  content: "";
  border-radius: inherit;
}
.mat-mdc-button._mat-animation-noopable,
.mat-mdc-unelevated-button._mat-animation-noopable,
.mat-mdc-raised-button._mat-animation-noopable,
.mat-mdc-outlined-button._mat-animation-noopable,
.mat-tonal-button._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-button > .mat-icon,
.mat-mdc-unelevated-button > .mat-icon,
.mat-mdc-raised-button > .mat-icon,
.mat-mdc-outlined-button > .mat-icon,
.mat-tonal-button > .mat-icon {
  display: inline-block;
  position: relative;
  vertical-align: top;
  font-size: 1.125rem;
  height: 1.125rem;
  width: 1.125rem;
}

.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mdc-button__ripple {
  top: -1px;
  left: -1px;
  bottom: -1px;
  right: -1px;
}

.mat-mdc-unelevated-button .mat-focus-indicator::before,
.mat-tonal-button .mat-focus-indicator::before,
.mat-mdc-raised-button .mat-focus-indicator::before {
  margin: calc(calc(var(--%NS%mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-mdc-outlined-button .mat-focus-indicator::before {
  margin: calc(calc(var(--%NS%mat-focus-indicator-border-width, 3px) + 3px) * -1);
}

.mat-mdc-button-progress-indicator-container {
  position: absolute;
  inset-inline-start: 0;
  inset-block-start: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
}

.mat-mdc-button-progress-indicator-shown mat-icon,
.mat-mdc-button-progress-indicator-shown [matButtonIcon],
.mat-mdc-button-progress-indicator-shown .mdc-button__label {
  visibility: hidden;
}
`,`@media (forced-colors: active) {
  .mat-mdc-button:not(.mdc-button--outlined),
  .mat-mdc-unelevated-button:not(.mdc-button--outlined),
  .mat-mdc-raised-button:not(.mdc-button--outlined),
  .mat-mdc-outlined-button:not(.mdc-button--outlined),
  .mat-mdc-button-base.mat-tonal-button,
  .mat-mdc-icon-button.mat-mdc-icon-button,
  .mat-mdc-outlined-button .mdc-button__ripple {
    outline: solid 1px;
  }
}
`],encapsulation:2})})()}return i})();function di(i){return i.hasAttribute(`mat-raised-button`)?`elevated`:i.hasAttribute(`mat-stroked-button`)?`outlined`:i.hasAttribute(`mat-flat-button`)?`filled`:i.hasAttribute(`mat-button`)?`text`:null}var Yn=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[x$1,hy]})}return i})();var qn=(()=>{class i{get vertical(){return this._vertical}set vertical(t){this._vertical=Vs(t)}_vertical=!1;get inset(){return this._inset}set inset(t){this._inset=Vs(t)}_inset=!1;static ɵfac=function(e){return new(e||i)};static ɵcmp=So({type:i,selectors:[[`mat-divider`]],hostAttrs:[`role`,`separator`,1,`mat-divider`],hostVars:7,hostBindings:function(e,n){e&2&&(No(`aria-orientation`,n.vertical?`vertical`:`horizontal`),Rs(`mat-divider-vertical`,n.vertical)(`mat-divider-horizontal`,!n.vertical)(`mat-divider-inset`,n.inset))},inputs:{vertical:`vertical`,inset:`inset`},decls:0,vars:0,template:function(e,n){},styles:[`.mat-divider {
  display: block;
  margin: 0;
  border-top-style: solid;
  border-top-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-top-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-vertical {
  border-top: 0;
  border-right-style: solid;
  border-right-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-right-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-inset {
  margin-left: 80px;
}
[dir=rtl] .mat-divider.mat-divider-inset {
  margin-left: auto;
  margin-right: 80px;
}
`],encapsulation:2})}return i})();var Wt=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[hy]})}return i})();var Xn=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[Ie,x$1,N,hy,Wt]})}return i})();var pe=new v(`MAT_MENU_PANEL`);var Ct=(()=>{class i{_isAnchor;_elementRef=g(nt);_document=g(L);_focusMonitor=g(He);_parentMenu=g(pe,{optional:!0});_changeDetectorRef=g(gm);role=`menuitem`;disabled=!1;disabledInteractive=!1;disableRipple=!1;_hovered=new te;_focused=new te;_highlighted=!1;_triggersSubmenu=!1;constructor(){g(QT).load(ct),this._parentMenu?.addItem?.(this),this._isAnchor=this._elementRef.nativeElement.tagName===`A`}focus(t,e){this._focusMonitor&&t?this._focusMonitor.focusVia(this._getHostElement(),t,e):this._getHostElement().focus(e),this._focused.next(this)}ngAfterViewInit(){this._focusMonitor&&this._focusMonitor.monitor(this._elementRef,!1)}ngOnDestroy(){this._focusMonitor&&this._focusMonitor.stopMonitoring(this._elementRef),this._parentMenu&&this._parentMenu.removeItem&&this._parentMenu.removeItem(this),this._hovered.complete(),this._focused.complete()}_getTabIndex(){return this.disabled&&!this.disabledInteractive?`-1`:`0`}_getAriaDisabled(){return this._isAnchor?this.disabled||null:this.disabled&&this.disabledInteractive?!0:null}_getDisabled(){return this.disabledInteractive||!this.disabled?null:!0}_getHostElement(){return this._elementRef.nativeElement}_checkDisabled(t){this.disabled&&(t.preventDefault(),t.stopPropagation())}_handleMouseEnter(){this._hovered.next(this)}getLabel(){let t=this._elementRef.nativeElement.cloneNode(!0),e=t.querySelectorAll(`mat-icon, .material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp`);for(let n=0;n<e.length;n++)e[n].remove();return t.textContent?.trim()||``}_setHighlighted(t){this._highlighted=t,this._changeDetectorRef.markForCheck()}_setTriggersSubmenu(t){this._triggersSubmenu=t,this._changeDetectorRef.markForCheck()}_hasFocus(){return this._document&&this._document.activeElement===this._getHostElement()}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[[[`mat-icon`],[``,`matMenuItemIcon`,``]],`*`],e=[`mat-icon, [matMenuItemIcon]`,`*`];function n(o,a){o&1&&(Af(),Es(0,`svg`,2),Rg(1,`polygon`,3),hu())}return So({type:i,selectors:[[``,`mat-menu-item`,``]],hostAttrs:[1,`mat-mdc-menu-item`,`mat-focus-indicator`],hostVars:12,hostBindings:function(a,m){a&1&&Pg(`click`,function(f){return m._checkDisabled(f)})(`mouseenter`,function(){return m._handleMouseEnter()}),a&2&&(No(`role`,m.role)(`tabindex`,m._getTabIndex())(`aria-disabled`,m._getAriaDisabled())(`disabled`,m._getDisabled()),Rs(`mat-mdc-menu-item-highlighted`,m._highlighted)(`mat-mdc-menu-item-submenu-trigger`,m._triggersSubmenu)(`mat-mdc-menu-item-disabled`,m.disabled)(`mat-mdc-menu-item-disabled-interactive`,m.disabledInteractive))},inputs:{role:`role`,disabled:[2,`disabled`,`disabled`,_u],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,_u],disableRipple:[2,`disableRipple`,`disableRipple`,_u]},exportAs:[`matMenuItem`],ngContentSelectors:e,decls:5,vars:3,consts:[[1,`mat-mdc-menu-item-text`],[`matRipple`,``,1,`mat-mdc-menu-ripple`,3,`matRippleDisabled`,`matRippleTrigger`],[`viewBox`,`0 0 5 10`,`focusable`,`false`,`aria-hidden`,`true`,1,`mat-mdc-menu-submenu-icon`],[`points`,`0,0 5,5 0,10`]],template:function(a,m){a&1&&(vu(t),Du(0),Es(1,`span`,0),Du(2,1),hu(),Rg(3,`div`,1),Kw(4,n,2,0,`svg`,2)),a&2&&(QE(3),xg(`matRippleDisabled`,m.disableRipple||m.disabled)(`matRippleTrigger`,m._getHostElement()),QE(),Jw(m._triggersSubmenu?4:-1))},dependencies:[lt],encapsulation:2})})()}return i})();var vi=new v(`MatMenuContent`);var _i=new v(`mat-menu-default-options`,{providedIn:`root`,factory:()=>({overlapTrigger:!1,xPosition:`after`,yPosition:`below`,backdropClass:`cdk-overlay-transparent-backdrop`})});var ce=`_mat-menu-enter`;var Yt=`_mat-menu-exit`;var _t=(()=>{class i{_elementRef=g(nt);_changeDetectorRef=g(gm);_injector=g(ne);_keyManager;_xPosition;_yPosition;_firstItemFocusRef;_exitFallbackTimeout;_animationsDisabled=Xr();_allItems;_directDescendantItems=new cs;_classList={};_panelAnimationState=`void`;_animationDone=new te;_isAnimating=or(!1);parentMenu;direction;overlayPanelClass;backdropClass;ariaLabel;ariaLabelledby;ariaDescribedby;get xPosition(){return this._xPosition}set xPosition(t){this._xPosition=t,this.setPositionClasses()}get yPosition(){return this._yPosition}set yPosition(t){this._yPosition=t,this.setPositionClasses()}templateRef;items;lazyContent;overlapTrigger=!1;hasBackdrop;get panelClass(){return this._previousPanelClass}set panelClass(t){let e=this._previousPanelClass,n=V({},this._classList);e&&e.length&&e.split(` `).forEach(o=>{n[o]=!1}),this._previousPanelClass=t,t&&t.length&&(t.split(` `).forEach(o=>{n[o]=!0}),this._elementRef.nativeElement.className=``),this._classList=n}_previousPanelClass=``;get classList(){return this.panelClass}set classList(t){this.panelClass=t}closed=new Pe;close=this.closed;panelId=g(z).getId(`mat-menu-panel-`);constructor(){let t=g(_i);this.overlayPanelClass=t.overlayPanelClass||``,this._xPosition=t.xPosition,this._yPosition=t.yPosition,this.backdropClass=t.backdropClass,this.overlapTrigger=t.overlapTrigger,this.hasBackdrop=t.hasBackdrop}ngOnInit(){this.setPositionClasses()}ngAfterContentInit(){this._updateDirectDescendants(),this._keyManager=new Y(this._directDescendantItems).withWrap().withTypeAhead().withHomeAndEnd().skipPredicate(t=>t.disabled&&!t.disabledInteractive),this._keyManager.tabOut.subscribe(()=>this.closed.emit(`tab`)),this._directDescendantItems.changes.pipe(ov(this._directDescendantItems),ma(t=>Yy(...t.map(e=>e._focused)))).subscribe(t=>this._keyManager.updateActiveItem(t)),this._directDescendantItems.changes.subscribe(t=>{let e=this._keyManager;if(this._panelAnimationState===`enter`&&e.activeItem?._hasFocus()){let n=t.toArray(),o=Math.max(0,Math.min(n.length-1,e.activeItemIndex||0));n[o]&&!n[o].disabled?e.setActiveItem(o):e.setNextItemActive()}})}ngOnDestroy(){this._keyManager?.destroy(),this._directDescendantItems.destroy(),this.closed.complete(),this._firstItemFocusRef?.destroy(),clearTimeout(this._exitFallbackTimeout)}_hovered(){return this._directDescendantItems.changes.pipe(ov(this._directDescendantItems),ma(e=>Yy(...e.map(n=>n._hovered))))}addItem(t){}removeItem(t){}_handleKeydown(t){let e=t.keyCode,n=this._keyManager;switch(e){case 27:Le(t)||(t.preventDefault(),this.closed.emit(`keydown`));break;case 37:this.parentMenu&&this.direction===`ltr`&&this.closed.emit(`keydown`);break;case 39:this.parentMenu&&this.direction===`rtl`&&this.closed.emit(`keydown`);break;default:(e===38||e===40)&&n.setFocusOrigin(`keyboard`),n.onKeydown(t);return}}focusFirstItem(t=`program`){this._firstItemFocusRef?.destroy(),this._firstItemFocusRef=AE(()=>{let e=this._resolvePanel();if(!e||!e.contains(document.activeElement)){let n=this._keyManager;n.setFocusOrigin(t).setFirstItemActive(),!n.activeItem&&e&&e.focus()}},{injector:this._injector})}resetActiveItem(){this._keyManager.setActiveItem(-1)}setElevation(t){}setPositionClasses(t=this.xPosition,e=this.yPosition){this._classList=G(V({},this._classList),{"mat-menu-before":t===`before`,"mat-menu-after":t===`after`,"mat-menu-above":e===`above`,"mat-menu-below":e===`below`}),this._changeDetectorRef.markForCheck()}_onAnimationDone(t){let e=t===Yt;(e||t===ce)&&(e&&(clearTimeout(this._exitFallbackTimeout),this._exitFallbackTimeout=void 0),this._animationDone.next(e?`void`:`enter`),this._isAnimating.set(!1))}_onAnimationStart(t){(t===ce||t===Yt)&&this._isAnimating.set(!0)}_setIsOpen(t){if(this._panelAnimationState=t?`enter`:`void`,t){if(this._keyManager.activeItemIndex===0){let e=this._resolvePanel();e&&(e.scrollTop=0)}}else this._animationsDisabled||(this._exitFallbackTimeout=setTimeout(()=>this._onAnimationDone(Yt),200));this._animationsDisabled&&setTimeout(()=>{this._onAnimationDone(t?ce:Yt)}),this._changeDetectorRef.markForCheck()}_updateDirectDescendants(){this._allItems.changes.pipe(ov(this._allItems)).subscribe(t=>{this._directDescendantItems.reset(t.filter(e=>e._parentMenu===this)),this._directDescendantItems.notifyOnChanges()})}_resolvePanel(){let t=null;return this._directDescendantItems.length&&(t=this._directDescendantItems.first._getHostElement().closest(`[role="menu"]`)),t}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[`*`];function e(n,o){if(n&1){let a=aC();gu(0,`div`,0),jg(`click`,function(){yf(a);let d=pC();return vf(d.closed.emit(`click`))})(`animationstart`,function(d){yf(a);let f=pC();return vf(f._onAnimationStart(d.animationName))})(`animationend`,function(d){yf(a);let f=pC();return vf(f._onAnimationDone(d.animationName))})(`animationcancel`,function(d){yf(a);let f=pC();return vf(f._onAnimationDone(d.animationName))}),gu(1,`div`,1),Du(2),mu()()}if(n&2){let a=pC();Eu(a._classList),Rs(`mat-menu-panel-animations-disabled`,a._animationsDisabled)(`mat-menu-panel-exit-animation`,a._panelAnimationState===`void`)(`mat-menu-panel-animating`,a._isAnimating()),Fg(`id`,a.panelId),No(`aria-label`,a.ariaLabel||null)(`aria-labelledby`,a.ariaLabelledby||null)(`aria-describedby`,a.ariaDescribedby||null)}}return So({type:i,selectors:[[`mat-menu`]],contentQueries:function(o,a,m){if(o&1&&Vg(m,vi,5)(m,Ct,5)(m,Ct,4),o&2){let d;mC(d=yC())&&(a.lazyContent=d.first),mC(d=yC())&&(a._allItems=d),mC(d=yC())&&(a.items=d)}},viewQuery:function(o,a){if(o&1&&Bg(pr,5),o&2){let m;mC(m=yC())&&(a.templateRef=m.first)}},hostVars:3,hostBindings:function(o,a){o&2&&No(`aria-label`,null)(`aria-labelledby`,null)(`aria-describedby`,null)},inputs:{backdropClass:`backdropClass`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],ariaDescribedby:[0,`aria-describedby`,`ariaDescribedby`],xPosition:`xPosition`,yPosition:`yPosition`,overlapTrigger:[2,`overlapTrigger`,`overlapTrigger`,_u],hasBackdrop:[2,`hasBackdrop`,`hasBackdrop`,n=>n==null?null:_u(n)],panelClass:[0,`class`,`panelClass`],classList:`classList`},outputs:{closed:`closed`,close:`close`},exportAs:[`matMenu`],features:[nm([{provide:pe,useExisting:i}])],ngContentSelectors:t,decls:1,vars:0,consts:[[`tabindex`,`-1`,`role`,`menu`,1,`mat-mdc-menu-panel`,3,`click`,`animationstart`,`animationend`,`animationcancel`,`id`],[1,`mat-mdc-menu-content`]],template:function(o,a){o&1&&(vu(),Mg(0,e,3,12,`ng-template`))},styles:[`mat-menu {
  display: none;
}

.mat-mdc-menu-content {
  margin: 0;
  padding: 8px 0;
  outline: 0;
}
.mat-mdc-menu-content,
.mat-mdc-menu-content .mat-mdc-menu-item .mat-mdc-menu-item-text {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  flex: 1;
  white-space: normal;
  font-family: var(--%NS%mat-menu-item-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-menu-item-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-menu-item-label-text-size, var(--%NS%mat-sys-label-large-size));
  letter-spacing: var(--%NS%mat-menu-item-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-menu-item-label-text-weight, var(--%NS%mat-sys-label-large-weight));
}

@keyframes _mat-menu-enter {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-menu-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-menu-panel {
  min-width: 112px;
  max-width: 280px;
  overflow: auto;
  box-sizing: border-box;
  outline: 0;
  animation: _mat-menu-enter 120ms cubic-bezier(0, 0, 0.2, 1);
  border-radius: var(--%NS%mat-menu-container-shape, var(--%NS%mat-sys-corner-extra-small));
  background-color: var(--%NS%mat-menu-container-color, var(--%NS%mat-sys-surface-container));
  box-shadow: var(--%NS%mat-menu-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
  will-change: transform, opacity;
}
.mat-mdc-menu-panel.mat-menu-panel-exit-animation {
  animation: _mat-menu-exit 100ms 25ms linear forwards;
}
.mat-mdc-menu-panel.mat-menu-panel-animations-disabled {
  animation: none;
}
.mat-mdc-menu-panel.mat-menu-panel-animating {
  pointer-events: none;
}
.mat-mdc-menu-panel.mat-menu-panel-animating:has(.mat-mdc-menu-content:empty) {
  display: none;
}
@media (forced-colors: active) {
  .mat-mdc-menu-panel {
    outline: solid 1px;
  }
}
.mat-mdc-menu-panel .mat-divider {
  border-top-color: var(--%NS%mat-menu-divider-color, var(--%NS%mat-sys-surface-variant));
  margin-bottom: var(--%NS%mat-menu-divider-bottom-spacing, 8px);
  margin-top: var(--%NS%mat-menu-divider-top-spacing, 8px);
}

.mat-mdc-menu-item {
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  padding: 0;
  cursor: pointer;
  width: 100%;
  text-align: left;
  box-sizing: border-box;
  color: inherit;
  font-size: inherit;
  background: none;
  text-decoration: none;
  margin: 0;
  min-height: 48px;
  padding-left: var(--%NS%mat-menu-item-leading-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-trailing-spacing, 12px);
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
  outline: none;
  border: none;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-menu-item::-moz-focus-inner {
  border: 0;
}
[dir=rtl] .mat-mdc-menu-item {
  padding-left: var(--%NS%mat-menu-item-trailing-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-leading-spacing, 12px);
}
.mat-mdc-menu-item:has(.material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp, mat-icon, [matButtonIcon]) {
  padding-left: var(--%NS%mat-menu-item-with-icon-leading-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-with-icon-trailing-spacing, 12px);
}
[dir=rtl] .mat-mdc-menu-item:has(.material-icons, .material-symbols-outlined, .material-symbols-rounded, .material-symbols-sharp, mat-icon, [matButtonIcon]) {
  padding-left: var(--%NS%mat-menu-item-with-icon-trailing-spacing, 12px);
  padding-right: var(--%NS%mat-menu-item-with-icon-leading-spacing, 12px);
}
.mat-mdc-menu-item, .mat-mdc-menu-item:visited, .mat-mdc-menu-item:link {
  color: var(--%NS%mat-menu-item-label-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-menu-item .mat-icon-no-color,
.mat-mdc-menu-item .mat-mdc-menu-submenu-icon {
  color: var(--%NS%mat-menu-item-icon-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-menu-item[disabled], .mat-mdc-menu-item.mat-mdc-menu-item-disabled {
  cursor: default;
  opacity: 0.38;
}
.mat-mdc-menu-item[disabled]::after, .mat-mdc-menu-item.mat-mdc-menu-item-disabled::after {
  display: block;
  position: absolute;
  content: "";
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.mat-mdc-menu-item:focus {
  outline: 0;
}
.mat-mdc-menu-item .mat-icon {
  flex-shrink: 0;
  margin-right: var(--%NS%mat-menu-item-spacing, 12px);
  height: var(--%NS%mat-menu-item-icon-size, 24px);
  width: var(--%NS%mat-menu-item-icon-size, 24px);
}
[dir=rtl] .mat-mdc-menu-item {
  text-align: right;
}
[dir=rtl] .mat-mdc-menu-item .mat-icon {
  margin-right: 0;
  margin-left: var(--%NS%mat-menu-item-spacing, 12px);
}
.mat-mdc-menu-item:not([disabled]):hover {
  background-color: var(--%NS%mat-menu-item-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-menu-item:not([disabled]).cdk-program-focused, .mat-mdc-menu-item:not([disabled]).cdk-keyboard-focused, .mat-mdc-menu-item:not([disabled]).mat-mdc-menu-item-highlighted {
  background-color: var(--%NS%mat-menu-item-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
}
@media (forced-colors: active) {
  .mat-mdc-menu-item {
    margin-top: 1px;
  }
}

.mat-mdc-menu-submenu-icon {
  width: var(--%NS%mat-menu-item-icon-size, 24px);
  height: 10px;
  fill: currentColor;
  padding-left: var(--%NS%mat-menu-item-spacing, 12px);
}
[dir=rtl] .mat-mdc-menu-submenu-icon {
  padding-right: var(--%NS%mat-menu-item-spacing, 12px);
  padding-left: 0;
}
[dir=rtl] .mat-mdc-menu-submenu-icon polygon {
  transform: scaleX(-1);
  transform-origin: center;
}
@media (forced-colors: active) {
  .mat-mdc-menu-submenu-icon {
    fill: CanvasText;
  }
}

.mat-mdc-menu-item .mat-mdc-menu-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
`],encapsulation:2})})()}return i})();var xi=new v(`mat-menu-scroll-strategy`,{providedIn:`root`,factory:()=>{let i=g(ne);return()=>le$2(i)}});var vt=/* @__PURE__ */ new WeakMap;var yi=(()=>{class i{_canHaveBackdrop;_element=g(nt);_viewContainerRef=g(Dr);_menuItemInstance=g(Ct,{optional:!0,self:!0});_dir=g(r_,{optional:!0});_focusMonitor=g(He);_ngZone=g(le$1);_injector=g(ne);_scrollStrategy=g(xi);_changeDetectorRef=g(gm);_animationsDisabled=Xr();_portal;_overlayRef=null;_menuOpen=!1;_closingActionsSubscription=J.EMPTY;_menuCloseSubscription=J.EMPTY;_pendingRemoval;_parentMaterialMenu;_parentInnerPadding;_openedBy=void 0;get _menu(){return this._menuInternal}set _menu(t){t!==this._menuInternal&&(this._menuInternal=t,this._menuCloseSubscription.unsubscribe(),t?(this._parentMaterialMenu,this._menuCloseSubscription=t.close.subscribe(e=>{this._destroyMenu(e),(e===`click`||e===`tab`)&&this._parentMaterialMenu&&this._parentMaterialMenu.closed.emit(e)})):this._destroyMenu(),this._menuItemInstance?._setTriggersSubmenu(this._triggersSubmenu()))}_menuInternal=null;constructor(t){this._canHaveBackdrop=t;let e=g(pe,{optional:!0});this._parentMaterialMenu=e instanceof _t?e:void 0}ngOnDestroy(){this._menu&&this._ownsMenu(this._menu)&&vt.delete(this._menu),this._pendingRemoval?.unsubscribe(),this._menuCloseSubscription.unsubscribe(),this._closingActionsSubscription.unsubscribe(),this._overlayRef&&(this._overlayRef.dispose(),this._overlayRef=null)}get menuOpen(){return this._menuOpen}get dir(){return this._dir&&this._dir.value===`rtl`?`rtl`:`ltr`}_triggersSubmenu(){return!!(this._menuItemInstance&&this._parentMaterialMenu&&this._menu)}_closeMenu(){this._menu?.close.emit()}_openMenu(t){if(this._triggerIsAriaDisabled())return;let e=this._menu;if(this._menuOpen||!e)return;this._pendingRemoval?.unsubscribe();let n=vt.get(e);vt.set(e,this),n&&n!==this&&n._closeMenu();let o=this._createOverlay(e),a=o.getConfig(),m=a.positionStrategy;this._setPosition(e,m),this._canHaveBackdrop?a.hasBackdrop=e.hasBackdrop==null?!this._triggersSubmenu():e.hasBackdrop:a.hasBackdrop=e.hasBackdrop??!1,o.hasAttached()||(o.attach(this._getPortal(e)),e.lazyContent?.attach(this.menuData)),this._closingActionsSubscription=this._menuClosingActions().subscribe(()=>this._closeMenu()),e.parentMenu=this._triggersSubmenu()?this._parentMaterialMenu:void 0,e.direction=this.dir,t&&e.focusFirstItem(this._openedBy||`program`),this._setIsMenuOpen(!0),e instanceof _t&&(e._setIsOpen(!0),e._directDescendantItems.changes.pipe(iv(e.close)).subscribe(()=>{m.withLockedPosition(!1).reapplyLastPosition(),m.withLockedPosition(!0)}))}focus(t,e){this._focusMonitor&&t?this._focusMonitor.focusVia(this._element,t,e):this._element.nativeElement.focus(e)}_destroyMenu(t){let e=this._overlayRef,n=this._menu;!e||!this.menuOpen||(this._closingActionsSubscription.unsubscribe(),this._pendingRemoval?.unsubscribe(),n instanceof _t&&this._ownsMenu(n)?(this._pendingRemoval=n._animationDone.pipe(kt(1)).subscribe(()=>{e.detach(),vt.has(n)||n.lazyContent?.detach()}),n._setIsOpen(!1)):(e.detach(),n?.lazyContent?.detach()),n&&this._ownsMenu(n)&&vt.delete(n),this.restoreFocus&&(t===`keydown`||!this._openedBy||!this._triggersSubmenu())&&this.focus(this._openedBy),this._openedBy=void 0,this._setIsMenuOpen(!1))}_setIsMenuOpen(t){t!==this._menuOpen&&(this._menuOpen=t,this._menuOpen?this.menuOpened.emit():this.menuClosed.emit(),this._triggersSubmenu()&&this._menuItemInstance._setHighlighted(t),this._changeDetectorRef.markForCheck())}_createOverlay(t){if(!this._overlayRef){let e=this._getOverlayConfig(t);this._subscribeToPositions(t,e.positionStrategy),this._overlayRef=ft(this._injector,e),this._overlayRef.keydownEvents().subscribe(n=>{this._menu instanceof _t&&this._menu._handleKeydown(n)})}return this._overlayRef}_getOverlayConfig(t){return new X({positionStrategy:de(this._injector,this._getOverlayOrigin()).withLockedPosition().withGrowAfterOpen().withTransformOriginOn(`.mat-menu-panel, .mat-mdc-menu-panel`),backdropClass:t.backdropClass||`cdk-overlay-transparent-backdrop`,panelClass:t.overlayPanelClass,scrollStrategy:this._scrollStrategy(),direction:this._dir||`ltr`,disableAnimations:this._animationsDisabled})}_subscribeToPositions(t,e){t.setPositionClasses&&e.positionChanges.subscribe(n=>{this._ngZone.run(()=>{let o=n.connectionPair.overlayX===`start`?`after`:`before`,a=n.connectionPair.overlayY===`top`?`below`:`above`;t.setPositionClasses(o,a)})})}_setPosition(t,e){let[n,o]=t.xPosition===`before`?[`end`,`start`]:[`start`,`end`],[a,m]=t.yPosition===`above`?[`bottom`,`top`]:[`top`,`bottom`],[d,f]=[a,m],[w,Zt]=[n,o],xt=0;if(this._triggersSubmenu()){if(Zt=n=t.xPosition===`before`?`start`:`end`,o=w=n===`end`?`start`:`end`,this._parentMaterialMenu){if(this._parentInnerPadding==null){let fe=this._parentMaterialMenu.items.first;this._parentInnerPadding=fe?fe._getHostElement().offsetTop:0}xt=a===`bottom`?this._parentInnerPadding:-this._parentInnerPadding}}else t.overlapTrigger||(d=a===`top`?`bottom`:`top`,f=m===`top`?`bottom`:`top`);e.withPositions([{originX:n,originY:d,overlayX:w,overlayY:a,offsetY:xt},{originX:o,originY:d,overlayX:Zt,overlayY:a,offsetY:xt},{originX:n,originY:f,overlayX:w,overlayY:m,offsetY:-xt},{originX:o,originY:f,overlayX:Zt,overlayY:m,offsetY:-xt}])}_menuClosingActions(){let t=this._getOutsideClickStream(this._overlayRef),e=this._overlayRef.detachments(),n=this._parentMaterialMenu?this._parentMaterialMenu.closed:ot(),o=this._parentMaterialMenu?this._parentMaterialMenu._hovered().pipe(Ot(a=>this._menuOpen&&a!==this._menuItemInstance)):ot();return Yy(t,n,o,e)}_getPortal(t){return(!this._portal||this._portal.templateRef!==t.templateRef)&&(this._portal=new j$1(t.templateRef,this._viewContainerRef)),this._portal}_ownsMenu(t){return vt.get(t)===this}_triggerIsAriaDisabled(){return _u(this._element.nativeElement.getAttribute(`aria-disabled`))}static ɵfac=function(e){ZI()};static ɵdir=Mo({type:i})}return i})();var Kn=(()=>{class i extends yi{_cleanupTouchstart;_hoverSubscription=J.EMPTY;get _deprecatedMatMenuTriggerFor(){return this.menu}set _deprecatedMatMenuTriggerFor(t){this.menu=t}get menu(){return this._menu}set menu(t){this._menu=t}menuData;restoreFocus=!0;menuOpened=new Pe;onMenuOpen=this.menuOpened;menuClosed=new Pe;onMenuClose=this.menuClosed;constructor(){super(!0);let t=g(hr);this._cleanupTouchstart=t.listen(this._element.nativeElement,`touchstart`,e=>{j(e)||(this._openedBy=`touch`)},{passive:!0})}triggersSubmenu(){return super._triggersSubmenu()}toggleMenu(){return this.menuOpen?this.closeMenu():this.openMenu()}openMenu(){this._openMenu(!0)}closeMenu(){this._closeMenu()}updatePosition(){this._overlayRef?.updatePosition()}ngAfterContentInit(){this._handleHover()}ngOnDestroy(){super.ngOnDestroy(),this._cleanupTouchstart(),this._hoverSubscription.unsubscribe()}_getOverlayOrigin(){return this._element}_getOutsideClickStream(t){return t.backdropClick()}_handleMousedown(t){V$1(t)||(this._openedBy=t.button===0?`mouse`:void 0,this.triggersSubmenu()&&t.preventDefault())}_handleKeydown(t){let e=t.keyCode;(e===13||e===32)&&(this._openedBy=`keyboard`),this.triggersSubmenu()&&(e===39&&this.dir===`ltr`||e===37&&this.dir===`rtl`)&&(this._openedBy=`keyboard`,this.openMenu())}_handleClick(t){this.triggersSubmenu()?(t.stopPropagation(),this.openMenu()):this.toggleMenu()}_handleHover(){this.triggersSubmenu()&&this._parentMaterialMenu&&(this._hoverSubscription=this._parentMaterialMenu._hovered().subscribe(t=>{t===this._menuItemInstance&&!t.disabled&&this._parentMaterialMenu?._panelAnimationState!==`void`&&(this._openedBy=`mouse`,this._openMenu(!1))}))}static ɵfac=function(e){return new(e||i)};static ɵdir=Mo({type:i,selectors:[[``,`mat-menu-trigger-for`,``],[``,`matMenuTriggerFor`,``]],hostAttrs:[1,`mat-mdc-menu-trigger`],hostVars:3,hostBindings:function(e,n){e&1&&Pg(`click`,function(a){return n._handleClick(a)})(`mousedown`,function(a){return n._handleMousedown(a)})(`keydown`,function(a){return n._handleKeydown(a)}),e&2&&No(`aria-haspopup`,n.menu?`menu`:null)(`aria-expanded`,n.menuOpen)(`aria-controls`,n.menuOpen?n.menu?.panelId:null)},inputs:{_deprecatedMatMenuTriggerFor:[0,`mat-menu-trigger-for`,`_deprecatedMatMenuTriggerFor`],menu:[0,`matMenuTriggerFor`,`menu`],menuData:[0,`matMenuTriggerData`,`menuData`],restoreFocus:[0,`matMenuTriggerRestoreFocus`,`restoreFocus`]},outputs:{menuOpened:`menuOpened`,onMenuOpen:`onMenuOpen`,menuClosed:`menuClosed`,onMenuClose:`onMenuClose`},exportAs:[`matMenuTrigger`],features:[Tg]})}return i})();var Jn=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[x$1,gt,hy,Jt]})}return i})();var ki=new v(`MAT_DRAWER_DEFAULT_AUTOSIZE`,{providedIn:`root`,factory:()=>!1});var he=new v(`MAT_DRAWER_CONTAINER`);var zt=(()=>{class i extends te$1{_platform=g(nr);_changeDetectorRef=g(gm);_element=g(nt);_ngZone=g(le$1);_isInert=!1;_container=g(ue);ngAfterContentInit(){this._container._contentMarginChanges.subscribe(()=>this._changeDetectorRef.markForCheck())}_drawerToggled(t){t.opened?this._ngZone.runOutsideAngular(()=>{t._animationEnd.pipe(Xy(50),kt(1)).subscribe(()=>this._updateInert())}):this._updateInert()}_drawerModeChanged(){this._updateInert()}_updateInert(){let t=this._container._isShowingBackdrop();if(t!==this._isInert){let e=this._element.nativeElement;this._isInert=t,t?e.setAttribute(`inert`,`true`):e.removeAttribute(`inert`)}}_shouldBeHidden(){if(this._platform.isBrowser)return!1;let{start:t,end:e}=this._container;return t!=null&&t.mode!==`over`&&t.opened||e!=null&&e.mode!==`over`&&e.opened}static ɵfac=(()=>{let t;return function(n){return(t||(t=Gp(i)))(n||i)}})();static ɵcmp=(function(){return So({type:i,selectors:[[`mat-drawer-content`]],hostAttrs:[1,`mat-drawer-content`],hostVars:6,hostBindings:function(n,o){n&2&&(Gg(`margin-left`,o._container._contentMargins.left,`px`)(`margin-right`,o._container._contentMargins.right,`px`),Rs(`mat-drawer-content-hidden`,o._shouldBeHidden()))},features:[nm([{provide:te$1,useExisting:i}]),Tg],ngContentSelectors:[`*`],decls:1,vars:0,template:function(n,o){n&1&&(vu(),Du(0))},encapsulation:2})})()}return i})();var be=(()=>{class i{_elementRef=g(nt);_focusTrapFactory=g(Je);_focusMonitor=g(He);_platform=g(nr);_ngZone=g(le$1);_renderer=g(hr);_interactivityChecker=g(Oe);_doc=g(L);_isAnimating=!1;_container=g(he,{optional:!0});_focusTrap=null;_elementFocusedBeforeDrawerWasOpened=null;_eventCleanups;_isAttached=!1;_anchor=null;get position(){return this._position}set position(t){t=t===`end`?`end`:`start`,t!==this._position&&(this._isAttached&&this._updatePositionInParent(t),this._position=t,this.onPositionChanged.emit())}_position=`start`;get mode(){return this._mode}set mode(t){this._mode=t,this._updateFocusTrapState(),this._modeChanged.next(),this._getContent()?._drawerModeChanged()}_mode=`over`;get disableClose(){return this._disableClose}set disableClose(t){this._disableClose=Vs(t)}_disableClose=!1;get autoFocus(){return this._autoFocus??(this.mode===`side`?`dialog`:`first-tabbable`)}set autoFocus(t){(t===`true`||t===`false`||t==null)&&(t=Vs(t)),this._autoFocus=t}_autoFocus;get opened(){return this._opened()}set opened(t){this.toggle(Vs(t))}_opened=or(!1);_openedVia=null;_animationStarted=new te;_animationEnd=new te;openedChange=new Pe(!0);_openedStream=this.openedChange.pipe(Ot(t=>t),Q(()=>{}));openedStart=this._animationStarted.pipe(Ot(()=>this.opened),Ea(void 0));_closedStream=this.openedChange.pipe(Ot(t=>!t),Q(()=>{}));closedStart=this._animationStarted.pipe(Ot(()=>!this.opened),Ea(void 0));_destroyed=new te;onPositionChanged=new Pe;_content;_modeChanged=new te;_injector=g(ne);_changeDetectorRef=g(gm);constructor(){this.openedChange.pipe(iv(this._destroyed)).subscribe(t=>{t?(this._elementFocusedBeforeDrawerWasOpened=this._doc.activeElement,this._takeFocus()):this._isFocusWithinDrawer()&&this._restoreFocus(this._openedVia||`program`)}),this._eventCleanups=this._ngZone.runOutsideAngular(()=>{let t=this._renderer,e=this._elementRef.nativeElement;return[t.listen(e,`keydown`,n=>{n.keyCode===27&&!this.disableClose&&!Le(n)&&this._ngZone.run(()=>{this.close(),n.stopPropagation(),n.preventDefault()})}),t.listen(e,`transitionend`,this._handleTransitionEvent),t.listen(e,`transitioncancel`,this._handleTransitionEvent)]}),this._animationEnd.subscribe(()=>{this.openedChange.emit(this.opened)})}_focusByCssSelector(t,e){let n=this._elementRef.nativeElement.querySelector(t);n&&(this._interactivityChecker.isFocusable(n)||(n.tabIndex=-1,this._ngZone.runOutsideAngular(()=>{let o=()=>{a(),m(),n.removeAttribute(`tabindex`)},a=this._renderer.listen(n,`blur`,o),m=this._renderer.listen(n,`mousedown`,o)})),n.focus(e))}_takeFocus(){if(!this._focusTrap)return;let t=this._elementRef.nativeElement;switch(this.autoFocus){case!1:case`dialog`:return;case!0:case`first-tabbable`:AE(()=>{let e=this._isAnimating?{preventScroll:!0}:void 0;!this._focusTrap.focusInitialElement(e)&&typeof t.focus==`function`&&t.focus(e)},{injector:this._injector});break;case`first-heading`:this._focusByCssSelector(`h1, h2, h3, h4, h5, h6, [role="heading"]`);break;default:this._focusByCssSelector(this.autoFocus)}}_restoreFocus(t){this.autoFocus!==`dialog`&&(this._elementFocusedBeforeDrawerWasOpened?this._focusMonitor.focusVia(this._elementFocusedBeforeDrawerWasOpened,t):this._elementRef.nativeElement.blur(),this._elementFocusedBeforeDrawerWasOpened=null)}_isFocusWithinDrawer(){let t=this._doc.activeElement;return!!t&&this._elementRef.nativeElement.contains(t)}ngAfterViewInit(){this._isAttached=!0,this._position===`end`&&this._updatePositionInParent(`end`),this._platform.isBrowser&&(this._focusTrap=this._focusTrapFactory.create(this._elementRef.nativeElement),this._updateFocusTrapState())}ngOnDestroy(){this._eventCleanups.forEach(t=>t()),this._focusTrap?.destroy(),this._anchor?.remove(),this._anchor=null,this._animationStarted.complete(),this._animationEnd.complete(),this._modeChanged.complete(),this._destroyed.next(),this._destroyed.complete()}open(t){return this.toggle(!0,t)}close(){return this.toggle(!1)}_closeViaBackdropClick(){return this._setOpen(!1,!0,`mouse`)}toggle(t=!this.opened,e){t&&e&&(this._openedVia=e);let n=this._setOpen(t,!t&&this._isFocusWithinDrawer(),this._openedVia||`program`);return t||(this._openedVia=null),n}_setOpen(t,e,n){return t===this.opened?Promise.resolve(t?`open`:`close`):(this._opened.set(t),this._getContent()?._drawerToggled(this),this._container?._transitionsEnabled?this._isAnimating?(this._setIsAnimating(!1),this._simulateAnimation()):(this._setIsAnimating(!0),setTimeout(()=>this._animationStarted.next())):this._simulateAnimation(),this._elementRef.nativeElement.classList.toggle(`mat-drawer-opened`,t),!t&&e&&this._restoreFocus(n),this._changeDetectorRef.markForCheck(),this._updateFocusTrapState(),new Promise(o=>{this.openedChange.pipe(kt(1)).subscribe(a=>o(a?`open`:`close`))}))}_getContent(){return this._container?._content||this._container?._userContent}_setIsAnimating(t){t!==this._isAnimating&&(this._isAnimating=t,this._elementRef.nativeElement.classList.toggle(`mat-drawer-animating`,t))}_simulateAnimation(){setTimeout(()=>{this._animationStarted.next(),this._animationEnd.next()})}_getWidth(){return this._elementRef.nativeElement.offsetWidth||0}_updateFocusTrapState(){this._focusTrap&&(this._focusTrap.enabled=this.opened&&!!this._container?._isShowingBackdrop())}_updatePositionInParent(t){if(!this._platform.isBrowser)return;let e=this._elementRef.nativeElement,n=e.parentNode;t===`end`?(this._anchor||(this._anchor=this._doc.createComment(`mat-drawer-anchor`),n.insertBefore(this._anchor,e)),n.appendChild(e)):this._anchor&&this._anchor.parentNode.insertBefore(e,this._anchor)}_handleTransitionEvent=t=>{let e=this._elementRef.nativeElement;t.target===e&&this._ngZone.run(()=>{t.type===`transitionend`&&this._setIsAnimating(!1),this._animationEnd.next(t)})};static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[`content`];return So({type:i,selectors:[[`mat-drawer`]],viewQuery:function(o,a){if(o&1&&Bg(t,5),o&2){let m;mC(m=yC())&&(a._content=m.first)}},hostAttrs:[1,`mat-drawer`],hostVars:12,hostBindings:function(o,a){o&2&&(No(`align`,null)(`tabIndex`,a.mode!==`side`?`-1`:null),Gg(`visibility`,!a._container&&!a.opened?`hidden`:null),Rs(`mat-drawer-end`,a.position===`end`)(`mat-drawer-over`,a.mode===`over`)(`mat-drawer-push`,a.mode===`push`)(`mat-drawer-side`,a.mode===`side`))},inputs:{position:`position`,mode:`mode`,disableClose:`disableClose`,autoFocus:`autoFocus`,opened:`opened`},outputs:{openedChange:`openedChange`,_openedStream:`opened`,openedStart:`openedStart`,_closedStream:`closed`,closedStart:`closedStart`,onPositionChanged:`positionChanged`},exportAs:[`matDrawer`],ngContentSelectors:[`*`],decls:3,vars:0,consts:[[`content`,``],[`cdkScrollable`,``,1,`mat-drawer-inner-container`]],template:function(o,a){o&1&&(vu(),Es(0,`div`,1,0),Du(2),hu())},dependencies:[te$1],encapsulation:2})})()}return i})();var ue=(()=>{class i{_dir=g(r_,{optional:!0});_element=g(nt);_ngZone=g(le$1);_changeDetectorRef=g(gm);_animationDisabled=Xr();_transitionsEnabled=!1;_allDrawers;_drawers=new cs;_content;_userContent;get start(){return this._start}get end(){return this._end}get autosize(){return this._autosize}set autosize(t){this._autosize=Vs(t)}_autosize=g(ki);get hasBackdrop(){return this._drawerHasBackdrop(this._start)||this._drawerHasBackdrop(this._end)}set hasBackdrop(t){this._backdropOverride=t==null?null:Vs(t)}_backdropOverride=null;backdropClick=new Pe;_start=null;_end=null;_left=null;_right=null;_destroyed=new te;_doCheckSubject=new te;_contentMargins={left:null,right:null};_contentMarginChanges=new te;get scrollable(){return this._userContent||this._content}_injector=g(ne);constructor(){let t=g(nr),e=g(tt);this._dir?.change.pipe(iv(this._destroyed)).subscribe(()=>{this._validateDrawers(),this.updateContentMargins()}),e.change().pipe(iv(this._destroyed)).subscribe(()=>this.updateContentMargins()),!this._animationDisabled&&t.isBrowser&&this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{this._element.nativeElement.classList.add(`mat-drawer-transition`),this._transitionsEnabled=!0},200)})}ngAfterContentInit(){this._allDrawers.changes.pipe(ov(this._allDrawers),iv(this._destroyed)).subscribe(t=>{this._drawers.reset(t.filter(e=>!e._container||e._container===this)),this._drawers.notifyOnChanges()}),this._drawers.changes.pipe(ov(null)).subscribe(()=>{this._validateDrawers(),this._drawers.forEach(t=>{this._watchDrawerToggle(t),this._watchDrawerPosition(t),this._watchDrawerMode(t)}),(!this._drawers.length||this._isDrawerOpen(this._start)||this._isDrawerOpen(this._end))&&this.updateContentMargins(),this._changeDetectorRef.markForCheck()}),this._ngZone.runOutsideAngular(()=>{this._doCheckSubject.pipe(Dd(10),iv(this._destroyed)).subscribe(()=>this.updateContentMargins())})}ngOnDestroy(){this._contentMarginChanges.complete(),this._doCheckSubject.complete(),this._drawers.destroy(),this._destroyed.next(),this._destroyed.complete()}open(){this._drawers.forEach(t=>t.open())}close(){this._drawers.forEach(t=>t.close())}updateContentMargins(){let t=0,e=0;if(this._left&&this._left.opened){if(this._left.mode==`side`)t+=this._left._getWidth();else if(this._left.mode==`push`){let n=this._left._getWidth();t+=n,e-=n}}if(this._right&&this._right.opened){if(this._right.mode==`side`)e+=this._right._getWidth();else if(this._right.mode==`push`){let n=this._right._getWidth();e+=n,t-=n}}t=t||null,e=e||null,(t!==this._contentMargins.left||e!==this._contentMargins.right)&&(this._contentMargins={left:t,right:e},this._ngZone.run(()=>this._contentMarginChanges.next(this._contentMargins)))}ngDoCheck(){this._autosize&&this._isPushed()&&this._ngZone.runOutsideAngular(()=>this._doCheckSubject.next())}_watchDrawerToggle(t){t._animationStarted.pipe(iv(this._drawers.changes)).subscribe(()=>{this.updateContentMargins(),this._changeDetectorRef.markForCheck()}),t.mode!==`side`&&t.openedChange.pipe(iv(this._drawers.changes)).subscribe(()=>this._setContainerClass(t.opened))}_watchDrawerPosition(t){t.onPositionChanged.pipe(iv(this._drawers.changes)).subscribe(()=>{AE({read:()=>this._validateDrawers()},{injector:this._injector})})}_watchDrawerMode(t){t._modeChanged.pipe(iv(Yy(this._drawers.changes,this._destroyed))).subscribe(()=>{this.updateContentMargins(),this._changeDetectorRef.markForCheck()})}_setContainerClass(t){let e=this._element.nativeElement.classList,n=`mat-drawer-container-has-open`;t?e.add(n):e.remove(n)}_validateDrawers(){this._start=this._end=null,this._drawers.forEach(t=>{t.position==`end`?(this._end,this._end=t):(this._start,this._start=t)}),this._right=this._left=null,this._dir&&this._dir.value===`rtl`?(this._left=this._end,this._right=this._start):(this._left=this._start,this._right=this._end)}_isPushed(){return this._isDrawerOpen(this._start)&&this._start.mode!=`over`||this._isDrawerOpen(this._end)&&this._end.mode!=`over`}_onBackdropClicked(){this.backdropClick.emit(),this._closeModalDrawersViaBackdrop()}_closeModalDrawersViaBackdrop(){[this._start,this._end].filter(t=>t&&!t.disableClose&&this._drawerHasBackdrop(t)).forEach(t=>t._closeViaBackdropClick())}_isShowingBackdrop(){return this._isDrawerOpen(this._start)&&this._drawerHasBackdrop(this._start)||this._isDrawerOpen(this._end)&&this._drawerHasBackdrop(this._end)}_isDrawerOpen(t){return t!=null&&t.opened}_drawerHasBackdrop(t){return this._backdropOverride==null?!!t&&t.mode!==`side`:this._backdropOverride}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[[[`mat-drawer`],[`mat-sidenav`]],[[`mat-drawer-content`],[`mat-sidenav-content`]],`*`],e=[`mat-drawer, mat-sidenav`,`mat-drawer-content, mat-sidenav-content`,`*`];function n(a,m){if(a&1){let d=aC();Es(0,`div`,1),Pg(`click`,function(){yf(d);let w=pC();return vf(w._onBackdropClicked())}),hu()}if(a&2){let d=pC();Rs(`mat-drawer-shown`,d._isShowingBackdrop())}}function o(a,m){a&1&&(Es(0,`mat-drawer-content`),Du(1,2),hu())}return So({type:i,selectors:[[`mat-drawer-container`]],contentQueries:function(m,d,f){if(m&1&&Vg(f,zt,5)(f,be,5),m&2){let w;mC(w=yC())&&(d._content=w.first),mC(w=yC())&&(d._allDrawers=w)}},viewQuery:function(m,d){if(m&1&&Bg(zt,5),m&2){let f;mC(f=yC())&&(d._userContent=f.first)}},hostAttrs:[1,`mat-drawer-container`],hostVars:2,hostBindings:function(m,d){m&2&&Rs(`mat-drawer-container-explicit-backdrop`,d._backdropOverride)},inputs:{autosize:`autosize`,hasBackdrop:`hasBackdrop`},outputs:{backdropClick:`backdropClick`},exportAs:[`matDrawerContainer`],features:[nm([{provide:he,useExisting:i}])],ngContentSelectors:e,decls:4,vars:2,consts:[[1,`mat-drawer-backdrop`,3,`mat-drawer-shown`],[1,`mat-drawer-backdrop`,3,`click`]],template:function(m,d){m&1&&(vu(t),Kw(0,n,1,2,`div`,0),Du(1),Du(2,1),Kw(3,o,2,0,`mat-drawer-content`)),m&2&&(Jw(d.hasBackdrop?0:-1),QE(3),Jw(d._content?-1:3))},dependencies:[zt],styles:[`.mat-drawer-container {
  position: relative;
  z-index: 1;
  color: var(--%NS%mat-sidenav-content-text-color, var(--%NS%mat-sys-on-background));
  background-color: var(--%NS%mat-sidenav-content-background-color, var(--%NS%mat-sys-background));
  box-sizing: border-box;
  display: block;
  overflow: hidden;
}
.mat-drawer-container[fullscreen] {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
}
.mat-drawer-container[fullscreen].mat-drawer-container-has-open {
  overflow: hidden;
}
.mat-drawer-container.mat-drawer-container-explicit-backdrop .mat-drawer-side {
  z-index: 3;
}
.mat-drawer-container.ng-animate-disabled .mat-drawer-backdrop,
.mat-drawer-container.ng-animate-disabled .mat-drawer-content, .ng-animate-disabled .mat-drawer-container .mat-drawer-backdrop,
.ng-animate-disabled .mat-drawer-container .mat-drawer-content {
  transition: none;
}

.mat-drawer-backdrop {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  z-index: 3;
  visibility: hidden;
}
.mat-drawer-backdrop.mat-drawer-shown {
  visibility: visible;
  background-color: var(--%NS%mat-sidenav-scrim-color, color-mix(in srgb, var(--%NS%mat-sys-neutral-variant20) 40%, transparent));
}
.mat-drawer-transition .mat-drawer-backdrop {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: background-color, visibility;
}
@media (forced-colors: active) {
  .mat-drawer-backdrop {
    opacity: 0.5;
  }
}

.mat-drawer-content {
  position: relative;
  z-index: 1;
  display: block;
  height: 100%;
  overflow: auto;
}
.mat-drawer-content.mat-drawer-content-hidden {
  opacity: 0;
}
.mat-drawer-transition .mat-drawer-content {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: transform, margin-left, margin-right;
}

.mat-drawer {
  position: relative;
  z-index: 4;
  color: var(--%NS%mat-sidenav-container-text-color, var(--%NS%mat-sys-on-surface-variant));
  box-shadow: var(--%NS%mat-sidenav-container-elevation-shadow, none);
  background-color: var(--%NS%mat-sidenav-container-background-color, var(--%NS%mat-sys-surface));
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  width: var(--%NS%mat-sidenav-container-width, 360px);
  display: block;
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 3;
  outline: 0;
  box-sizing: border-box;
  overflow-y: auto;
  transform: translate3d(-100%, 0, 0);
}
@media (forced-colors: active) {
  .mat-drawer, [dir=rtl] .mat-drawer.mat-drawer-end {
    border-right: solid 1px currentColor;
  }
}
@media (forced-colors: active) {
  [dir=rtl] .mat-drawer, .mat-drawer.mat-drawer-end {
    border-left: solid 1px currentColor;
    border-right: none;
  }
}
.mat-drawer.mat-drawer-side {
  z-index: 2;
}
.mat-drawer.mat-drawer-end {
  right: 0;
  transform: translate3d(100%, 0, 0);
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
[dir=rtl] .mat-drawer {
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transform: translate3d(100%, 0, 0);
}
[dir=rtl] .mat-drawer.mat-drawer-end {
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  left: 0;
  right: auto;
  transform: translate3d(-100%, 0, 0);
}
.mat-drawer-transition .mat-drawer {
  transition: transform 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) {
  visibility: hidden;
  box-shadow: none;
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) .mat-drawer-inner-container {
  display: none;
}
.mat-drawer.mat-drawer-opened.mat-drawer-opened {
  transform: none;
}

.mat-drawer-side {
  box-shadow: none;
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
}
.mat-drawer-side.mat-drawer-end {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side.mat-drawer-end {
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
  border-left: none;
}

.mat-drawer-inner-container {
  width: 100%;
  height: 100%;
  overflow: auto;
}

.mat-sidenav-fixed {
  position: fixed;
}
`],encapsulation:2})})()}return i})();var qt=(()=>{class i extends zt{static ɵfac=(()=>{let t;return function(n){return(t||(t=Gp(i)))(n||i)}})();static ɵcmp=(function(){return So({type:i,selectors:[[`mat-sidenav-content`]],hostAttrs:[1,`mat-drawer-content`,`mat-sidenav-content`],features:[nm([{provide:te$1,useExisting:i},{provide:zt,useExisting:i}]),Tg],ngContentSelectors:[`*`],decls:1,vars:0,template:function(n,o){n&1&&(vu(),Du(0))},encapsulation:2})})()}return i})();var ge=(()=>{class i extends be{get fixedInViewport(){return this._fixedInViewport}set fixedInViewport(t){this._fixedInViewport=Vs(t)}_fixedInViewport=!1;get fixedTopGap(){return this._fixedTopGap}set fixedTopGap(t){this._fixedTopGap=Be(t)}_fixedTopGap=0;get fixedBottomGap(){return this._fixedBottomGap}set fixedBottomGap(t){this._fixedBottomGap=Be(t)}_fixedBottomGap=0;static ɵfac=(()=>{let t;return function(n){return(t||(t=Gp(i)))(n||i)}})();static ɵcmp=(function(){return So({type:i,selectors:[[`mat-sidenav`]],hostAttrs:[1,`mat-drawer`,`mat-sidenav`],hostVars:16,hostBindings:function(n,o){n&2&&(No(`tabIndex`,o.mode!==`side`?`-1`:null)(`align`,null),Gg(`top`,o.fixedInViewport?o.fixedTopGap:null,`px`)(`bottom`,o.fixedInViewport?o.fixedBottomGap:null,`px`),Rs(`mat-drawer-end`,o.position===`end`)(`mat-drawer-over`,o.mode===`over`)(`mat-drawer-push`,o.mode===`push`)(`mat-drawer-side`,o.mode===`side`)(`mat-sidenav-fixed`,o.fixedInViewport))},inputs:{fixedInViewport:`fixedInViewport`,fixedTopGap:`fixedTopGap`,fixedBottomGap:`fixedBottomGap`},exportAs:[`matSidenav`],features:[nm([{provide:be,useExisting:i}]),Tg],ngContentSelectors:[`*`],decls:3,vars:0,consts:[[`content`,``],[`cdkScrollable`,``,1,`mat-drawer-inner-container`]],template:function(n,o){n&1&&(vu(),Es(0,`div`,1,0),Du(2),hu())},dependencies:[te$1],encapsulation:2})})()}return i})();var ti=(()=>{class i extends ue{_allDrawers=void 0;_content=void 0;static ɵfac=(()=>{let t;return function(n){return(t||(t=Gp(i)))(n||i)}})();static ɵcmp=(function(){let t=[[[`mat-drawer`],[`mat-sidenav`]],[[`mat-drawer-content`],[`mat-sidenav-content`]],`*`],e=[`mat-drawer, mat-sidenav`,`mat-drawer-content, mat-sidenav-content`,`*`];function n(a,m){if(a&1){let d=aC();Es(0,`div`,1),Pg(`click`,function(){yf(d);let w=pC();return vf(w._onBackdropClicked())}),hu()}if(a&2){let d=pC();Rs(`mat-drawer-shown`,d._isShowingBackdrop())}}function o(a,m){a&1&&(Es(0,`mat-sidenav-content`),Du(1,2),hu())}return So({type:i,selectors:[[`mat-sidenav-container`]],contentQueries:function(m,d,f){if(m&1&&Vg(f,qt,5)(f,ge,5),m&2){let w;mC(w=yC())&&(d._content=w.first),mC(w=yC())&&(d._allDrawers=w)}},hostAttrs:[1,`mat-drawer-container`,`mat-sidenav-container`],hostVars:2,hostBindings:function(m,d){m&2&&Rs(`mat-drawer-container-explicit-backdrop`,d._backdropOverride)},exportAs:[`matSidenavContainer`],features:[nm([{provide:he,useExisting:i},{provide:ue,useExisting:i}]),Tg],ngContentSelectors:e,decls:4,vars:2,consts:[[1,`mat-drawer-backdrop`,3,`mat-drawer-shown`],[1,`mat-drawer-backdrop`,3,`click`]],template:function(m,d){m&1&&(vu(t),Kw(0,n,1,2,`div`,0),Du(1),Du(2,1),Kw(3,o,2,0,`mat-sidenav-content`)),m&2&&(Jw(d.hasBackdrop?0:-1),QE(3),Jw(d._content?-1:3))},dependencies:[qt],styles:[`.mat-drawer-container {
  position: relative;
  z-index: 1;
  color: var(--%NS%mat-sidenav-content-text-color, var(--%NS%mat-sys-on-background));
  background-color: var(--%NS%mat-sidenav-content-background-color, var(--%NS%mat-sys-background));
  box-sizing: border-box;
  display: block;
  overflow: hidden;
}
.mat-drawer-container[fullscreen] {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
}
.mat-drawer-container[fullscreen].mat-drawer-container-has-open {
  overflow: hidden;
}
.mat-drawer-container.mat-drawer-container-explicit-backdrop .mat-drawer-side {
  z-index: 3;
}
.mat-drawer-container.ng-animate-disabled .mat-drawer-backdrop,
.mat-drawer-container.ng-animate-disabled .mat-drawer-content, .ng-animate-disabled .mat-drawer-container .mat-drawer-backdrop,
.ng-animate-disabled .mat-drawer-container .mat-drawer-content {
  transition: none;
}

.mat-drawer-backdrop {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  z-index: 3;
  visibility: hidden;
}
.mat-drawer-backdrop.mat-drawer-shown {
  visibility: visible;
  background-color: var(--%NS%mat-sidenav-scrim-color, color-mix(in srgb, var(--%NS%mat-sys-neutral-variant20) 40%, transparent));
}
.mat-drawer-transition .mat-drawer-backdrop {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: background-color, visibility;
}
@media (forced-colors: active) {
  .mat-drawer-backdrop {
    opacity: 0.5;
  }
}

.mat-drawer-content {
  position: relative;
  z-index: 1;
  display: block;
  height: 100%;
  overflow: auto;
}
.mat-drawer-content.mat-drawer-content-hidden {
  opacity: 0;
}
.mat-drawer-transition .mat-drawer-content {
  transition-duration: 400ms;
  transition-timing-function: cubic-bezier(0.25, 0.8, 0.25, 1);
  transition-property: transform, margin-left, margin-right;
}

.mat-drawer {
  position: relative;
  z-index: 4;
  color: var(--%NS%mat-sidenav-container-text-color, var(--%NS%mat-sys-on-surface-variant));
  box-shadow: var(--%NS%mat-sidenav-container-elevation-shadow, none);
  background-color: var(--%NS%mat-sidenav-container-background-color, var(--%NS%mat-sys-surface));
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  width: var(--%NS%mat-sidenav-container-width, 360px);
  display: block;
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 3;
  outline: 0;
  box-sizing: border-box;
  overflow-y: auto;
  transform: translate3d(-100%, 0, 0);
}
@media (forced-colors: active) {
  .mat-drawer, [dir=rtl] .mat-drawer.mat-drawer-end {
    border-right: solid 1px currentColor;
  }
}
@media (forced-colors: active) {
  [dir=rtl] .mat-drawer, .mat-drawer.mat-drawer-end {
    border-left: solid 1px currentColor;
    border-right: none;
  }
}
.mat-drawer.mat-drawer-side {
  z-index: 2;
}
.mat-drawer.mat-drawer-end {
  right: 0;
  transform: translate3d(100%, 0, 0);
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
[dir=rtl] .mat-drawer {
  border-top-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-left-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  transform: translate3d(100%, 0, 0);
}
[dir=rtl] .mat-drawer.mat-drawer-end {
  border-top-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-bottom-right-radius: var(--%NS%mat-sidenav-container-shape, var(--%NS%mat-sys-corner-large));
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  left: 0;
  right: auto;
  transform: translate3d(-100%, 0, 0);
}
.mat-drawer-transition .mat-drawer {
  transition: transform 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) {
  visibility: hidden;
  box-shadow: none;
}
.mat-drawer:not(.mat-drawer-opened):not(.mat-drawer-animating) .mat-drawer-inner-container {
  display: none;
}
.mat-drawer.mat-drawer-opened.mat-drawer-opened {
  transform: none;
}

.mat-drawer-side {
  box-shadow: none;
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
}
.mat-drawer-side.mat-drawer-end {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side {
  border-left-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-left-width: 1px;
  border-left-style: solid;
  border-right: none;
}
[dir=rtl] .mat-drawer-side.mat-drawer-end {
  border-right-color: var(--%NS%mat-sidenav-container-divider-color, transparent);
  border-right-width: 1px;
  border-right-style: solid;
  border-left: none;
}

.mat-drawer-inner-container {
  width: 100%;
  height: 100%;
  overflow: auto;
}

.mat-sidenav-fixed {
  position: fixed;
}
`],encapsulation:2})})()}return i})();var ei=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[Jt,hy,Jt]})}return i})();var Ni=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵdir=Mo({type:i,selectors:[[`mat-toolbar-row`]],hostAttrs:[1,`mat-toolbar-row`],exportAs:[`matToolbarRow`]})}return i})();var ni=(()=>{class i{_elementRef=g(nt);_platform=g(nr);_document=g(L);color;_toolbarRows;ngAfterViewInit(){this._platform.isBrowser&&(this._checkToolbarMixedModes(),this._toolbarRows.changes.subscribe(()=>this._checkToolbarMixedModes()))}_checkToolbarMixedModes(){this._toolbarRows.length}static ɵfac=function(e){return new(e||i)};static ɵcmp=(function(){let t=[`*`,[[`mat-toolbar-row`]]];return So({type:i,selectors:[[`mat-toolbar`]],contentQueries:function(o,a,m){if(o&1&&Vg(m,Ni,5),o&2){let d;mC(d=yC())&&(a._toolbarRows=d)}},hostAttrs:[1,`mat-toolbar`],hostVars:6,hostBindings:function(o,a){o&2&&(Eu(a.color?`mat-`+a.color:``),Rs(`mat-toolbar-multiple-rows`,a._toolbarRows.length>0)(`mat-toolbar-single-row`,a._toolbarRows.length===0))},inputs:{color:`color`},exportAs:[`matToolbar`],ngContentSelectors:[`*`,`mat-toolbar-row`],decls:2,vars:0,template:function(o,a){o&1&&(vu(t),Du(0),Du(1,1))},styles:[`.mat-toolbar {
  background: var(--%NS%mat-toolbar-container-background-color, var(--%NS%mat-sys-surface));
  color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-toolbar, .mat-toolbar h1, .mat-toolbar h2, .mat-toolbar h3, .mat-toolbar h4, .mat-toolbar h5, .mat-toolbar h6 {
  font-family: var(--%NS%mat-toolbar-title-text-font, var(--%NS%mat-sys-title-large-font));
  font-size: var(--%NS%mat-toolbar-title-text-size, var(--%NS%mat-sys-title-large-size));
  line-height: var(--%NS%mat-toolbar-title-text-line-height, var(--%NS%mat-sys-title-large-line-height));
  font-weight: var(--%NS%mat-toolbar-title-text-weight, var(--%NS%mat-sys-title-large-weight));
  letter-spacing: var(--%NS%mat-toolbar-title-text-tracking, var(--%NS%mat-sys-title-large-tracking));
  margin: 0;
}
@media (forced-colors: active) {
  .mat-toolbar {
    outline: solid 1px;
  }
}
.mat-toolbar .mat-form-field-underline,
.mat-toolbar .mat-form-field-ripple,
.mat-toolbar .mat-focused .mat-form-field-ripple {
  background-color: currentColor;
}
.mat-toolbar .mat-form-field-label,
.mat-toolbar .mat-focused .mat-form-field-label,
.mat-toolbar .mat-select-value,
.mat-toolbar .mat-select-arrow,
.mat-toolbar .mat-form-field.mat-focused .mat-select-arrow {
  color: inherit;
}
.mat-toolbar .mat-input-element {
  caret-color: currentColor;
}
.mat-toolbar .mat-mdc-button-base.mat-mdc-button-base.mat-unthemed {
  --%NS%mat-button-text-label-text-color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
  --%NS%mat-button-outlined-label-text-color: var(--%NS%mat-toolbar-container-text-color, var(--%NS%mat-sys-on-surface));
}

.mat-toolbar-row, .mat-toolbar-single-row {
  display: flex;
  box-sizing: border-box;
  padding: 0 16px;
  width: 100%;
  flex-direction: row;
  align-items: center;
  white-space: nowrap;
  height: var(--%NS%mat-toolbar-standard-height, 64px);
}
@media (max-width: 599px) {
  .mat-toolbar-row, .mat-toolbar-single-row {
    height: var(--%NS%mat-toolbar-mobile-height, 56px);
  }
}

.mat-toolbar-multiple-rows {
  display: flex;
  box-sizing: border-box;
  flex-direction: column;
  width: 100%;
  min-height: var(--%NS%mat-toolbar-standard-height, 64px);
}
@media (max-width: 599px) {
  .mat-toolbar-multiple-rows {
    min-height: var(--%NS%mat-toolbar-mobile-height, 56px);
  }
}
`],encapsulation:2})})()}return i})();var ii=(()=>{class i{static ɵfac=function(e){return new(e||i)};static ɵmod=Ct$1({type:i});static ɵinj=Xe({imports:[hy]})}return i})();function Ii(i,c){i&1&&Rg(0,`mat-progress-bar`,1)}function Ei(i,c){i&1&&(Es(0,`mat-error`),BC(1,`Escribe tu contraseña actual.`),hu())}function Di(i,c){i&1&&(Es(0,`mat-error`),BC(1,`Debe tener al menos 8 caracteres.`),hu())}function Ai(i,c){i&1&&BC(0,` Las contraseñas no coinciden. `)}function Ti(i,c){i&1&&BC(0,` Repite la nueva contraseña. `)}function Pi(i,c){if(i&1&&(Es(0,`mat-error`),Kw(1,Ai,1,0)(2,Ti,1,0),hu()),i&2){let t=pC();QE(),Jw(t.form.controls.password_confirmation.errors?.mismatch?1:2)}}function Oi(i,c){if(i&1&&(Es(0,`div`,7)(1,`span`,11),BC(2,`error`),hu(),Es(3,`span`),BC(4),hu()()),i&2){let t=pC();QE(4),Kg(t.error())}}var Xt=class i{auth=g(d);toast=g(u);dialogRef=g(Nt);fb=g(Wr);saving=or(!1);error=or(null);form=this.fb.nonNullable.group({current_password:[``,[Me.required,Me.maxLength(255)]],password:[``,[Me.required,Me.minLength(8),Me.maxLength(255)]],password_confirmation:[``,[Me.required,Me.maxLength(255)]]},{validators:rs});save(){if(this.form.invalid){this.form.markAllAsTouched();return}if(this.form.controls.password.value!==this.form.controls.password_confirmation.value){this.form.controls.password_confirmation.setErrors({mismatch:!0});return}this.saving.set(!0),this.error.set(null),this.auth.changePassword(this.form.getRawValue()).subscribe({next:c=>{this.saving.set(!1),this.toast.success(c.message||rU.auth.changePasswordSuccess),this.dialogRef.close(!0)},error:c=>{this.saving.set(!1),this.error.set(qr(c,rU.auth.changePasswordFallback))}})}close(){this.dialogRef.close(!1)}static ɵfac=function(t){return new(t||i)};static ɵcmp=So({type:i,selectors:[[`app-change-password-dialog`]],decls:32,vars:7,consts:[[`mat-dialog-title`,``],[`mode`,`indeterminate`],[1,`stack`,2,`margin-top`,`8px`,3,`ngSubmit`,`formGroup`],[`appearance`,`outline`],[`matInput`,``,`type`,`password`,`formControlName`,`current_password`,`autocomplete`,`current-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password`,`autocomplete`,`new-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password_confirmation`,`autocomplete`,`new-password`,`maxlength`,`255`],[1,`banner`,`banner--danger`],[1,`btn-row`,2,`justify-content`,`flex-end`],[`type`,`button`,1,`btn`,`btn--outline`,3,`click`],[`type`,`submit`,1,`btn`,`btn--primary`,3,`disabled`],[1,`material-icons`]],template:function(t,e){t&1&&(Es(0,`h2`,0),BC(1,`Cambiar contraseña`),hu(),Es(2,`mat-dialog-content`),Kw(3,Ii,1,0,`mat-progress-bar`,1),Es(4,`form`,2),Pg(`ngSubmit`,function(){return e.save()}),Es(5,`mat-form-field`,3)(6,`mat-label`),BC(7,`Contraseña actual`),hu(),Es(8,`input`,4),BI(),hu(),Es(9,`mat-hint`),BC(10,`La contraseña con la que ingresaste hoy.`),hu(),Kw(11,Ei,2,0,`mat-error`),hu(),Es(12,`mat-form-field`,3)(13,`mat-label`),BC(14,`Nueva contraseña`),hu(),Es(15,`input`,5),BI(),hu(),Es(16,`mat-hint`),BC(17,`Mínimo 8 caracteres.`),hu(),Kw(18,Di,2,0,`mat-error`),hu(),Es(19,`mat-form-field`,3)(20,`mat-label`),BC(21,`Repetir nueva contraseña`),hu(),Es(22,`input`,6),BI(),hu(),Es(23,`mat-hint`),BC(24,`Debe coincidir exactamente con la nueva contraseña.`),hu(),Kw(25,Pi,3,1,`mat-error`),hu(),Kw(26,Oi,5,1,`div`,7),Es(27,`div`,8)(28,`button`,9),Pg(`click`,function(){return e.close()}),BC(29,`Cancelar`),hu(),Es(30,`button`,10),BC(31,` Guardar contraseña `),hu()()()()),t&2&&(QE(3),Jw(e.saving()?3:-1),QE(),xg(`formGroup`,e.form),QE(4),UI(),QE(3),Jw(e.form.controls.current_password.touched&&e.form.controls.current_password.invalid?11:-1),QE(4),UI(),QE(3),Jw(e.form.controls.password.touched&&e.form.controls.password.invalid?18:-1),QE(4),UI(),QE(3),Jw(e.form.controls.password_confirmation.touched&&e.form.controls.password_confirmation.invalid?25:-1),QE(),Jw(e.error()?26:-1),QE(4),xg(`disabled`,e.saving()))},dependencies:[Kr,Ur,vn,Br,Hr,ji$1,wt,sr,zo,Bo,Lo,Vt,ri$1,Dt,Ft,mr,Ja,Qa,Fr,Lr],encapsulation:2})};var Li=(i,c)=>c.route;var Bi=(i,c)=>c.id;function Ri(i,c){if(i&1&&(Es(0,`span`,36),BC(1),hu()),i&2){let t=pC(2);QE(),Kg(t.unreadCount())}}function Fi(i,c){if(i&1){let t=aC();Es(0,`a`,35),Pg(`click`,function(){yf(t);let n=pC();return vf(n.isMobile()&&n.sidenavOpen.set(!1))}),Es(1,`mat-icon`),BC(2),hu(),Es(3,`span`),BC(4),hu(),Kw(5,Ri,2,1,`span`,36),hu()}if(i&2){let t=c.$implicit,e=pC();Rs(`nav-item--active`,e.isActive(t)),xg(`routerLink`,t.route),QE(2),Kg(t.icon),QE(2),Kg(t.label),QE(),Jw(t.route===`/avisos`&&e.unreadCount()>0?5:-1)}}function ji(i,c){if(i&1){let t=aC();Es(0,`button`,37),Pg(`click`,function(){yf(t);let n=pC();return vf(n.onInstallClick())}),Es(1,`mat-icon`),BC(2,`install_mobile`),hu(),Es(3,`span`),BC(4,`Instalar app`),hu()()}}function Vi(i,c){i&1&&(Es(0,`div`,38),Rg(1,`mat-progress-bar`,42),hu())}function Hi(i,c){i&1&&(Es(0,`div`,39),BC(1,` No encontramos clientes con ese dato. `),hu())}function Gi(i,c){if(i&1){let t=aC();Es(0,`button`,43),Pg(`click`,function(){let n=yf(t).$implicit,o=pC(2);return vf(o.selectClient(n))}),Es(1,`span`,44),BC(2),hu(),Es(3,`span`,45)(4,`strong`),BC(5),hu(),Es(6,`span`),BC(7),hu()(),Es(8,`span`,6),BC(9,`chevron_right`),hu()()}if(i&2){let t=c.$implicit;QE(2),Kg(t.full_name.charAt(0)),QE(3),Kg(t.full_name),QE(2),Kg(t.phone)}}function Qi(i,c){if(i&1){let t=aC();Es(0,`button`,46),Pg(`click`,function(){yf(t);let n=pC(2);return vf(n.submitGlobalSearch())}),BC(1,` Ver todos los resultados `),hu()}}function Ui(i,c){if(i&1&&(Es(0,`div`,24),Kw(1,Vi,2,0,`div`,38),Kw(2,Hi,2,0,`div`,39),tC(3,Gi,10,3,`button`,40,Bi),Kw(5,Qi,2,0,`button`,41),hu()),i&2){let t=pC();QE(),Jw(t.searching()?1:-1),QE(),Jw(!t.searching()&&t.results().length===0&&t.searchTerm().trim()!==``?2:-1),QE(),nC(t.results()),QE(2),Jw(t.results().length>0?5:-1)}}var ai=class i{auth=g(d);notifications=g(c);clients=g(g$2);images=g(f);router=g(G$1);dialog=g(Je$1);breakpoint=g(cr);destroyRef=g(he$1);toast=g(u);pwa=g(K);user=this.auth.user;isMobile=T(this.breakpoint.observe(`(max-width: 900px)`).pipe(Q(c=>c.matches)),{initialValue:!1});sidenavOpen=or(!0);currentUrl=or(this.router.url);navItems=[{label:`Inicio`,icon:`dashboard`,route:`/inicio`},{label:`Nuevo cliente`,icon:`person_add`,route:`/clientes/nuevo`},{label:`Buscar cliente`,icon:`manage_search`,route:`/clientes`},{label:`Pedidos`,icon:`shopping_bag`,route:`/pedidos`},{label:`Avisos de entrega`,icon:`local_shipping`,route:`/entregas`},{label:`Historial`,icon:`history`,route:`/historial`},{label:`Avisos`,icon:`notifications`,route:`/avisos`},{label:`Crear usuario`,icon:`group_add`,route:`/usuarios`}];searching=or(!1);results=or([]);showResults=or(!1);searchTerm=or(``);unreadCount=this.notifications.unreadCount;searchSubject=new te;constructor(){Vf(()=>{this.sidenavOpen.set(!this.isMobile())}),this.searchSubject.pipe(Dd(300),Ed(),ma(c=>c.trim()===``?ot({current_page:1,data:[],last_page:1,per_page:6,total:0}):(this.searching.set(!0),this.clients.list({search:c,per_page:6}).pipe(Vn$1(()=>this.searching.set(!1))))),U(this.destroyRef)).subscribe({next:c=>{this.results.set(c.data),this.showResults.set(!0)},error:()=>{this.results.set([]),this.searching.set(!1)}}),this.router.events.pipe(Ot(c=>c instanceof x),U(this.destroyRef)).subscribe(c=>{this.currentUrl.set(c.urlAfterRedirects),this.closeResults(),this.notifications.refreshUnreadCount(),this.isMobile()&&this.sidenavOpen.set(!1)}),Nr(0,6e4).pipe(U(this.destroyRef)).subscribe(()=>this.notifications.refreshUnreadCount())}isActive(c){let t=this.currentUrl().split(`?`)[0];return c.route===`/clientes`?t.startsWith(`/clientes`)&&!t.startsWith(`/clientes/nuevo`):c.route===`/clientes/nuevo`?t.startsWith(`/clientes/nuevo`):t===c.route||t.startsWith(c.route+`/`)}toggleSidenav(){this.sidenavOpen.update(c=>!c)}onSearchInput(c){let t=c.target.value;if(this.searchTerm.set(t),t.trim()===``){this.results.set([]),this.showResults.set(!1);return}this.searchSubject.next(t)}onSearchFocus(){(this.results().length||this.searchTerm().trim()!==``)&&this.showResults.set(!0)}onSearchBlur(){setTimeout(()=>this.showResults.set(!1),180)}submitGlobalSearch(){let c=this.searchTerm().trim();c!==``&&this.router.navigate([`/clientes`],{queryParams:{q:c}})}selectClient(c){this.router.navigate([`/clientes`,c.id]),this.clearSearch()}clearSearch(){this.searchTerm.set(``),this.results.set([]),this.showResults.set(!1)}closeResults(){this.showResults.set(!1)}openSearchPage(){this.router.navigate([`/clientes`],{queryParams:{focus:1}})}goToNotifications(){this.router.navigate([`/avisos`])}changePassword(){this.dialog.open(Xt,{width:`430px`,maxWidth:`92vw`,panelClass:`app-dialog`,autoFocus:!1})}onInstallClick(){this.isMobile()&&this.sidenavOpen.set(!1),this.installApp()}async installApp(){if(!this.pwa.installed()){if(this.pwa.canInstall()){let c=await this.pwa.promptInstall();c===`accepted`?this.toast.success(rU.layout.installAccepted):c===`dismissed`&&this.toast.info(rU.layout.installDismissed);return}this.toast.info(rU.layout.installInstructions)}}logout(){this.auth.logout().subscribe({next:()=>this.finishLogout(),error:()=>this.finishLogout()})}finishLogout(){this.images.clear(),this.router.navigate([`/login`])}static ɵfac=function(t){return new(t||i)};static ɵcmp=So({type:i,selectors:[[`app-layout`]],decls:80,vars:16,consts:[[`sidenav`,``],[`userMenu`,`matMenu`],[1,`shell`],[1,`sidebar`,3,`openedChange`,`mode`,`opened`],[`routerLink`,`/inicio`,1,`brand`,3,`click`],[1,`brand__mark`],[1,`material-icons`],[1,`brand__name`],[1,`brand__sub`],[1,`nav`],[1,`nav-item`,3,`nav-item--active`,`routerLink`],[`type`,`button`,1,`nav-item`,`nav-item--button`],[1,`sidebar__footer`],[1,`sidebar__user`],[1,`avatar`],[1,`sidebar__user-info`],[`type`,`button`,1,`btn`,`btn--ghost`,`btn--sm`,`btn--block`,3,`click`],[1,`content`],[1,`topbar`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Abrir menú`,1,`topbar__icon`,`mobile-only`,3,`click`],[`routerLink`,`/inicio`,1,`topbar__brand`,`mobile-only`],[1,`topbar__search`,`desktop-only`],[1,`search-box`],[`type`,`search`,`maxlength`,`100`,`placeholder`,`Buscar por nombre o celular…`,`aria-label`,`Buscar cliente`,1,`search-input`,3,`input`,`focus`,`blur`,`keydown.enter`,`value`],[1,`search-results`],[1,`spacer`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Buscar cliente`,1,`topbar__icon`,`mobile-only`,3,`click`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Avisos`,1,`topbar__icon`,3,`click`],[`matBadgeColor`,`warn`,`matBadgeSize`,`small`,3,`matBadge`,`matBadgeHidden`],[`mat-button`,``,`type`,`button`,1,`topbar__user`,`desktop-only`,3,`matMenuTriggerFor`],[1,`avatar`,`avatar--sm`],[`mat-icon-button`,``,`type`,`button`,`aria-label`,`Cuenta`,1,`topbar__icon`,`mobile-only`,3,`matMenuTriggerFor`],[1,`menu-user`],[`mat-menu-item`,``,`type`,`button`,3,`click`],[1,`main`],[1,`nav-item`,3,`click`,`routerLink`],[1,`nav-item__badge`],[`type`,`button`,1,`nav-item`,`nav-item--button`,3,`click`],[1,`search-results__status`],[1,`search-results__empty`],[`type`,`button`,1,`search-result`],[`type`,`button`,1,`search-results__all`],[`mode`,`indeterminate`],[`type`,`button`,1,`search-result`,3,`click`],[1,`search-result__avatar`],[1,`search-result__info`],[`type`,`button`,1,`search-results__all`,3,`click`]],template:function(t,e){if(t&1&&(Es(0,`mat-sidenav-container`,2)(1,`mat-sidenav`,3,0),Pg(`openedChange`,function(o){return e.sidenavOpen.set(o)}),Es(3,`div`,4),Pg(`click`,function(){return e.isMobile()&&e.sidenavOpen.set(!1)}),Es(4,`div`,5)(5,`span`,6),BC(6,`visibility`),hu()(),Es(7,`div`)(8,`div`,7),BC(9,`Óptica`),hu(),Es(10,`div`,8),BC(11,`Gestión del local`),hu()()(),Es(12,`nav`,9),tC(13,Fi,6,6,`a`,10,Li),Kw(15,ji,5,0,`button`,11),hu(),Es(16,`div`,12)(17,`div`,13)(18,`div`,14),BC(19),hu(),Es(20,`div`,15)(21,`strong`),BC(22),hu(),Es(23,`span`),BC(24),hu()()(),Es(25,`button`,16),Pg(`click`,function(){return e.logout()}),Es(26,`mat-icon`),BC(27,`logout`),hu(),BC(28,` Cerrar sesión `),hu()()(),Es(29,`mat-sidenav-content`,17)(30,`mat-toolbar`,18)(31,`button`,19),Pg(`click`,function(){return e.toggleSidenav()}),Es(32,`mat-icon`),BC(33,`menu`),hu()(),Es(34,`a`,20)(35,`span`,6),BC(36,`visibility`),hu(),BC(37,` Óptica `),hu(),Es(38,`div`,21)(39,`div`,22)(40,`mat-icon`),BC(41,`search`),hu(),Es(42,`input`,23),Pg(`input`,function(o){return e.onSearchInput(o)})(`focus`,function(){return e.onSearchFocus()})(`blur`,function(){return e.onSearchBlur()})(`keydown.enter`,function(){return e.submitGlobalSearch()}),hu()(),Kw(43,Ui,6,3,`div`,24),hu(),Rg(44,`span`,25),Es(45,`button`,26),Pg(`click`,function(){return e.openSearchPage()}),Es(46,`mat-icon`),BC(47,`search`),hu()(),Es(48,`button`,27),Pg(`click`,function(){return e.goToNotifications()}),Es(49,`mat-icon`,28),BC(50,`notifications`),hu()(),Es(51,`button`,29)(52,`span`,30),BC(53),hu(),BC(54),Es(55,`mat-icon`),BC(56,`expand_more`),hu()(),Es(57,`button`,31)(58,`mat-icon`),BC(59,`account_circle`),hu()(),Es(60,`mat-menu`,null,1)(62,`div`,32)(63,`strong`),BC(64),hu(),Es(65,`span`),BC(66),hu()(),Rg(67,`mat-divider`),Es(68,`button`,33),Pg(`click`,function(){return e.changePassword()}),Es(69,`mat-icon`),BC(70,`lock_reset`),hu(),Es(71,`span`),BC(72,`Cambiar contraseña`),hu()(),Es(73,`button`,33),Pg(`click`,function(){return e.logout()}),Es(74,`mat-icon`),BC(75,`logout`),hu(),Es(76,`span`),BC(77,`Cerrar sesión`),hu()()()(),Es(78,`main`,34),Rg(79,`router-outlet`),hu()()()),t&2){let n=DC(61);QE(),xg(`mode`,e.isMobile()?`over`:`side`)(`opened`,e.sidenavOpen()),QE(12),nC(e.navItems),QE(2),Jw(e.pwa.installed()?-1:15),QE(4),Kg((e.user()?.name||`U`).charAt(0)),QE(3),Kg(e.user()?.name),QE(2),Kg(e.user()?.username),QE(18),xg(`value`,e.searchTerm()),QE(),Jw(e.showResults()?43:-1),QE(6),xg(`matBadge`,e.unreadCount())(`matBadgeHidden`,e.unreadCount()===0),QE(2),xg(`matMenuTriggerFor`,n),QE(2),Kg((e.user()?.name||`U`).charAt(0)),QE(),Iu(` `,e.user()?.name,` `),QE(3),xg(`matMenuTriggerFor`,n),QE(7),Kg(e.user()?.name),QE(2),Kg(e.user()?.username)}},dependencies:[Bm,ua,wr,di$1,ei,ge,ti,qt,ii,ni,tU,eU,Yn,Wn,le,Jn,_t,Ct,Kn,Vn,jn,Wt,qn,Xn,Fr,Lr],styles:[`.shell[_ngcontent-%COMP%]{height:100dvh;min-height:100dvh;background:var(--%NS%optic-bg)}.sidebar[_ngcontent-%COMP%]{width:256px;border-right:1px solid var(--%NS%optic-border);background:#fff;display:flex;flex-direction:column}.brand[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:22px 20px 18px;cursor:pointer;-webkit-user-select:none;user-select:none}.brand__mark[_ngcontent-%COMP%]{width:44px;height:44px;border-radius:14px;background:linear-gradient(145deg,#00b3b3,#008585);display:grid;place-items:center;color:#fff;box-shadow:0 6px 14px #00a0a04d}.brand__mark[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:26px}.brand__name[_ngcontent-%COMP%]{font-size:1.2rem;font-weight:800;color:#123333;letter-spacing:-.02em}.brand__sub[_ngcontent-%COMP%]{font-size:.73rem;color:var(--%NS%optic-muted);margin-top:1px}.nav[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:3px;padding:6px 12px;overflow-y:auto;flex:1}.nav-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;padding:11px 13px;border-radius:11px;color:#445858;font-weight:500;font-size:.92rem;text-decoration:none;transition:background .14s ease,color .14s ease}.nav-item--button[_ngcontent-%COMP%]{width:100%;border:none;background:transparent;cursor:pointer;font-family:inherit;text-align:left}.nav-item[_ngcontent-%COMP%]:hover{background:#f1f8f8;color:var(--%NS%optic-primary-dark);text-decoration:none}.nav-item--active[_ngcontent-%COMP%]{background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);font-weight:700}.nav-item[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:21px;color:inherit}.nav-item__badge[_ngcontent-%COMP%]{margin-left:auto;background:var(--%NS%optic-danger);color:#fff;border-radius:999px;font-size:.7rem;font-weight:700;min-width:20px;height:20px;display:grid;place-items:center;padding:0 6px}.sidebar__footer[_ngcontent-%COMP%]{border-top:1px solid var(--%NS%optic-border);padding:14px 14px 18px;display:flex;flex-direction:column;gap:10px}.sidebar__user[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:2px 4px}.avatar[_ngcontent-%COMP%]{width:38px;height:38px;border-radius:50%;background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);display:grid;place-items:center;font-weight:800;flex-shrink:0;text-transform:uppercase}.avatar--sm[_ngcontent-%COMP%]{width:28px;height:28px;font-size:.8rem}.sidebar__user-info[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0}.sidebar__user-info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.86rem;color:#244040;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sidebar__user-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.74rem;color:var(--%NS%optic-muted)}.content[_ngcontent-%COMP%]{background:var(--%NS%optic-bg);overflow-x:hidden}.topbar[_ngcontent-%COMP%]{height:68px;background:#fffffff5;border-bottom:1px solid var(--%NS%optic-border);position:sticky;top:0;z-index:20;padding:0 20px;display:flex;gap:8px;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}.topbar__icon[_ngcontent-%COMP%]{color:#4b6262}.topbar__brand[_ngcontent-%COMP%]{display:flex;align-items:center;gap:7px;font-weight:800;color:#143636;font-size:1.05rem;text-decoration:none;margin-right:4px}.topbar__brand[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%optic-primary)}.topbar__search[_ngcontent-%COMP%]{position:relative;width:min(460px,42vw);margin-left:14px}.topbar__search[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%], .topbar__search[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#789191;font-size:21px;pointer-events:none}.topbar__search[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]{min-height:44px;border-radius:12px;background:#f5f9f9;border-color:transparent}.topbar__search[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]:focus{background:#fff}.search-results[_ngcontent-%COMP%]{position:absolute;top:calc(100% + 8px);left:0;right:0;background:#fff;border:1px solid var(--%NS%optic-border);border-radius:14px;box-shadow:var(--%NS%shadow-md);overflow:hidden;z-index:30}.search-results__status[_ngcontent-%COMP%]{padding:4px}.search-results__empty[_ngcontent-%COMP%]{padding:18px;color:var(--%NS%optic-muted);font-size:.88rem;text-align:center}.search-result[_ngcontent-%COMP%]{width:100%;display:flex;align-items:center;gap:10px;padding:10px 14px;border:none;background:#fff;cursor:pointer;text-align:left;border-bottom:1px solid #f0f5f5}.search-result[_ngcontent-%COMP%]:hover{background:#f4fafa}.search-result__avatar[_ngcontent-%COMP%]{width:34px;height:34px;border-radius:50%;background:var(--%NS%optic-primary-soft);color:var(--%NS%optic-primary-dark);display:grid;place-items:center;font-weight:700;flex-shrink:0}.search-result__info[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0;flex:1}.search-result__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.9rem;color:#233c3c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.search-result__info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.78rem;color:var(--%NS%optic-muted)}.search-result[_ngcontent-%COMP%] > .material-icons[_ngcontent-%COMP%]{color:#9ab3b3;font-size:19px}.search-results__all[_ngcontent-%COMP%]{width:100%;border:none;background:#f7fbfb;color:var(--%NS%optic-primary-dark);font-weight:600;font-size:.84rem;padding:11px;cursor:pointer}.search-results__all[_ngcontent-%COMP%]:hover{background:var(--%NS%optic-primary-soft)}.topbar__user[_ngcontent-%COMP%]{font-weight:600;color:#344c4c}.menu-user[_ngcontent-%COMP%]{padding:12px 16px;display:flex;flex-direction:column}.menu-user[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.9rem}.menu-user[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.76rem;color:var(--%NS%optic-muted)}.main[_ngcontent-%COMP%]{min-height:calc(100dvh - 68px)}@media(max-width:900px){.sidebar[_ngcontent-%COMP%]{width:min(280px,86vw)}.topbar[_ngcontent-%COMP%]{padding:0 10px 0 6px;height:62px}.main[_ngcontent-%COMP%]{min-height:calc(100dvh - 62px)}}@media(max-width:360px){.topbar[_ngcontent-%COMP%]{gap:2px;padding:0 4px}.topbar__brand[_ngcontent-%COMP%]{gap:4px;font-size:.96rem}}`]})};export{ai as LayoutComponent};