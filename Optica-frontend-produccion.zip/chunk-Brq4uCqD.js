import{$t as gf,At as ZC,Bn as tm,C as Fe,E as GT,En as or,Et as Xe,F as Kg,G as Nb,Gt as eT,H as Mf,Hn as v,Jn as xg,Jt as fl,Kn as wt$1,N as Jw,Nn as pm,Ot as Xw,Pt as Zw,Qn as yl,R as Lg,Rn as tU,Rt as _t$1,S as Es,Sn as nt$1,Vt as bi,W as Mu,Wn as vl,X as PC,Xt as g,Yt as fy,Z as PI,_n as ml,_t as VI,d as Ag,en as hC,ft as So,h as Cl,ht as To,it as Qw,j as J2,jt as ZE,kn as pC,ln as kg,nn as hf,pn as mC,rt as Qg,sn as jm,st as Rs,tt as QC,u as A,un as lC,v as Dl,vt as Vg,w as Fs,wn as oC,wt as X2,xn as ne,yn as na}from"./main-P563L73P.js";import{n as Fr,o as Wr,r as Lr,t as Er}from"./chunk-CYxp9Ny5.js";import{b as q,p as We}from"./chunk-CdA-vY_o.js";import{C as hr,D as mr,F as ts,I as vn,L as wt$2,M as ri,N as rs,P as sr,S as ee,T as ji,a as Dt,b as Wr$1,d as Kr,f as Me,g as Qa,i as Br,l as Ja,o as Ft,p as Ne,s as Hr,t as $n,v as Ur,y as Vt}from"./chunk-BdXR_waH.js";import{b as nn,p as da,s as On}from"./chunk-C_kO2yv-.js";import{t as v$1}from"./chunk-SnbS0r-z.js";var Ye=(()=>{class e{labelPosition=`after`;static ɵfac=function(r){return new(r||e)};static ɵcmp=(function(){return To({type:e,selectors:[[``,`mat-internal-form-field`,``]],hostAttrs:[1,`mdc-form-field`,`mat-internal-form-field`],hostVars:2,hostBindings:function(g,p){g&2&&Rs(`mdc-form-field--align-end`,p.labelPosition===`before`)},inputs:{labelPosition:`labelPosition`},ngContentSelectors:[`*`],decls:1,vars:0,template:function(g,p){g&1&&(ml(),yl(0))},styles:[`.mat-internal-form-field {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}
.mat-internal-form-field > label, .mat-internal-form-field > .mat-internal-form-field-label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
  order: 0;
}
[dir=rtl] .mat-internal-form-field > label, [dir=rtl] .mat-internal-form-field > .mat-internal-form-field-label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
}

.mdc-form-field--align-end > label, .mdc-form-field--align-end > .mat-internal-form-field-label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
  order: -1;
}
[dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end label, [dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end .mat-internal-form-field-label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
}
`],encapsulation:2})})()}return e})();var nt=new v(`mat-slide-toggle-default-options`,{providedIn:`root`,factory:()=>({disableToggleValue:!1,hideIcon:!1,disabledInteractive:!1})});var U=class{source;checked;constructor(i,t){this.source=i,this.checked=t}};var j=(()=>{class e{_elementRef=g(nt$1);_focusMonitor=g(We);_changeDetectorRef=g(pm);defaults=g(nt);_injector=g(ne);_signalFormField=null;_onChange=t=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=!1;_createChangeEvent(t){return new U(this,t)}_labelId;get buttonId(){return`${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus()}_noopAnimations=Er();_focused=!1;name=null;id;labelPosition=`after`;ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=!1;color;disabled=!1;fullWidth=!1;disableRipple=!1;tabIndex=0;get checked(){return this._checked}set checked(t){this._checked=t,this._changeDetectorRef.markForCheck()}hideIcon;disabledInteractive;change=new Fe;toggleChange=new Fe;get inputId(){return`${this.id||this._uniqueId}-input`}constructor(){g(GT).load(nn);let t=g(new Fs(`tabindex`),{optional:!0}),r=this.defaults;this.tabIndex=t==null?0:parseInt(t)||0,this.color=r.color||`accent`,this.id=this._uniqueId=g(q).getId(`mat-mdc-slide-toggle-`),this.hideIcon=r.hideIcon??!1,this.disabledInteractive=r.disabledInteractive??!1,this._labelId=this._uniqueId+`-label`}ngOnInit(){this._signalFormField=this._injector.get($n,void 0,{optional:!0,self:!0})}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,!0).subscribe(t=>{t===`keyboard`||t===`program`?(this._focused=!0,this._changeDetectorRef.markForCheck()):t||Promise.resolve().then(()=>{this._focused=!1,this._onTouched(),this._changeDetectorRef.markForCheck()})})}ngOnChanges(t){t.required&&this._validatorOnChange()}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef)}writeValue(t){this.checked=!!t}registerOnChange(t){this._onChange=t}registerOnTouched(t){this._onTouched=t}validate(t){return this.required&&t.value!==!0&&!this._signalFormField?{required:!0}:null}registerOnValidatorChange(t){this._validatorOnChange=t}setDisabledState(t){this.disabled=t,this._changeDetectorRef.markForCheck()}toggle(){this.checked=!this.checked,this._onChange(this.checked)}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked))}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new U(this,this.checked))))}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static ɵfac=function(r){return new(r||e)};static ɵcmp=(function(){let t=[`switch`],r=[`*`];function g(p,_){p&1&&(Es(0,`span`,11),Mf(),Es(1,`svg`,13),xg(2,`path`,14),fl(),Es(3,`svg`,15),xg(4,`path`,16),fl()())}return To({type:e,selectors:[[`mat-slide-toggle`]],viewQuery:function(_,o){if(_&1&&Vg(t,5),_&2){let S;pC(S=hC())&&(o._switchElement=S.first)}},hostAttrs:[1,`mat-mdc-slide-toggle`],hostVars:15,hostBindings:function(_,o){_&2&&(kg(`id`,o.id),So(`tabindex`,null)(`aria-label`,null)(`name`,null)(`aria-labelledby`,null),vl(o.color?`mat-`+o.color:``),Rs(`mat-mdc-slide-toggle-focused`,o._focused)(`mat-mdc-slide-toggle-checked`,o.checked)(`mat-slide-toggle-full-width`,o.fullWidth)(`_mat-animation-noopable`,o._noopAnimations))},inputs:{name:`name`,id:`id`,labelPosition:`labelPosition`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],ariaDescribedby:[0,`aria-describedby`,`ariaDescribedby`],required:[2,`required`,`required`,Cl],color:`color`,disabled:[2,`disabled`,`disabled`,Cl],fullWidth:[2,`fullWidth`,`fullWidth`,Cl],disableRipple:[2,`disableRipple`,`disableRipple`,Cl],tabIndex:[2,`tabIndex`,`tabIndex`,p=>p==null?0:Nb(p)],checked:[2,`checked`,`checked`,Cl],hideIcon:[2,`hideIcon`,`hideIcon`,Cl],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,Cl]},outputs:{change:`change`,toggleChange:`toggleChange`},exportAs:[`matSlideToggle`],features:[tm([{provide:Ne,useExisting:bi(()=>e),multi:!0},{provide:ee,useExisting:e,multi:!0}]),Mu],ngContentSelectors:r,decls:14,vars:27,consts:[[`switch`,``],[`mat-internal-form-field`,``,3,`labelPosition`],[`role`,`switch`,`type`,`button`,1,`mdc-switch`,3,`click`,`tabIndex`,`disabled`],[1,`mat-mdc-slide-toggle-touch-target`],[1,`mdc-switch__track`],[1,`mdc-switch__handle-track`],[1,`mdc-switch__handle`],[1,`mdc-switch__shadow`],[1,`mdc-elevation-overlay`],[1,`mdc-switch__ripple`],[`mat-ripple`,``,1,`mat-mdc-slide-toggle-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`,`matRippleCentered`],[1,`mdc-switch__icons`],[1,`mdc-label`,3,`click`,`for`],[`viewBox`,`0 0 24 24`,`aria-hidden`,`true`,1,`mdc-switch__icon`,`mdc-switch__icon--on`],[`d`,`M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z`],[`viewBox`,`0 0 24 24`,`aria-hidden`,`true`,1,`mdc-switch__icon`,`mdc-switch__icon--off`],[`d`,`M20 13H4v-2h16v2z`]],template:function(_,o){if(_&1&&(ml(),Es(0,`div`,1)(1,`button`,2,0),Lg(`click`,function(){return o._handleClick()}),xg(3,`div`,3)(4,`span`,4),Es(5,`span`,5)(6,`span`,6)(7,`span`,7),xg(8,`span`,8),fl(),Es(9,`span`,9),xg(10,`span`,10),fl(),Zw(11,g,5,0,`span`,11),fl()()(),Es(12,`label`,12),Lg(`click`,function(et){return et.stopPropagation()}),yl(13),fl()()),_&2){let S=mC(2);Ag(`labelPosition`,o.labelPosition),ZE(),Rs(`mdc-switch--selected`,o.checked)(`mdc-switch--unselected`,!o.checked)(`mdc-switch--checked`,o.checked)(`mdc-switch--disabled`,o.disabled)(`mat-mdc-slide-toggle-disabled-interactive`,o.disabledInteractive),Ag(`tabIndex`,o.disabled&&!o.disabledInteractive?-1:o.tabIndex)(`disabled`,o.disabled&&!o.disabledInteractive),So(`id`,o.buttonId)(`name`,o.name)(`aria-label`,o.ariaLabel)(`aria-labelledby`,o._getAriaLabelledBy())(`aria-describedby`,o.ariaDescribedby)(`aria-required`,o.required||null)(`aria-checked`,o.checked)(`aria-disabled`,o.disabled&&o.disabledInteractive?`true`:null),ZE(9),Ag(`matRippleTrigger`,S)(`matRippleDisabled`,o.disableRipple||o.disabled)(`matRippleCentered`,!0),ZE(),Qw(o.hideIcon?-1:11),ZE(),Ag(`for`,o.buttonId),So(`id`,o._labelId)}},dependencies:[da,Ye],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--%NS%mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--%NS%mat-slide-toggle-track-height, 32px);
  border-radius: var(--%NS%mat-slide-toggle-track-shape, var(--%NS%mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--%NS%mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--%NS%mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-track-outline-color, var(--%NS%mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--%NS%mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--%NS%mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--%NS%mat-slide-toggle-disabled-unselected-track-outline-color, var(--%NS%mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--%NS%mat-slide-toggle-unselected-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--%NS%mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--%NS%mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--%NS%mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--%NS%mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-hover-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-focus-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-track-color, var(--%NS%mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--%NS%mat-slide-toggle-disabled-unselected-track-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--%NS%mat-slide-toggle-selected-track-color, var(--%NS%mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--%NS%mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--%NS%mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--%NS%mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--%NS%mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-track-color, var(--%NS%mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-track-color, var(--%NS%mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-track-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--%NS%mat-slide-toggle-disabled-selected-track-color, var(--%NS%mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--%NS%mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--%NS%mat-slide-toggle-handle-width);
  height: var(--%NS%mat-slide-toggle-handle-height);
  border-radius: var(--%NS%mat-slide-toggle-handle-shape, var(--%NS%mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--%NS%mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--%NS%mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--%NS%mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-selected-handle-size, 24px);
  height: var(--%NS%mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--%NS%mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--%NS%mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--%NS%mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--%NS%mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--%NS%mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--%NS%mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--%NS%selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--%NS%mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--%NS%unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--%NS%mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--%NS%mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--%NS%mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--%NS%selected:enabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-handle-color, var(--%NS%mat-sys-on-primary));
}
.mdc-switch--%NS%selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-handle-color, var(--%NS%mat-sys-primary-container));
}
.mdc-switch--%NS%selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-handle-color, var(--%NS%mat-sys-primary-container));
}
.mdc-switch--%NS%selected:enabled:active .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-handle-color, var(--%NS%mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--%NS%selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-disabled-selected-handle-color, var(--%NS%mat-sys-surface));
}
.mdc-switch--%NS%unselected:enabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-handle-color, var(--%NS%mat-sys-outline));
}
.mdc-switch--%NS%unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-hover-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--%NS%unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-focus-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--%NS%unselected:enabled:active .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-handle-color, var(--%NS%mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--%NS%mat-slide-toggle-disabled-unselected-handle-color, var(--%NS%mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--%NS%mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--%NS%mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--%NS%mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--%NS%mat-slide-toggle-state-layer-size, 40px);
  height: var(--%NS%mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--%NS%disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--%NS%unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-hover-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mdc-switch--%NS%unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-focus-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mdc-switch--%NS%unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-unselected-pressed-state-layer-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--%NS%selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-hover-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-hover-state-layer-opacity, var(--%NS%mat-sys-hover-state-layer-opacity));
}
.mdc-switch--%NS%selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-focus-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-focus-state-layer-opacity, var(--%NS%mat-sys-focus-state-layer-opacity));
}
.mdc-switch--%NS%selected:enabled:active .mdc-switch__ripple::after {
  background: var(--%NS%mat-slide-toggle-selected-pressed-state-layer-color, var(--%NS%mat-sys-primary));
  opacity: var(--%NS%mat-slide-toggle-selected-pressed-state-layer-opacity, var(--%NS%mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--%NS%mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--%NS%mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--%NS%mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--%NS%mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--%NS%mat-slide-toggle-unselected-icon-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--%NS%mat-slide-toggle-disabled-unselected-icon-color, var(--%NS%mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--%NS%mat-slide-toggle-selected-icon-size, 16px);
  height: var(--%NS%mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--%NS%mat-slide-toggle-selected-icon-color, var(--%NS%mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--%NS%mat-slide-toggle-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-icon {
  min-height: fit-content;
  flex-shrink: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--%NS%mat-slide-toggle-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-slide-toggle-label-text-font, var(--%NS%mat-sys-body-medium-font));
  line-height: var(--%NS%mat-slide-toggle-label-text-line-height, var(--%NS%mat-sys-body-medium-line-height));
  font-size: var(--%NS%mat-slide-toggle-label-text-size, var(--%NS%mat-sys-body-medium-size));
  letter-spacing: var(--%NS%mat-slide-toggle-label-text-tracking, var(--%NS%mat-sys-body-medium-tracking));
  font-weight: var(--%NS%mat-slide-toggle-label-text-weight, var(--%NS%mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--%NS%mat-slide-toggle-disabled-label-text-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-slide-toggle-full-width {
  width: 100%;
}
.mat-slide-toggle-full-width .mat-internal-form-field {
  width: 100%;
  justify-content: space-between;
}
.mat-slide-toggle-full-width .mat-internal-form-field label {
  margin: 0;
  flex-grow: 1;
  text-align: end;
}
.mat-slide-toggle-full-width .mdc-form-field--align-end label {
  text-align: start;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--%NS%mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--%NS%mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2})})()}return e})();var Je=(()=>{class e{static ɵfac=function(r){return new(r||e)};static ɵmod=wt$1({type:e});static ɵinj=Xe({imports:[j,fy]})}return e})();var L=class e{http=g(na);api=tU.apiUrl;list(i=1,t=10){let r=new _t$1().set(`page`,String(i)).set(`per_page`,String(t));return this.http.get(`${this.api}/users`,{params:r})}create(i){return this.http.post(`${this.api}/users`,i)}static ɵfac=function(t){return new(t||e)};static ɵprov=A({token:e,factory:e.ɵfac,providedIn:`root`})};var it=(e,i)=>i.id;function st(e,i){e&1&&xg(0,`mat-progress-bar`,9)}function rt(e,i){e&1&&PC(0,` El nombre es obligatorio. `)}function lt(e,i){e&1&&PC(0,` El nombre no puede superar los 100 caracteres. `)}function ot(e,i){e&1&&PC(0,` Escribe al menos 3 letras. `)}function dt(e,i){if(e&1&&(Es(0,`mat-error`),Zw(1,rt,1,0)(2,lt,1,0)(3,ot,1,0),fl()),e&2){let t=lC();ZE(),Qw(t.form.controls.name.errors?.required?1:t.form.controls.name.errors?.maxlength?2:3)}}function ct(e,i){e&1&&PC(0,` Usa solo letras, números, guiones o guiones bajos. `)}function mt(e,i){e&1&&PC(0,` El nombre de usuario es obligatorio. `)}function gt(e,i){e&1&&PC(0,` Debe tener al menos 3 caracteres. `)}function ht(e,i){if(e&1&&(Es(0,`mat-error`),Zw(1,ct,1,0)(2,mt,1,0)(3,gt,1,0),fl()),e&2){let t=lC();ZE(),Qw(t.form.controls.username.errors?.pattern?1:t.form.controls.username.errors?.required?2:3)}}function pt(e,i){e&1&&PC(0,` La contraseña es demasiado larga. `)}function ut(e,i){e&1&&PC(0,` La contraseña debe tener al menos 8 caracteres. `)}function ft(e,i){if(e&1&&(Es(0,`mat-error`),Zw(1,pt,1,0)(2,ut,1,0),fl()),e&2){let t=lC();ZE(),Qw(t.form.controls.password.errors?.maxlength?1:2)}}function bt(e,i){e&1&&PC(0,` Las contraseñas no coinciden. `)}function _t(e,i){e&1&&PC(0,` La contraseña es demasiado larga. `)}function vt(e,i){e&1&&PC(0,` Repite la contraseña. `)}function wt(e,i){if(e&1&&(Es(0,`mat-error`),Zw(1,bt,1,0)(2,_t,1,0)(3,vt,1,0),fl()),e&2){let t=lC();ZE(),Qw(t.form.controls.password_confirmation.errors?.mismatch?1:t.form.controls.password_confirmation.errors?.maxlength?2:3)}}function yt(e,i){if(e&1&&(Es(0,`div`,22)(1,`span`,4),PC(2,`error`),fl(),Es(3,`span`),PC(4),fl()()),e&2){let t=lC();ZE(4),Qg(t.error())}}function kt(e,i){e&1&&(xg(0,`span`,28),PC(1,` Creando… `))}function St(e,i){e&1&&(Es(0,`span`,4),PC(1,`person_add`),fl(),PC(2,` Crear usuario `))}function xt(e,i){e&1&&xg(0,`mat-progress-bar`,9)}function Nt(e,i){e&1&&(Es(0,`div`,27)(1,`span`,4),PC(2,`group`),fl(),Es(3,`h3`),PC(4,`No hay usuarios`),fl(),Es(5,`p`),PC(6,`Crea el primero con el formulario de la izquierda.`),fl()())}function Ct(e,i){if(e&1&&(Es(0,`span`,36),PC(1),ZC(2,`date`),fl()),e&2){let t=lC().$implicit;ZE(),Qg(QC(2,1,t.created_at,`dd/MM/yyyy`))}}function It(e,i){if(e&1&&(Es(0,`li`,30)(1,`span`,32),PC(2),fl(),Es(3,`div`,33)(4,`strong`),PC(5),fl(),Es(6,`span`,8),PC(7),fl()(),Es(8,`div`,34)(9,`span`,35),PC(10),fl(),Zw(11,Ct,3,4,`span`,36),fl()()),e&2){let t=i.$implicit;ZE(2),Qg(t.name.charAt(0)),ZE(3),Qg(t.name),ZE(2),Dl(`@`,t.username),ZE(2),Rs(`user-status--inactive`,!t.is_active),ZE(),Dl(` `,t.is_active?`Activo`:`Inactivo`,` `),ZE(),Qw(t.created_at?11:-1)}}function Mt(e,i){if(e&1){let t=oC();Es(0,`ul`,29),Xw(1,It,12,7,`li`,30,it),fl(),Es(3,`app-pager`,31),Lg(`pageChange`,function(g){hf(t);let p=lC();return gf(p.goToPage(g))}),fl()}if(e&2){let t=lC();ZE(),Jw(t.users()),ZE(2),Ag(`page`,t.page())(`lastPage`,t.lastPage())}}var Ke=class e{fb=g(Wr$1);usersService=g(L);toast=g(On);formDirective;users=or([]);loading=or(!0);saving=or(!1);error=or(null);page=or(1);lastPage=or(1);total=or(0);pageSize=10;form=this.fb.nonNullable.group({name:[``,[Me.required,Me.minLength(3),Me.maxLength(100),ts]],username:[``,[Me.required,Me.minLength(3),Me.maxLength(50),Me.pattern(/^[a-zA-Z0-9_-]+$/),ts]],password:[``,[Me.required,Me.minLength(8),Me.maxLength(255)]],password_confirmation:[``,[Me.required,Me.maxLength(255)]],is_active:[!0]},{validators:rs});ngOnInit(){this.loadUsers()}loadUsers(){this.loading.set(!0),this.usersService.list(this.page(),this.pageSize).subscribe({next:i=>{this.users.set(i.data),this.total.set(i.total),this.lastPage.set(i.last_page),this.loading.set(!1)},error:i=>{this.loading.set(!1),this.toast.error(Wr(i,`No se pudieron cargar los usuarios.`))}})}submit(){if(this.form.invalid){this.form.markAllAsTouched();return}if(this.form.controls.password.value!==this.form.controls.password_confirmation.value){this.form.controls.password_confirmation.setErrors({mismatch:!0}),this.form.controls.password_confirmation.markAsTouched();return}this.saving.set(!0),this.error.set(null);let i=this.form.getRawValue();this.usersService.create({name:i.name.trim(),username:i.username.trim().toLowerCase(),password:i.password,password_confirmation:i.password_confirmation,is_active:i.is_active}).subscribe({next:t=>{this.saving.set(!1),this.toast.success(t.message||`Usuario creado correctamente.`),this.clearForm(),this.page.set(1),this.loadUsers()},error:t=>{this.saving.set(!1),this.error.set(Wr(t,`No se pudo crear el usuario.`))}})}clearForm(){let i={name:``,username:``,password:``,password_confirmation:``,is_active:!0};this.formDirective?this.formDirective.resetForm(i):this.form.reset(i),this.form.markAsPristine(),this.form.markAsUntouched(),this.form.updateValueAndValidity(),this.error.set(null)}goToPage(i){i<1||i>this.lastPage()||i===this.page()||(this.page.set(i),this.loadUsers(),window.scrollTo({top:0,behavior:`smooth`}))}static ɵfac=function(t){return new(t||e)};static ɵcmp=To({type:e,selectors:[[`app-users`]],viewQuery:function(t,r){if(t&1&&Vg(wt$2,5),t&2){let g;pC(g=hC())&&(r.formDirective=g.first)}},decls:87,vars:14,consts:[[1,`page`],[1,`page-header`],[1,`page-header__text`],[1,`banner`,`banner--info`,2,`margin-bottom`,`16px`],[1,`material-icons`],[1,`users-layout`],[1,`card`],[1,`section-head`],[1,`muted`,`small`],[`mode`,`indeterminate`],[1,`stack`,3,`ngSubmit`,`formGroup`],[1,`form-required-note`],[1,`form-grid`],[`appearance`,`outline`,1,`full`],[`matInput`,``,`formControlName`,`name`,`autocomplete`,`name`,`maxlength`,`100`,`placeholder`,`Ej. Ana Torres`],[`matPrefix`,``],[`appearance`,`outline`],[`matInput`,``,`formControlName`,`username`,`autocomplete`,`username`,`autocapitalize`,`none`,`spellcheck`,`false`,`maxlength`,`50`,`placeholder`,`Ej. maria`],[1,`active-toggle`],[`formControlName`,`is_active`,`color`,`primary`],[`matInput`,``,`type`,`password`,`formControlName`,`password`,`autocomplete`,`new-password`,`maxlength`,`255`],[`matInput`,``,`type`,`password`,`formControlName`,`password_confirmation`,`autocomplete`,`new-password`,`maxlength`,`255`],[1,`banner`,`banner--danger`],[1,`form-actions`],[`type`,`submit`,1,`btn`,`btn--primary`,`btn--lg`,3,`disabled`],[`type`,`button`,1,`btn`,`btn--outline`,`btn--lg`,3,`click`,`disabled`],[`type`,`button`,1,`btn`,`btn--ghost`,`btn--sm`,3,`click`],[1,`empty-state`],[1,`spinner`],[1,`user-list`],[1,`user-item`],[3,`pageChange`,`page`,`lastPage`],[1,`user-item__avatar`],[1,`user-item__body`],[1,`user-item__side`],[1,`user-status`],[1,`muted`,`tiny`]],template:function(t,r){t&1&&(Es(0,`div`,0)(1,`header`,1)(2,`div`,2)(3,`h1`),PC(4,`Usuarios`),fl(),Es(5,`p`),PC(6,`Crea una cuenta para que otra persona pueda ingresar al sistema.`),fl()()(),Es(7,`div`,3)(8,`span`,4),PC(9,`info`),fl(),Es(10,`span`),PC(11,` Los usuarios nuevos tienen los mismos permisos que tú. Comparte la contraseña de forma segura y pídele que la cambie después de su primer ingreso. `),fl()(),Es(12,`div`,5)(13,`section`,6)(14,`div`,7)(15,`div`)(16,`h2`),PC(17,`Crear usuario`),fl(),Es(18,`p`,8),PC(19,`Completa los datos de la persona que usará el sistema.`),fl()()(),Zw(20,st,1,0,`mat-progress-bar`,9),Es(21,`form`,10),Lg(`ngSubmit`,function(){return r.submit()}),Es(22,`p`,11),PC(23,`Los campos con * son obligatorios.`),fl(),Es(24,`div`,12)(25,`mat-form-field`,13)(26,`mat-label`),PC(27,`Nombre completo`),fl(),Es(28,`input`,14),PI(),fl(),Es(29,`mat-icon`,15),PC(30,`badge`),fl(),Es(31,`mat-hint`),PC(32,`Nombre y apellidos de la persona.`),fl(),Zw(33,dt,4,1,`mat-error`),fl(),Es(34,`mat-form-field`,16)(35,`mat-label`),PC(36,`Nombre de usuario`),fl(),Es(37,`input`,17),PI(),fl(),Es(38,`mat-icon`,15),PC(39,`person`),fl(),Es(40,`mat-hint`),PC(41,`Sin espacios. Se usará para iniciar sesión.`),fl(),Zw(42,ht,4,1,`mat-error`),fl(),Es(43,`div`,18)(44,`mat-slide-toggle`,19),PI(),PC(45,` Usuario activo `),fl(),Es(46,`p`,8),PC(47,` Si está activo, podrá iniciar sesión inmediatamente. Puedes desactivarlo al crearlo si aún no lo usará. `),fl()(),Es(48,`mat-form-field`,16)(49,`mat-label`),PC(50,`Contraseña`),fl(),Es(51,`input`,20),PI(),fl(),Es(52,`mat-icon`,15),PC(53,`lock`),fl(),Es(54,`mat-hint`),PC(55,`Mínimo 8 caracteres. Compártela de forma segura.`),fl(),Zw(56,ft,3,1,`mat-error`),fl(),Es(57,`mat-form-field`,16)(58,`mat-label`),PC(59,`Repetir contraseña`),fl(),Es(60,`input`,21),PI(),fl(),Es(61,`mat-icon`,15),PC(62,`lock_reset`),fl(),Es(63,`mat-hint`),PC(64,`Debe coincidir exactamente con la contraseña.`),fl(),Zw(65,wt,4,1,`mat-error`),fl()(),Zw(66,yt,5,1,`div`,22),Es(67,`div`,23)(68,`button`,24),Zw(69,kt,2,0)(70,St,3,0),fl(),Es(71,`button`,25),Lg(`click`,function(){return r.clearForm()}),PC(72,` Limpiar `),fl()()()(),Es(73,`section`,6)(74,`div`,7)(75,`div`)(76,`h2`),PC(77,`Usuarios del sistema`),fl(),Es(78,`p`,8),PC(79),fl()(),Es(80,`button`,26),Lg(`click`,function(){return r.loadUsers()}),Es(81,`mat-icon`),PC(82,`refresh`),fl(),PC(83,` Actualizar `),fl()(),Zw(84,xt,1,0,`mat-progress-bar`,9),Zw(85,Nt,7,0,`div`,27)(86,Mt,4,2),fl()()()),t&2&&(ZE(20),Qw(r.saving()?20:-1),ZE(),Ag(`formGroup`,r.form),ZE(7),VI(),ZE(5),Qw(r.form.controls.name.touched&&r.form.controls.name.invalid?33:-1),ZE(4),VI(),ZE(5),Qw(r.form.controls.username.touched&&r.form.controls.username.invalid?42:-1),ZE(2),VI(),ZE(7),VI(),ZE(5),Qw(r.form.controls.password.touched&&r.form.controls.password.invalid?56:-1),ZE(4),VI(),ZE(5),Qw(r.form.controls.password_confirmation.touched&&r.form.controls.password_confirmation.invalid?65:-1),ZE(),Qw(r.error()?66:-1),ZE(2),Ag(`disabled`,r.saving()),ZE(),Qw(r.saving()?69:70),ZE(2),Ag(`disabled`,r.saving()),ZE(8),Kg(` `,r.total(),` `,r.total()===1?`usuario registrado`:`usuarios registrados`,`. `),ZE(5),Qw(r.loading()?84:-1),ZE(),Qw(!r.loading()&&r.users().length===0?85:86))},dependencies:[jm,Kr,Ur,vn,Br,Hr,ji,wt$2,sr,Vt,ri,Dt,Ft,mr,hr,Ja,Qa,J2,X2,Fr,Lr,Je,j,v$1,eT],styles:[`.users-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);gap:16px;align-items:start}.section-head[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}.section-head[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-size:1.05rem}.active-toggle[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;padding:8px 12px;border:1px solid var(--%NS%optic-border);border-radius:12px;background:#fbfdfd;height:fit-content;margin-top:4px}.active-toggle[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0}.user-list[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0;display:flex;flex-direction:column}.user-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:11px;padding:12px 4px;border-bottom:1px solid #eef4f4}.user-item[_ngcontent-%COMP%]:last-child{border-bottom:none}.user-item__avatar[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:12px;background:#e2f6f6;color:#007171;display:grid;place-items:center;font-weight:800;font-size:1rem;flex-shrink:0;text-transform:uppercase}.user-item__body[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0;flex:1}.user-item__body[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.user-item__side[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0}.user-status[_ngcontent-%COMP%]{display:inline-flex;border-radius:999px;padding:3px 10px;font-size:.72rem;font-weight:700;background:var(--%NS%optic-success-soft);color:#217a45}.user-status--inactive[_ngcontent-%COMP%]{background:#eef1f1;color:#62706f}.spinner[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;animation:_ngcontent-%COMP%_spin .7s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}@media(max-width:980px){.users-layout[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr)}}@media(max-width:720px){.form-actions[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%]{flex:1 1 auto}.user-item[_ngcontent-%COMP%]{align-items:flex-start}}`]})};export{Ke as UsersComponent};